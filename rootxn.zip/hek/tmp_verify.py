"""Bounded verify: test only shell.txt entries."""
import sys, os, requests
sys.path.insert(0, "/home/xiao/Unduhan/hek")
from shell_manager_v2 import ShellManagerV2

sm = ShellManagerV2()
print("total shells loaded:", len(sm.all_shells))
for s in sm.all_shells:
    try:
        r = requests.get(s, timeout=3, verify=False, headers={"User-Agent":"Mozilla/5.0"})
        status = "OK" if r.status_code==200 else "FAIL"
        print("  [{}] {}".format(status, s[:80]))
    except Exception as e:
        print("  [ERR] {} {}".format(s[:80], str(e)[:60]))
