#!/usr/bin/env python3
"""
ZONE-H GRABBER MODULE v1.0
===========================
Zone-h defacement grabber dan notifier
Diadaptasi dari AlienExploit Tool11
"""

import requests
import re
import json
import threading
import urllib3
from concurrent.futures import ThreadPoolExecutor, as_completed
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn, TimeElapsedColumn
from rich.table import Table

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
console = Console()

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36',
}

# Zone-h endpoints
ZONEH_URLS = {
    'archive': 'https://zone-h.org/archive',
    'archive_today': 'https://zone-h.org/archive/today',
    'archive_week': 'https://zone-h.org/archive/week',
    'archive_month': 'https://zone-h.org/archive/month',
    'archive_critical': 'https://zone-h.org/archive/critical',
    'archive_unverified': 'https://zone-h.org/archive/unverified',
    'archive_mirror': 'https://zone-h.org/archive/mirror',
}


class ZoneHGrabber:
    """Zone-h defacement grabber."""
    
    def __init__(self):
        self.defacements = []
    
    def grab_archive(self, category='archive', pages=1):
        """Grab defacements dari Zone-h archive."""
        url = ZONEH_URLS.get(category, ZONEH_URLS['archive'])
        console.print(f"[cyan]Grabbing Zone-h archive: {url}[/cyan]")
        
        for page in range(1, pages + 1):
            try:
                page_url = f'{url}/page={page}' if page > 1 else url
                r = requests.get(page_url, timeout=15, headers=HEADERS, verify=False)
                
                if r.status_code == 200:
                    # Parse defacement entries
                    entries = self._parse_archive(r.text)
                    self.defacements.extend(entries)
                    console.print(f"  [green]Page {page}: Found {len(entries)} defacements[/green]")
                else:
                    console.print(f"  [red]Page {page}: HTTP {r.status_code}[/red]")
            except Exception as e:
                console.print(f"  [red]Page {page}: Error - {e}[/red]")
        
        return self.defacements
    
    def _parse_archive(self, html):
        """Parse Zone-h archive HTML."""
        entries = []
        
        # Find defacement entries
        # Zone-h archive format: <a href="/mirror/id/XXXX">domain.com</a>
        mirrors = re.findall(r'href=["\']/mirror/id/(\d+)["\'][^>]*>(.*?)</a>', html)
        
        for mirror_id, domain in mirrors:
            entries.append({
                'id': mirror_id,
                'domain': domain.strip(),
                'url': f'https://zone-h.org/mirror/id/{mirror_id}',
                'mirror': f'https://zone-h.org/mirror/{mirror_id}',
            })
        
        return entries
    
    def grab_by_cms(self, cms_type, pages=1):
        """Grab defacements by CMS type."""
        url = f'https://zone-h.org/archive/by={cms_type}'
        console.print(f"[cyan]Grabbing Zone-h by CMS: {cms_type}[/cyan]")
        
        for page in range(1, pages + 1):
            try:
                page_url = f'{url}/page={page}' if page > 1 else url
                r = requests.get(page_url, timeout=15, headers=HEADERS, verify=False)
                
                if r.status_code == 200:
                    entries = self._parse_archive(r.text)
                    self.defacements.extend(entries)
                    console.print(f"  [green]Page {page}: Found {len(entries)} defacements[/green]")
            except Exception as e:
                console.print(f"  [red]Page {page}: Error - {e}[/red]")
        
        return self.defacements
    
    def grab_by_country(self, country_code, pages=1):
        """Grab defacements by country."""
        url = f'https://zone-h.org/archive/country={country_code}'
        console.print(f"[cyan]Grabbing Zone-h by country: {country_code}[/cyan]")
        
        for page in range(1, pages + 1):
            try:
                page_url = f'{url}/page={page}' if page > 1 else url
                r = requests.get(page_url, timeout=15, headers=HEADERS, verify=False)
                
                if r.status_code == 200:
                    entries = self._parse_archive(r.text)
                    self.defacements.extend(entries)
                    console.print(f"  [green]Page {page}: Found {len(entries)} defacements[/green]")
            except Exception as e:
                console.print(f"  [red]Page {page}: Error - {e}[/red]")
        
        return self.defacements
    
    def grab_by_notifier(self, notifier, pages=1):
        """Grab defacements by notifier."""
        url = f'https://zone-h.org/archive/notifier={notifier}'
        console.print(f"[cyan]Grabbing Zone-h by notifier: {notifier}[/cyan]")
        
        for page in range(1, pages + 1):
            try:
                page_url = f'{url}/page={page}' if page > 1 else url
                r = requests.get(page_url, timeout=15, headers=HEADERS, verify=False)
                
                if r.status_code == 200:
                    entries = self._parse_archive(r.text)
                    self.defacements.extend(entries)
                    console.print(f"  [green]Page {page}: Found {len(entries)} defacements[/green]")
            except Exception as e:
                console.print(f"  [red]Page {page}: Error - {e}[/red]")
        
        return self.defacements
    
    def export_results(self, output_file='zoneh_results.json'):
        """Export results to JSON."""
        with open(output_file, 'w') as f:
            json.dump(self.defacements, f, indent=2)
        console.print(f"[green]Results exported to {output_file}[/green]")
    
    def display_summary(self):
        """Display summary table."""
        if not self.defacements:
            console.print("[yellow]No defacements found.[/yellow]")
            return
        
        console.print(f"\n[bold green]ZONE-H GRABBER SUMMARY[/bold green]")
        console.print(f"  Total defacements: {len(self.defacements)}")
        
        table = Table(title="Zone-h Defacements")
        table.add_column("ID", width=10)
        table.add_column("Domain", width=40)
        table.add_column("URL", width=50)
        for d in self.defacements[:20]:
            table.add_row(d['id'], d['domain'], d['url'])
        console.print(table)


def main():
    import argparse
    parser = argparse.ArgumentParser(description="Zone-h Grabber")
    parser.add_argument("--category", default="archive", help="Archive category")
    parser.add_argument("--cms", help="CMS type (wordpress, joomla, etc)")
    parser.add_argument("--country", help="Country code (US, ID, etc)")
    parser.add_argument("--notifier", help="Notifier name")
    parser.add_argument("--pages", type=int, default=1, help="Number of pages")
    parser.add_argument("-o", "--output", default="zoneh_results.json", help="Output file")
    args = parser.parse_args()
    
    grabber = ZoneHGrabber()
    
    if args.cms:
        grabber.grab_by_cms(args.cms, args.pages)
    elif args.country:
        grabber.grab_by_country(args.country, args.pages)
    elif args.notifier:
        grabber.grab_by_notifier(args.notifier, args.pages)
    else:
        grabber.grab_archive(args.category, args.pages)
    
    grabber.display_summary()
    grabber.export_results(args.output)


if __name__ == "__main__":
    main()
