#!/usr/bin/env python3
"""
Dorking Scanner v2 - go.id target collector
Uses DuckDuckGo HTML with retry logic + Bing fallback
Saves results incrementally to list.txt
"""

import re
import time
import random
import urllib.request
import urllib.parse
import ssl
import os
from concurrent.futures import ThreadPoolExecutor, as_completed

# Colors
RS = "\033[0m"
BR = "\033[1m"
R  = "\033[91m"
G  = "\033[92m"
Y  = "\033[93m"
C  = "\033[96m"
W  = "\033[97m"
D  = "\033[90m"

SSL_CTX = ssl._create_unverified_context()
USER_AGENTS = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
    'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:121.0) Gecko/20100101 Firefox/121.0',
]

DORK_FILE = "/home/xiao/Unduhan/hek/dork.txt"
OUTPUT_FILE = "/home/xiao/Unduhan/hek/list.txt"
PROGRESS_FILE = "/home/xiao/Unduhan/hek/dorking_progress.txt"

def load_dorks():
    dorks = []
    with open(DORK_FILE, 'r', errors='ignore') as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith('#'):
                dorks.append(line)
    return dorks

def load_progress():
    """Load already-processed dorks to skip."""
    done = set()
    if os.path.exists(PROGRESS_FILE):
        with open(PROGRESS_FILE, 'r') as f:
            for line in f:
                done.add(line.strip())
    return done

def save_progress(dork):
    with open(PROGRESS_FILE, 'a') as f:
        f.write(dork + '\n')

def save_result(url):
    """Append URL to list.txt immediately."""
    with open(OUTPUT_FILE, 'a') as f:
        f.write(url + '\n')

def extract_goid_urls(html):
    """Extract go.id URLs from HTML."""
    urls = []
    # Pattern 1: DDG result links
    links = re.findall(r'class="result__a"[^>]*href="([^"]+)"', html)
    for u in links:
        if 'uddg=' in u:
            match = re.search(r'uddg=([^&]+)', u)
            if match:
                u = urllib.parse.unquote(match.group(1))
        if 'go.id' in u and 'duckduckgo' not in u:
            u = u.split('&')[0].split('?')[0]
            if u not in urls:
                urls.append(u)
    
    # Pattern 2: Bing result links
    if not urls:
        links = re.findall(r'<h2><a href="(https?://[^"]+)"', html)
        for u in links:
            if 'go.id' in u and 'bing' not in u and 'microsoft' not in u:
                u = u.split('&')[0].split('?')[0]
                if u not in urls:
                    urls.append(u)
    
    # Pattern 3: Generic go.id links
    if not urls:
        links = re.findall(r'href="(https?://[^"]*go\.id[^"]*)"', html)
        for u in links:
            if 'duckduckgo' not in u and 'bing' not in u and 'microsoft' not in u:
                u = u.split('&')[0].split('?')[0]
                if u not in urls:
                    urls.append(u)
    
    return urls

def ddg_search(dork, max_retries=3):
    """Search DuckDuckGo with retry logic."""
    query = f"site:go.id {dork}"
    encoded = urllib.parse.quote(query)
    url = f"https://html.duckduckgo.com/html/?q={encoded}"
    
    for attempt in range(max_retries):
        headers = {
            'User-Agent': random.choice(USER_AGENTS),
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'identity',
            'Connection': 'keep-alive',
        }
        
        try:
            req = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(req, timeout=15, context=SSL_CTX) as r:
                html = r.read().decode('utf-8', errors='ignore')
                if 'anomaly' in html.lower() or 'captcha' in html.lower():
                    if attempt < max_retries - 1:
                        time.sleep(5 * (attempt + 1))
                        continue
                    return []
                return extract_goid_urls(html)
        except Exception as e:
            if attempt < max_retries - 1:
                time.sleep(3 * (attempt + 1))
                continue
            return []
    return []

def bing_search(dork, max_retries=2):
    """Fallback to Bing search."""
    query = f"site:go.id {dork}"
    encoded = urllib.parse.quote(query)
    url = f"https://www.bing.com/search?q={encoded}&count=20"
    
    for attempt in range(max_retries):
        headers = {
            'User-Agent': random.choice(USER_AGENTS),
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'identity',
        }
        
        try:
            req = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(req, timeout=15, context=SSL_CTX) as r:
                html = r.read().decode('utf-8', errors='ignore')
                return extract_goid_urls(html)
        except Exception:
            if attempt < max_retries - 1:
                time.sleep(3)
                continue
            return []
    return []

def search_dork(dork):
    """Try DDG first, fallback to Bing."""
    urls = ddg_search(dork)
    if urls:
        return urls
    # If DDG returns nothing, try Bing
    time.sleep(2)
    urls = bing_search(dork)
    return urls

def worker(idx, total, dork):
    """Worker function for parallel dorking."""
    urls = search_dork(dork)
    
    # Save results immediately
    for url in urls:
        save_result(url)
    save_progress(dork)
    
    if urls:
        print(f" {W}[{idx}/{total}]{RS} Dork: {C}{dork[:50]:<50}{RS} -> {G}[{len(urls)} URLs]{RS}", flush=True)
    else:
        print(f" {W}[{idx}/{total}]{RS} Dork: {C}{dork[:50]:<50}{RS} -> {R}[ZONK]{RS}", flush=True)
    
    # Random delay to avoid rate limiting
    time.sleep(random.uniform(2.0, 5.0))
    return urls

def main():
    print(f" {D}{'='*70}{RS}")
    print(f" {W}{BR}DORKING SCANNER v2 - go.id TARGET COLLECTOR{RS}")
    print(f" {D}{'='*70}{RS}")
    
    # Step 1: Clear list.txt and progress
    print(f"\n {Y}[*] Clearing list.txt and progress...{RS}")
    with open(OUTPUT_FILE, 'w') as f:
        f.write('')
    if os.path.exists(PROGRESS_FILE):
        os.remove(PROGRESS_FILE)
    print(f" {G}[+] Cleared.{RS}")
    
    # Step 2: Load dorks
    print(f" {Y}[*] Loading dorks from dork.txt...{RS}")
    dorks = load_dorks()
    total = len(dorks)
    print(f" {G}[+] Loaded {total} dorks.{RS}")
    
    # Step 3: Dorking
    print(f"\n {Y}[*] Starting dorking (DDG + Bing fallback)...{RS}")
    print(f" {D}{'─'*70}{RS}")
    
    all_urls = set()
    max_threads = 2  # Conservative to avoid rate limiting
    
    with ThreadPoolExecutor(max_workers=max_threads) as executor:
        futures = {
            executor.submit(worker, idx, total, dork): dork
            for idx, dork in enumerate(dorks, 1)
        }
        
        for future in as_completed(futures):
            try:
                urls = future.result()
                if urls:
                    all_urls.update(urls)
            except Exception:
                pass
    
    # Step 4: Deduplicate and save final results
    print(f"\n {D}{'─'*70}{RS}")
    print(f" {Y}[*] Deduplicating and saving final results...{RS}")
    
    # Read all saved URLs
    final_urls = set()
    if os.path.exists(OUTPUT_FILE):
        with open(OUTPUT_FILE, 'r') as f:
            for line in f:
                line = line.strip()
                if line:
                    final_urls.add(line)
    
    # Save deduplicated results
    with open(OUTPUT_FILE, 'w') as f:
        for url in sorted(final_urls):
            f.write(url + '\n')
    
    print(f" {G}[+] Done! {len(final_urls)} unique URLs saved to {OUTPUT_FILE}{RS}")
    print(f" {D}{'='*70}{RS}")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print(f"\n\n {R}[!] Interrupted by user.{RS}\n")
