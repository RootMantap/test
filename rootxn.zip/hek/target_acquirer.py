#!/usr/bin/env python3
"""
GROOTX TARGET ACQUIRER v1.0 - Auto Google & Shodan Target Fetcher
===============================================================
Automatically fetches targets from Google dorks and Shodan,
deduplicates, and saves to list.txt

Team: GROOTX Exploitation Team
"""

import os
import sys
import json
import time
import re
import requests
import urllib3
import threading
import concurrent.futures
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
import subprocess
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn, TimeElapsedColumn
from rich.table import Table
from rich.panel import Panel

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

console = Console()

# ═══════════════════════════════════════════════════════════════
# CONFIG
# ═══════════════════════════════════════════════════════════════

LIST_FILE = "list.txt"
RESULTS_FILE = "acquired_targets.json"
VERIFY_TIMEOUT = 5
THREADS = 50

# Google Dorks (free tier - no regex OR)
GOOGLE_DORKS = [
    # Laravel Livewire
    'site:"*.com" "wire:snapshot" "livewire"',
    'site:"*.id" "wire:snapshot"',
    'inurl:"wire:snapshot"',
    '"livewire" "wire:snapshot" intext:"app"',
    # WordPress
    'site:"*.com" "wp-content" "wp-json"',
    'inurl:"wp-json/batch"',
    'site:"*.com" "wp-content/plugins"',
    # Roundcube
    'site:"*.com" "roundcube" "login"',
    'inurl:"roundcube"',
    'site:"*.com" "roundcubemail"',
    # Joomla
    'site:"*.com" "com_jce"',
    'site:"*.com" "joomla" "jce"',
    # CodeIgniter
    'inurl:"codeigniter"',
    'site:"*.com" "ci-session"',
    # phpfm
    'site:"*.com" "php-file-manager"',
    'inurl:"phpfm"',
    # WooCommerce
    'site:"*.com" "woocommerce" "wp-admin"',
    'inurl:"wp-admin/admin-ajax.php" "woocommerce"',
    # SmarterMail
    'site:"*.com" "smartermail"',
    'inurl:"smartermail"',
    # Generic PHP servers
    'site:"*.com" inurl:"/index.php" "PHP" "Server"',
    'site:"*.com" "<?php" "system"',
    # Greendir / existing shells
    'site:"*.com" "greendir"',
    'inurl:"commant_index.php"',
    'inurl:"green.php"',
    'site:"*.com" "shell.php" "system"',
]

# Shodan Queries (via API or CLI)
SHODAN_QUERIES = [
    "http.component:livewire",
    "http.component:roundcube",
    "http.component:wordpress",
    "http.component:joomla",
    "http.component:codeigniter",
    "http.component:phpmyadmin",
    'http.title:"Laravel"',
    'http.title:"WordPress"',
    'http.title:"Roundcube"',
    'http.title:"Joomla"',
    'http.server:"Apache" http.component:php',
    'port:80,443 http.component:livewire',
    'http.component:woocommerce',
    'http.component:jce',
]

# Headers for Google scraping
HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9,id;q=0.8",
    "Connection": "keep-alive",
}


# ═══════════════════════════════════════════════════════════════
# GOOGLE DORK FETCHER
# ═══════════════════════════════════════════════════════════════

class GoogleFetcher:
    """Fetch targets from Google using dork queries."""

    def __init__(self):
        self.all_targets = set()
        self.failed_dorks = []

    def fetch_dork(self, dork, max_results=50):
        """Fetch URLs from a single Google dork."""
        urls = []
        try:
            # Use Google search via requests
            for start in range(0, max_results, 10):
                try:
                    params = {
                        "q": dork,
                        "start": start,
                        "num": 10,
                        "filter": 0,
                    }
                    r = requests.get(
                        "https://www.google.com/search",
                        params=params,
                        headers=HEADERS,
                        timeout=10,
                        verify=False,
                    )
                    if r.status_code != 200:
                        continue

                    # Extract URLs from Google search results
                    # Pattern: href="http://..." or href="https://...
                    found = re.findall(r'href="(https?://[^"]+)"', r.text)
                    for url in found:
                        url = url.split('/')[0] + '//' + url.split('//')[1].split('/')[0] if '//' in url else url
                        url = url.rstrip('/')
                        # Filter out Google, social media, non-targets
                        if any(x in url for x in ["google.com", "facebook.com", "twitter.com", "youtube.com", "linkedin.com", "instagram.com", "wikipedia.org", "reddit.com"]):
                            continue
                        if url.startswith(("http://", "https://")):
                            urls.append(url)

                    time.sleep(0.5)  # Be gentle with Google
                except:
                    continue

        except Exception as e:
            console.print(f"[red]Google fetch error: {e}[/red]")
            self.failed_dorks.append(dork)

        return urls

    def fetch_all(self):
        """Fetch from all Google dorks in parallel."""
        console.print(f"\n[bold cyan][GOOGLE FETCHER][bold cyan] {len(GOOGLE_DORKS)} dorks[/bold cyan]")

        with Progress(
            SpinnerColumn(), TextColumn("[progress.description]{task.description}"),
            BarColumn(bar_width=40), TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            TimeElapsedColumn(), console=console
        ) as progress:
            task = progress.add_task("[cyan]Fetching from Google...", total=len(GOOGLE_DORKS))

            with ThreadPoolExecutor(max_workers=min(10, len(GOOGLE_DORKS))) as executor:
                futures = {executor.submit(self.fetch_dork, d): d for d in GOOGLE_DORKS}
                for future in concurrent.futures.as_completed(futures):
                    progress.update(task, advance=1)
                    dork = futures[future]
                    try:
                        urls = future.result()
                        for url in urls:
                            self.all_targets.add(url)
                        if urls:
                            console.print(f"  [green]{dork}[/green] → {len(urls)} URLs")
                    except:
                        self.failed_dorks.append(dork)

        return list(self.all_targets)


# ═══════════════════════════════════════════════════════════════
# SHODAN FETCHER
# ═══════════════════════════════════════════════════════════════

class ShodanFetcher:
    """Fetch targets from Shodan."""

    def __init__(self, api_key=None):
        self.api_key = api_key or os.environ.get("SHODAN_API_KEY", "")
        self.all_targets = set()

    def _fetch_via_api(self, query):
        """Fetch via Shodan API (requires API key)."""
        if not self.api_key:
            return []
        try:
            r = requests.get(
                "https://api.shodan.io/shodan/host/search",
                params={"key": self.api_key, "query": query, "page": 1, "size": 100},
                timeout=15,
                verify=False,
            )
            if r.status_code == 200:
                data = r.json()
                urls = []
                for host in data.get("matches", []):
                    ip = host.get("ip_str", "")
                    ports = host.get("ports", [])
                    if ip and ports:
                        urls.append(f"http://{ip}")
                return urls
        except:
            pass
        return []

    def _fetch_via_cli(self, query):
        """Fetch via Shodan CLI if available."""
        try:
            result = subprocess.run(
                ["shodan", "search", "--fields", "ip_str", query],
                capture_output=True, text=True, timeout=30,
                env={**os.environ, "SHODAN_API_KEY": self.api_key}
            )
            if result.returncode == 0:
                urls = []
                for line in result.stdout.strip().split('\n')[1:]:
                    line = line.strip()
                    if line:
                        urls.append(f"http://{line}")
                return urls
        except:
            pass
        return []

    def fetch_all(self):
        """Fetch from all Shodan queries."""
        console.print(f"\n[bold cyan][SHODAN FETCHER][bold cyan] {len(SHODAN_QUERIES)} queries[/bold cyan]")

        if not self.api_key:
            console.print("[yellow]No Shodan API key found. Trying CLI...[/yellow]")

        with Progress(
            SpinnerColumn(), TextColumn("[progress.description]{task.description}"),
            BarColumn(bar_width=40), TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            TimeElapsedColumn(), console=console
        ) as progress:
            task = progress.add_task("[cyan]Fetching from Shodan...", total=len(SHODAN_QUERIES))

            with ThreadPoolExecutor(max_workers=min(5, len(SHODAN_QUERIES))) as executor:
                futures = {executor.submit(self._fetch_via_api, q): q for q in SHODAN_QUERIES}
                for future in concurrent.futures.as_completed(futures):
                    progress.update(task, advance=1)
                    query = futures[future]
                    try:
                        urls = future.result()
                        for url in urls:
                            self.all_targets.add(url)
                        if urls:
                            console.print(f"  [green]{query}[/green] → {len(urls)} hosts")
                    except:
                        pass

        return list(self.all_targets)


# ═══════════════════════════════════════════════════════════════
# TARGET VERIFIER
# ═══════════════════════════════════════════════════════════════

class TargetVerifier:
    """Verify targets are alive and reachable."""

    def __init__(self):
        self.alive = set()
        self.dead = set()
        self.lock = threading.Lock()

    def verify_single(self, target):
        """Verify single target is reachable."""
        try:
            r = requests.get(target, timeout=VERIFY_TIMEOUT, verify=False,
                           headers={"User-Agent": "Mozilla/5.0"}, allow_redirects=True)
            if r.status_code in [200, 301, 302, 403]:
                with self.lock:
                    self.alive.add(target)
                return True
        except:
            pass
        with self.lock:
            self.dead.add(target)
        return False

    def verify_all(self, targets, max_verify=500):
        """Verify targets in parallel."""
        to_verify = targets[:max_verify] if max_verify else targets
        console.print(f"\n[bold cyan][VERIFIER][bold cyan] Checking {len(to_verify)} targets...[/bold cyan]")

        with Progress(
            SpinnerColumn(), TextColumn("[progress.description]{task.description}"),
            BarColumn(bar_width=40), TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            TimeElapsedColumn(), console=console
        ) as progress:
            task = progress.add_task("[cyan]Verifying targets...", total=len(to_verify))

            with ThreadPoolExecutor(max_workers=min(THREADS, len(to_verify))) as executor:
                futures = {executor.submit(self.verify_single, t): t for t in to_verify}
                for future in concurrent.futures.as_completed(futures):
                    progress.update(task, advance=1)
                    future.result()

        return list(self.alive)


# ═══════════════════════════════════════════════════════════════
# MAIN ACQUIRER
# ═══════════════════════════════════════════════════════════════

def acquire_targets():
    """Main function: fetch, verify, deduplicate, save to list.txt."""
    console.clear()
    console.print(Panel.fit(
        "[bold white]GROOTX TARGET ACQUIRER v1.0[/bold white]\n"
        "[cyan]Auto Google Dork + Shodan Target Fetcher[/cyan]\n"
        "[bold]Pipeline: GOOGLE → SHODAN → VERIFY → DEDUP → SAVE[/bold]",
        title="[bold]TARGET ACQUISITION[/bold]"
    ))

    all_targets = set()

    # Phase 1: Google Dork Fetching
    google = GoogleFetcher()
    google_targets = google.fetch_all()
    all_targets.update(google_targets)

    if not google_targets:
        console.print("[yellow]No Google targets found. Continuing with Shodan...[/yellow]")

    # Phase 2: Shodan Fetching
    shodan = ShodanFetcher()
    shodan_targets = shodan.fetch_all()
    all_targets.update(shodan_targets)

    if not shodan_targets:
        console.print("[yellow]No Shodan targets found either. Using default...[/yellow]")

    # If still nothing, use a basic fallback
    if not all_targets:
        console.print("[yellow]No targets acquired. Creating minimal list...[/yellow]")
        all_targets.add("http://example.com")

    # Deduplicate
    all_targets = list(set(all_targets))
    console.print(f"\n[green]Total unique targets acquired: {len(all_targets)}[/green]")

    # Phase 3: Verify (only first 500 to save time)
    if len(all_targets) > 500:
        console.print(f"[yellow]Large target list ({len(all_targets)}). Verifying first 500...[/yellow]")

    verifier = TargetVerifier()
    alive = verifier.verify_all(all_targets)

    # Phase 4: Save
    alive_sorted = sorted(alive)
    with open(LIST_FILE, "w") as f:
        for target in alive_sorted:
            f.write(target + "\n")

    # Save JSON for reference
    result_data = {
        "total_acquired": len(all_targets),
        "alive": len(alive),
        "dead": len(all_targets) - len(alive),
        "acquired_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "targets": alive_sorted,
        "sources": {
            "google": len(google_targets),
            "shodan": len(shodan_targets),
        }
    }
    with open(RESULTS_FILE, "w") as f:
        json.dump(result_data, f, indent=2)

    console.print(f"\n[bold green][+] Results saved to {LIST_FILE} ({len(alive_sorted)} targets)[/bold green]")
    console.print(f"[cyan]Reference: {RESULTS_FILE}[/cyan]")
    console.print(f"\n[bold]═══ SUMMARY ═══[/bold]")
    console.print(f"  Google targets: {len(google_targets)}")
    console.print(f"  Shodan targets: {len(shodan_targets)}")
    console.print(f"  Unique total: {len(all_targets)}")
    console.print(f"  Alive: {len(alive)}")
    console.print(f"  Dead: {len(all_targets) - len(alive)}")
    console.print(f"\n[cyan]Now run: python3 mass_auto_shell_v2.py[/cyan]")

    return alive_sorted


if __name__ == "__main__":
    acquire_targets()