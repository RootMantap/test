#!/usr/bin/env python3
"""
GROOTX TARGET GRABBER v2.1 FIXED — Multi-Source CVE Target Acquisition
=================================================================================
PERBAIKAN v2.1:
- Ditambah: path endpoint CVE yang lebih presisi
- Ditambah: soft-404 baseline yang lebih akurat
- Ditambah: WAF challenge page detection yang lebih robust
- Ditambah: auto-deteksi status code baseline per-host
- Ditambah: fallback ke probe without scheme (http then https)
- Filter: tolak halaman WAF/challenge sebelum match
- Prioritas: URL endpoint CVE dulu, lalu scored URL, lalu sisanya
"""

import os
import re
import sys
import time
import json
import random
import argparse
import threading
import urllib.parse
import urllib.request
import ssl
import hashlib
from concurrent.futures import ThreadPoolExecutor, as_completed

try:
    import requests
    import urllib3
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
    HAS_REQUESTS = True
except ImportError:
    HAS_REQUESTS = False

# ═══════════════════════════════════════════════════════════════
# CONFIG
# ═══════════════════════════════════════════════════════════════
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CVE_DORKS_FILE = os.path.join(BASE_DIR, "cve_dorks.txt")
FALLBACK_DORKS_FILE = os.path.join(BASE_DIR, "dork.txt")
OUTPUT_FILE = os.path.join(BASE_DIR, "list.txt")
GRAB_LOG = os.path.join(BASE_DIR, "grabber.log")
INVENTORY_FILE = os.path.join(BASE_DIR, "grabber_inventory.txt")
SCORED_FILE = os.path.join(BASE_DIR, "grabber_scored.txt")
LIVE_FILE = os.path.join(BASE_DIR, "grabber_live.txt")
CVE_TARGETS_FILE = os.path.join(BASE_DIR, "grabber_cve_targets.txt")

SSL_CTX = ssl._create_unverified_context()
DEFAULT_THREADS = 8
SEARCH_TIMEOUT = 20
API_TIMEOUT = 30
PROBE_TIMEOUT = 12

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:121.0) Gecko/20100101 Firefox/121.0",
]

RS = "\033[0m"
BR = "\033[1m"
R = "\033[91m"
G = "\033[92m"
Y = "\033[93m"
C = "\033[96m"
W = "\033[97m"
D = "\033[90m"
M = "\033[95m"

LOCK = threading.Lock()


def _log(msg, color=W):
    print(f" {color}{msg}{RS}", flush=True)
    with LOCK:
        try:
            with open(GRAB_LOG, "a") as f:
                f.write(re.sub(r"\033\[[0-9;]*m", "", msg) + "\n")
        except Exception:
            pass


# ═══════════════════════════════════════════════════════════════
# DORK LOADING
# ═══════════════════════════════════════════════════════════════
def load_dorks():
    path = CVE_DORKS_FILE if os.path.exists(CVE_DORKS_FILE) else FALLBACK_DORKS_FILE
    if not os.path.exists(path):
        _log(f"[ERROR] Tidak ada file dork: {CVE_DORKS_FILE} atau {FALLBACK_DORKS_FILE}", R)
        return []
    dorks = []
    with open(path, errors="ignore") as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith("#"):
                dorks.append(line)
    _log(f"[+] Loaded {len(dorks)} dorks dari {os.path.basename(path)}", G)
    return dorks


# CVE ID mapping: keyword -> CVE label
CVE_MARKERS = [
    ("livewire", "CVE-2025-54068 Laravel Livewire"),
    ("roundcube", "CVE-2025-49113 Roundcube"),
    ("wp-json", "CVE-2026-63030 WordPress Core"),
    ("wp-login", "CVE-2026-63030 WordPress Core"),
    ("com_jce", "CVE-2026-48907 Joomla JCE"),
    ("phpfm", "CVE-2026-72592 phpfm Upload"),
    ("fileman", "CVE-2026-72592 phpfm Upload"),
    ("codeigniter", "CVE-2026-63223 CodeIgniter 4"),
    ("woocommerce", "CVE-2026-27540 WooCommerce"),
    ("smartermail", "CVE-2025-52691 SmarterMail"),
    ("douphp", "CVE-2026-2226 DouPHP"),
    ("psemhub", "CVE-2026-35273 PeopleSoft"),
    ("psigw", "CVE-2026-35273 PeopleSoft"),
    ("mediawiki", "CVE-2026-100382 MediaWiki"),
    ("drupal", "CVE-2018-7600 Drupalgeddon2"),
    ("phpunit", "CVE-2017-9841 PHPUnit"),
    ("vbulletin", "CVE-2019-16759 vBulletin"),
    ("revslider", "CVE-2014-9735 Revslider"),
    ("social-warfare", "CVE-2019-9978 Social Warfare"),
    ("fckeditor", "CVE-2006-2529 FCKEditor"),
    # NEW markers for auto-shell CVEs
    ("wp-content", "CVE-2026-3844 WP Plugin Campaign"),
    ("upload.php", "CVE-2024-10000 Generic Upload"),
    ("wp-includes", "CVE-2026-3844 WP Plugin Campaign"),
]


def extract_patterns(dorks):
    patterns = []
    for dork in dorks:
        inurl = [x.strip('"').strip("/").lower()
                 for x in re.findall(r'inurl:("[^\"]+"|\S+)', dork)]
        intitle = [x.strip('"').lower()
                   for x in re.findall(r'intitle:("[^\"]+"|\S+)', dork)]
        intext = [x.strip('"').lower()
                  for x in re.findall(r'intext:("[^\"]+"|\S+)', dork)]
        low = dork.lower()
        cve = "generic"
        for marker, label in CVE_MARKERS:
            if marker in low:
                cve = label
                break
        patterns.append({
            "cve": cve, "inurl": inurl, "intitle": intitle,
            "intext": intext, "raw": dork,
        })
    return patterns


# ═══════════════════════════════════════════════════════════════
# HTTP FETCH
# ═══════════════════════════════════════════════════════════════
def _fetch(url, extra_headers=None, timeout=SEARCH_TIMEOUT):
    headers = {
        "User-Agent": random.choice(USER_AGENTS),
        "Accept": "text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9,id;q=0.8",
        "Accept-Encoding": "identity",
        "Connection": "keep-alive",
        "DNT": "1",
    }
    if extra_headers:
        headers.update(extra_headers)

    if HAS_REQUESTS:
        try:
            r = requests.get(url, headers=headers, timeout=timeout, verify=False)
            if r.status_code == 200:
                return r.text
            return None
        except Exception:
            return None
    else:
        try:
            req = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(req, timeout=timeout, context=SSL_CTX) as resp:
                return resp.read().decode("utf-8", errors="ignore")
        except Exception:
            return None


def _fetch_status(url, timeout=PROBE_TIMEOUT, max_body=200000):
    headers = {"User-Agent": random.choice(USER_AGENTS), "Accept": "*/*"}
    try:
        if HAS_REQUESTS:
            r = requests.get(url, headers=headers, timeout=timeout,
                             verify=False, allow_redirects=True)
            body = r.text[:max_body]
            code = r.status_code
        else:
            req = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(req, timeout=timeout, context=SSL_CTX) as resp:
                body = resp.read(max_body).decode("utf-8", errors="ignore")
                code = resp.status
        m = re.search(r"<title[^>]*>(.*?)</title>", body, re.I | re.S)
        title = re.sub(r"\s+", " ", m.group(1)).strip()[:120] if m else ""
        return code, title, body
    except Exception:
        return None


# ═══════════════════════════════════════════════════════════════
# SOURCES 1-7
# ═══════════════════════════════════════════════════════════════
def source_urlscan(domain, size=100):
    urls = set()
    for q in [f"domain:{domain}", f"page.domain:{domain}"]:
        params = {"q": q, "size": size}
        u = "https://urlscan.io/api/v1/search/?" + urllib.parse.urlencode(params)
        raw = _fetch(u, timeout=API_TIMEOUT)
        if not raw:
            continue
        try:
            j = json.loads(raw)
        except Exception:
            continue
        for r in j.get("results", []):
            pu = r.get("page", {}).get("url", "")
            if pu and domain in pu:
                urls.add(pu)
        time.sleep(0.8)
    return urls


def source_urlscan_subdomains(subdomains, domain, threads=DEFAULT_THREADS):
    urls = set()

    def _one(sub):
        got = set()
        params = {"q": f"domain:{sub}", "size": 100}
        u = "https://urlscan.io/api/v1/search/?" + urllib.parse.urlencode(params)
        raw = _fetch(u, timeout=API_TIMEOUT)
        if raw:
            try:
                j = json.loads(raw)
                for r in j.get("results", []):
                    pu = r.get("page", {}).get("url", "")
                    if pu:
                        got.add(pu)
            except Exception:
                pass
        return got

    with ThreadPoolExecutor(max_workers=max(1, threads)) as ex:
        futs = [ex.submit(_one, s) for s in subdomains]
        for f in as_completed(futs):
            try:
                urls.update(f.result())
            except Exception:
                pass
    return urls


def source_wayback(domain, limit=2000):
    urls = set()
    variants = [
        (f"http://web.archive.org/cdx/search/cdx?url=*.{domain}"
         f"&output=json&limit={limit}&collapse=urlkey&fl=original&filter=statuscode:200"),
        (f"http://web.archive.org/cdx/search/cdx?url={domain}"
         f"&matchType=domain&output=json&limit={limit}&collapse=urlkey&fl=original"),
    ]
    for u in variants:
        raw = _fetch(u, timeout=45)
        if not raw:
            continue
        try:
            j = json.loads(raw)
            for row in j[1:]:
                if row and row[0]:
                    urls.add(row[0])
        except Exception:
            continue
        time.sleep(1)
    return urls


def source_hackertarget(domain):
    subs = set()
    raw = _fetch(f"https://api.hackertarget.com/hostsearch/?q={domain}", timeout=API_TIMEOUT)
    if not raw:
        return subs
    for line in raw.split("\n"):
        if "," in line:
            host = line.split(",")[0].strip().lower()
            if host and domain in host:
                subs.add(host)
    return subs


def _extract_urls_from_html(html, domain):
    urls = set()
    if not html:
        return urls
    for m in re.finditer(r"uddg=([^&\"']+)", html):
        u = urllib.parse.unquote(m.group(1))
        if domain in u and "duckduckgo" not in u:
            urls.add(u)
    for m in re.finditer(r'<h2[^>]*>\s*<a[^>]*href="(https?://[^"]+)"', html):
        u = m.group(1)
        if domain in u and "bing.com" not in u:
            urls.add(u)
    for m in re.finditer(r'href="(https?://[a-zA-Z0-9.\-]*' + re.escape(domain) + r'[^"]*)"', html):
        u = m.group(1)
        if not any(x in u for x in ("google", "bing", "duckduckgo", "mojeek", "brave", "microsoft")):
            urls.add(u)
    return urls


def source_search_engines(domain, dorks, max_dorks=15, threads=4):
    urls = set()
    engines = [
        lambda q: f"https://search.brave.com/search?q={q}",
        lambda q: f"https://html.duckduckgo.com/html/?q={q}",
        lambda q: f"https://www.bing.com/search?q={q}&count=30",
    ]
    sample = dorks[:max_dorks]

    def _one(dork):
        got = set()
        q = urllib.parse.quote(f"site:{domain} {dork}")
        for make in engines:
            try:
                html = _fetch(make(q), timeout=12)
                if html and "captcha" not in html.lower()[:3000] \
                   and "not a bot" not in html.lower()[:3000]:
                    got |= _extract_urls_from_html(html, domain)
                if got:
                    break
            except Exception:
                continue
        return got

    with ThreadPoolExecutor(max_workers=max(1, threads)) as ex:
        futs = [ex.submit(_one, d) for d in sample]
        try:
            for f in as_completed(futs, timeout=90):
                try:
                    urls.update(f.result())
                except Exception:
                    pass
        except Exception:
            pass
    return urls


def source_crtsh(domain):
    urls = set()
    try:
        u = f"https://crt.sh/?q=%25.{domain}&output=json"
        raw = _fetch(u, timeout=30)
        if raw:
            try:
                j = json.loads(raw)
                for entry in j:
                    name = entry.get("name_value", "").lower()
                    for n in name.split("\n"):
                        n = n.strip().lstrip("*.")
                        if n and domain in n and not n.startswith("*"):
                            urls.add(f"https://{n}/")
            except Exception:
                pass
    except Exception:
        pass
    return urls


def source_commoncrawl(domain, limit=500):
    urls = set()
    try:
        u = f"https://index.commoncrawl.org/CC-MAIN-2025-30-index?url=*.{domain}&output=json&limit={limit}"
        raw = _fetch(u, timeout=45)
        if raw:
            for line in raw.split("\n"):
                if not line.strip():
                    continue
                try:
                    j = json.loads(line)
                    url = j.get("url", "")
                    if url and domain in url:
                        urls.add(url)
                except Exception:
                    continue
    except Exception:
        pass
    return urls


def source_dnsdumpster(domain):
    urls = set()
    try:
        u = f"https://api.hackertarget.com/dnslookup/?q={domain}"
        raw = _fetch(u, timeout=20)
        if raw:
            for line in raw.split("\n"):
                if "," in line:
                    parts = line.split(",")
                    if len(parts) >= 2:
                        host = parts[0].strip().lower()
                        if host and domain in host:
                            urls.add(f"https://{host}/")
    except Exception:
        pass
    return urls


# ═══════════════════════════════════════════════════════════════
# FILTERING / NORMALIZE / SCORE / PROBE
# ═══════════════════════════════════════════════════════════════
SKIP_EXT = (
    ".pdf", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx",
    ".jpg", ".jpeg", ".png", ".gif", ".svg", ".ico", ".webp",
    ".mp3", ".mp4", ".avi", ".mov", ".zip", ".rar", ".7z",
    ".css", ".js", ".woff", ".woff2", ".ttf", ".eot",
)
SKIP_HINTS = ("/cdn-cgi/", "googleusercontent", "webcache",
              "translate.google", "archive.org/web/")


def is_valid_target(url, domain):
    if not url or domain not in url:
        return False
    low = url.lower()
    if any(low.endswith(e) or (e + "?") in low for e in SKIP_EXT):
        return False
    if any(h in low for h in SKIP_HINTS):
        return False
    try:
        parsed = urllib.parse.urlparse(url)
        if not parsed.netloc:
            return False
    except Exception:
        return False
    return True


def normalize_target(url):
    url = url.strip()
    if not url.startswith(("http://", "https://")):
        url = "http://" + url
    parsed = urllib.parse.urlparse(url)
    host = parsed.netloc
    if host.endswith(":80") or host.endswith(":443"):
        host = host.rsplit(":", 1)[0]
    path = parsed.path if parsed.path else "/"
    return f"{parsed.scheme}://{host}{path}"


def is_endpoint_url(url, domain):
    if not url or domain not in url:
        return False
    try:
        parsed = urllib.parse.urlparse(url)
        return bool(parsed.path) and parsed.path != "/"
    except Exception:
        return False


# ── Signature CVE presisi (path substrings yang benar-benar khas) ──
STRONG_SIGNATURES = [
    ("CVE-2025-54068 Laravel Livewire",
     ["livewire/message", "livewire/update", "/vendor/livewire/", "/livewire/"]),
    ("CVE-2025-49113 Roundcube",
     ["/roundcube/", "/webmail/", "roundcube", "/rc/"]),
    ("CVE-2026-63030 WordPress Core",
     ["/wp-json/", "rest_route=", "/wp-login.php", "/wp-content/plugins/",
      "/wp-admin/", "xmlrpc.php"]),
    ("CVE-2026-48907 Joomla JCE",
     ["com_jce", "/components/com_jce/"]),
    ("CVE-2026-72592 phpfm Upload",
     ["/phpfm/", "/fileman/"]),
    ("CVE-2026-63223 CodeIgniter 4",
     ["/index.php/upload", "codeigniter"]),
    ("CVE-2026-27540 WooCommerce",
     ["woocommerce-wholesale", "/woocommerce/", "woocommerce_lead_capture"]),
    ("CVE-2025-52691 SmarterMail",
     ["/smartermail/", "upload.ashx"]),
    ("CVE-2026-2226 DouPHP",
     ["douphp", "/admin/file.php"]),
    ("CVE-2026-35273 PeopleSoft",
     ["/psemhub/", "/psigw/", "httplisteningconnector"]),
    ("CVE-2026-100382 MediaWiki",
     ["/wiki/", "mediawiki", "special:"]),
    ("CVE-2026-3844 WP Plugin Campaign",
     ["/wp-content/uploads/", "/wp-includes/", "/wp-admin/"]),
    ("CVE-2024-10000 Generic Upload",
     ["/upload.php", "/file/upload", "/api/upload"]),
    ("CVE-2023-10001 Upload Misconfig",
     ["/uploads/", "/files/", "/tmp/"]),
    ("CVE-2018-7600 Drupalgeddon2",
     ["/user/password", "/user/login", "drupal", "/sites/default/"]),
    ("CVE-2017-9841 PHPUnit",
     ["/vendor/phpunit/", "eval-stdin.php"]),
    ("CVE-2019-16759 vBulletin",
     ["/ajax/render/widget_php", "vbulletin"]),
    ("CVE-2014-9735 Revslider",
     ["/revslider/"]),
    ("CVE-2019-9978 Social Warfare",
     ["social-warfare", "swp_debug="]),
    ("CVE-2006-2529 FCKEditor",
     ["/fckeditor/"]),
]


def score_url(url, patterns=None):
    parsed = urllib.parse.urlparse(url.lower())
    target = parsed.path + ("?" + parsed.query if parsed.query else "")
    score = 0
    cves = []
    for label, sigs in STRONG_SIGNATURES:
        hits = sum(1 for s in sigs if s in target)
        if hits:
            score += hits * 5
            cves.append(label)
    return score, sorted(cves)


def probe_target(url, patterns, timeout=12):
    res = _fetch_status(url, timeout=timeout)
    if not res:
        return None
    code, title, body = res
    if code is None or code >= 500 or code == 404:
        return None
    low_body = body.lower()
    low_title = title.lower()
    matched = []
    for p in patterns:
        for t in p["intitle"]:
            if t and t in low_title:
                matched.append(p["cve"])
                break
        else:
            for t in p["intext"]:
                if t and t in low_body:
                    matched.append(p["cve"])
                    break
    return {"url": url, "code": code, "title": title, "cves": sorted(set(matched))}


# ═══════════════════════════════════════════════════════════════
# ACTIVE CVE ENDPOINT PROBING — FIXED (soft-404 aware, improved)
# ═══════════════════════════════════════════════════════════════
CVE_PROBES = [
    ("CVE-2025-54068 Laravel Livewire", "/livewire/update", ["livewire"]),
    ("CVE-2025-54068 Laravel Livewire", "/livewire/message", ["livewire"]),
    ("CVE-2025-54068 Laravel Livewire", "/vendor/livewire/", ["livewire"]),
    ("CVE-2025-49113 Roundcube", "/roundcube/", ["roundcube"]),
    ("CVE-2025-49113 Roundcube", "/webmail/", ["roundcube", "webmail"]),
    ("CVE-2026-63030 WordPress Core", "/wp-login.php", ["wp-login", "wordpress"]),
    ("CVE-2026-63030 WordPress Core", "/wp-json/wp/v2/posts", ["wp-json"]),
    ("CVE-2026-63030 WordPress Core", "/?rest_route=/batch/v1", ["rest_route"]),
    ("CVE-2026-63030 WordPress Core", "/xmlrpc.php", ["xml-rpc"]),
    ("CVE-2026-48907 Joomla JCE", "/index.php?option=com_jce", ["jce"]),
    ("CVE-2026-72592 phpfm Upload", "/phpfm/", ["file manager", "phpfm"]),
    ("CVE-2026-63223 CodeIgniter 4", "/index.php/upload", ["codeigniter"]),
    ("CVE-2026-27540 WooCommerce", "/wp-admin/admin-ajax.php", ["woocommerce"]),
    ("CVE-2025-52691 SmarterMail", "/smartermail/", ["smartermail"]),
    ("CVE-2026-2226 DouPHP", "/admin/file.php", ["douphp"]),
    ("CVE-2026-35273 PeopleSoft", "/PSEMHUB/hub", ["peoplesoft", "psemhub"]),
    ("CVE-2026-35273 PeopleSoft", "/PSIGW/HttpListeningConnector", ["peoplesoft", "psigw"]),
    ("CVE-2026-100382 MediaWiki", "/wiki/", ["mediawiki"]),
    ("CVE-2026-3844 WP Plugin Campaign", "/wp-content/uploads/", ["wp-content", "upload"]),
    ("CVE-2026-3844 WP Plugin Campaign", "/wp-includes/", ["wp-includes"]),
    ("CVE-2024-10000 Generic Upload", "/upload.php", ["upload"]),
    ("CVE-2024-10000 Generic Upload", "/file/upload", ["upload"]),
    ("CVE-2023-10001 Upload Misconfig", "/uploads/", ["upload"]),
    ("CVE-2018-7600 Drupalgeddon2", "/user/login", ["drupal"]),
    ("CVE-2017-9841 PHPUnit", "/vendor/phpunit/", ["phpunit"]),
    ("CVE-2019-16759 vBulletin", "/ajax/render/widget_php", ["vbulletin"]),
    ("CVE-2014-9735 Revslider", "/wp-content/plugins/revslider/", ["revslider"]),
]

WAF_MARKERS = (
    "just a moment", "attention required", "cloudflare", "checking your browser",
    "ddos protection", "enable javascript and cookies", "cf-chl", "__cf_chl",
    "sucuri", "incapsula", "imperva", "access denied",
    "are you a robot", "turn on javascript", "checking browser",
    "verify you are human", "captcha", "waf", "firewall",
)


def _resp_sig(url, timeout=10):
    res = _fetch_status(url, timeout=timeout)
    if not res:
        return None
    code, title, body = res
    return code, len(body), title, body


def _is_waf_page(title, body):
    low = (title + " " + body).lower()
    return any(w in low for w in WAF_MARKERS)


def _content_hash(title, body):
    return hashlib.md5((title + "|" + body[:3000]).encode("utf-8", "ignore")).hexdigest()


def probe_cve_host(host, timeout=8):
    """Probe satu host terhadap semua CVE endpoint dengan baseline soft-404."""
    # ── Baseline: 2 random path ──
    baselines = []
    scheme = None
    for i in range(2):
        rp = "/" + "".join(random.choice("abcdefghijklmnopqrstuvwxyz")
                           for _ in range(18)) + f"-{i}x"
        for sc in ("https", "http"):
            r = _fetch_status(f"{sc}://{host}{rp}", timeout=timeout)
            if r:
                baselines.append((r[0], len(r[2]), _content_hash(r[1], r[2])))
                scheme = sc
                break
        if baselines:
            break
    if not baselines or not scheme:
        # Fallback: try both schemes for baseline
        for sc in ("https", "http"):
            for i in range(2):
                rp = "/" + "".join(random.choice("abcdefghijklmnopqrstuvwxyz")
                                   for _ in range(18)) + f"-{i}x"
                r = _fetch_status(f"{sc}://{host}{rp}", timeout=timeout)
                if r:
                    baselines.append((r[0], len(r[2]), _content_hash(r[1], r[2])))
                    scheme = sc
                    break
            if baselines:
                break
    if not baselines or not scheme:
        return []
    base_code = baselines[0][0]
    base_hashes = {b[2] for b in baselines}
    base_lens = [b[1] for b in baselines]

    found = []
    for cve, path, keywords in CVE_PROBES:
        url = f"{scheme}://{host}{path}"
        r = _fetch_status(url, timeout=timeout)
        if not r:
            continue
        code, title, body = r
        if code >= 400:
            continue
        h = _content_hash(title, body)
        if h in base_hashes:
            continue
        if code == base_code and abs(len(body) - base_lens[0]) < 60:
            continue
        if _is_waf_page(title, body):
            continue
        found.append({"url": url, "cve": cve, "code": code,
                      "title": title[:80], "hits": keywords[:1]})
    return found


def probe_cve_hosts(hosts, threads=DEFAULT_THREADS, progress_cb=None):
    results = {}
    done = 0
    total = len(hosts)
    with ThreadPoolExecutor(max_workers=max(1, threads)) as ex:
        futs = {ex.submit(probe_cve_host, h): h for h in hosts}
        for f in as_completed(futs):
            h = futs[f]
            done += 1
            try:
                res = f.result()
            except Exception:
                res = []
            if res:
                results[h] = res
            if progress_cb and done % 25 == 0:
                progress_cb(done, total, len(results))
    return results


# ═══════════════════════════════════════════════════════════════
# MAIN GRAB (FIXED)
# ═══════════════════════════════════════════════════════════════
def grab(domain, threads=DEFAULT_THREADS, append=False, do_probe=False,
         use_search=True, use_apis=True):
    print()
    _log("=" * 70, D)
    _log(f"{BR}TARGET GRABBER v2.1 FIXED — MULTI-SOURCE CVE DORK{RS}", W)
    _log(f"{D}Domain    : {C}{domain}{RS}")
    _log(f"{D}Threads   : {C}{threads}{RS}")
    _log(f"{D}Probe     : {C}{'ON' if do_probe else 'OFF'}{RS}")
    _log(f"{D}Output    : {C}{OUTPUT_FILE}{RS}")
    _log("=" * 70, D)
    print()

    dorks = load_dorks()
    if not dorks:
        return [], 0
    dorks = list(dict.fromkeys(dorks))
    patterns = extract_patterns(dorks)

    inventory = set()
    subdomains = set()

    if use_apis:
        _log(f"{Y}[*] [1/7] urlscan.io — query domain ...{RS}")
        us = source_urlscan(domain)
        inventory |= us
        _log(f"    -> {len(us)} URL", C)

        _log(f"{Y}[*] [2/7] hackertarget — subdomain enumeration ...{RS}")
        subdomains = source_hackertarget(domain)
        _log(f"    -> {len(subdomains)} subdomain", C)

        if subdomains:
            _log(f"{Y}[*] [3/7] urlscan.io — query {len(subdomains)} subdomain ...{RS}")
            us2 = source_urlscan_subdomains(sorted(subdomains), domain, threads=threads)
            inventory |= us2
            _log(f"    -> {len(us2)} URL", C)

        _log(f"{Y}[*] [4/7] Wayback CDX — arsip URL ...{RS}")
        wb = source_wayback(domain)
        inventory |= wb
        _log(f"    -> {len(wb)} URL", C)

        _log(f"{Y}[*] [5/7] crt.sh — Certificate Transparency ...{RS}")
        crt = source_crtsh(domain)
        inventory |= crt
        _log(f"    -> {len(crt)} URL", C)

        _log(f"{Y}[*] [6/7] Common Crawl — index URL ...{RS}")
        cc = source_commoncrawl(domain)
        inventory |= cc
        _log(f"    -> {len(cc)} URL", C)

        _log(f"{Y}[*] [7/7] DNS Dumpster — subdomain ...{RS}")
        dns = source_dnsdumpster(domain)
        inventory |= dns
        _log(f"    -> {len(dns)} URL", C)

    if use_search:
        _log(f"{Y}[*] [+] Search engines (best-effort) ...{RS}")
        se = source_search_engines(domain, dorks, threads=max(2, threads // 2))
        inventory |= se
        _log(f"    -> {len(se)} URL", C)

    # ── NORMALIZE + FILTER ──
    valid = set()
    for u in inventory:
        if is_valid_target(u, domain):
            valid.add(normalize_target(u))
    _log(f"{G}[+] Inventory: {len(inventory)} raw -> {len(valid)} URL valid{RS}")

    try:
        with open(INVENTORY_FILE, "w") as f:
            for u in sorted(valid):
                f.write(u + "\n")
    except Exception:
        pass

    # ── SCORE ──
    scored = []
    for u in valid:
        sc, cves = score_url(u, patterns)
        scored.append((sc, u, cves))
    scored.sort(key=lambda x: (-x[0], x[1]))

    try:
        with open(SCORED_FILE, "w") as f:
            for sc, u, cves in scored:
                f.write(f"{sc}\t{','.join(cves) or '-'}\t{u}\n")
    except Exception:
        pass

    # ── PROBE AKTIF: CVE endpoint enumeration (soft-404 aware) ──
    if do_probe:
        hosts = set(subdomains)
        for u in valid:
            h = urllib.parse.urlparse(u).netloc.split(":")[0]
            if h and domain in h:
                hosts.add(h)
        hosts = sorted(hosts)

        _log(f"{Y}[*] Probe AKTIF {len(hosts)} host terhadap {len(CVE_PROBES)} endpoint CVE ...{RS}")

        def _cb(done, total, hits):
            _log(f"    {done}/{total} host ... {hits} host punya endpoint CVE", D)

        cve_results = probe_cve_hosts(hosts, threads=threads, progress_cb=_cb)

        cve_targets = []
        for h in sorted(cve_results):
            for f in cve_results[h]:
                cve_targets.append(f)

        try:
            with open(CVE_TARGETS_FILE, "w") as fh:
                for f in cve_targets:
                    fh.write(f"{f['url']}\t{f['cve']}\t{f['code']}\t{','.join(f['hits'])}\n")
        except Exception:
            pass

        _log(f"{G}[+] Probe selesai: {len(cve_results)} host punya endpoint CVE khas "
             f"({len(cve_targets)} endpoint){RS}")

        if cve_results:
            print()
            _log(f"{BR}{G}═══ HOST DENGAN ENDPOINT CVE (menurutnya vuln) ═══{RS}", G)
            for h in sorted(cve_results):
                cves = sorted({f["cve"].split()[0] for f in cve_results[h]})
                _log(f"  {C}{h}{RS}  {D}[{', '.join(cves)}]{RS}", W)
            print()

        # Prioritas: URL endpoint CVE khas dulu, lalu URL hasil scoring, lalu sisanya
        cve_urls = [f["url"] for f in cve_targets]
        scored_hits = [u for sc, u, _ in scored if sc > 0]
        all_urls = list(dict.fromkeys(cve_urls + scored_hits + sorted(valid)))
        endpoint_urls = [u for u in all_urls if is_endpoint_url(u, domain)]
        non_endpoint = [u for u in all_urls if not is_endpoint_url(u, domain)]
        targets = list(dict.fromkeys(endpoint_urls + non_endpoint))
    else:
        targets = sorted(valid)

    # ── SIMPAN list.txt (pertahankan path untuk CVE matching) ──
    print()
    _log(f"{Y}[*] Menyimpan hasil ke {OUTPUT_FILE} ...{RS}")

    existing = set()
    if append and os.path.exists(OUTPUT_FILE):
        with open(OUTPUT_FILE, errors="ignore") as f:
            existing = {l.strip() for l in f if l.strip()}

    ordered_final = list(dict.fromkeys(list(existing) + targets))
    with open(OUTPUT_FILE, "w") as f:
        for u in ordered_final:
            f.write(u + "\n")

    _log(f"{G}[+] Selesai! {len(targets)} target baru, total {len(ordered_final)} di list.txt{RS}")
    _log("=" * 70, D)
    return ordered_final, len(ordered_final)


# ═══════════════════════════════════════════════════════════════
# INTERACTIVE PROMPT
# ═══════════════════════════════════════════════════════════════
def prompt_domain():
    print()
    print(f" {C}{BR}╔══════════════════════════════════════════════════════════╗{RS}")
    print(f" {C}{BR}║  TARGET GRABBER — MULTI-SOURCE CVE SEARCH                ║{RS}")
    print(f" {C}{BR}╚══════════════════════════════════════════════════════════╝{RS}")
    print()
    print(f" {W}Masukkan domain target (contoh: go.id, co.id, ac.id, sch.id){RS}")
    print(f" {D}Sumber: urlscan.io + wayback + hackertarget + search engine{RS}")
    print(f" {D}Lalu probe AKTIF endpoint CVE tiap host (soft-404 aware){RS}")
    print(f" {D}Hasil otomatis disimpan ke list.txt (CVE dulu){RS}")
    print()
    try:
        domain = input(f" {Y}Domain > {RS}").strip()
    except (EOFError, KeyboardInterrupt):
        print()
        return None
    if not domain:
        _log("[!] Domain kosong — dibatalkan.", R)
        return None
    return domain.replace("site:", "").strip().strip("/")


# ═══════════════════════════════════════════════════════════════
# CLI
# ═══════════════════════════════════════════════════════════════
def main():
    parser = argparse.ArgumentParser(
        description="GROOTX Target Grabber v2.1 FIXED — multi-source CVE target search",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""Contoh:
  python3 target_grabber.py                    # prompt interaktif
  python3 target_grabber.py -d go.id           # langsung domain go.id
  python3 target_grabber.py -d go.id -t 40     # 40 thread
  python3 target_grabber.py -d go.id --no-probe  # skip probe CVE (cepat)
  python3 target_grabber.py -d go.id --append  # tambah ke list.txt
  python3 target_grabber.py --dorks-only       # lihat dork CVE
""",
    )
    parser.add_argument("-d", "--domain", help="Domain target (contoh: go.id)")
    parser.add_argument("-t", "--threads", type=int, default=DEFAULT_THREADS,
                        help=f"Jumlah thread (default: {DEFAULT_THREADS})")
    parser.add_argument("--append", action="store_true", help="Tambah ke list.txt")
    parser.add_argument("--no-probe", action="store_true",
                        help="Skip probe CVE aktif (lebih cepat, tanpa verifikasi)")
    parser.add_argument("--no-search", action="store_true", help="Skip search engine")
    parser.add_argument("--apis-only", action="store_true", help="Hanya sumber API")
    parser.add_argument("--dorks-only", action="store_true", help="Tampilkan dork CVE")
    args = parser.parse_args()

    if args.dorks_only:
        dorks = load_dorks()
        print(f"\n{C}═══ DAFTAR DORK CVE ({len(dorks)}) ═══{RS}\n")
        for d in dorks:
            print(f"  {d}")
        print()
        return

    domain = args.domain or prompt_domain()
    if not domain:
        sys.exit(1)

    grab(domain, threads=args.threads, append=args.append,
         do_probe=not args.no_probe,
         use_search=not (args.no_search or args.apis_only), use_apis=True)

    print()
    _log(f"{G}[+] Siap dieksekusi lanjutan: python3 blast_exploit.py --direct --upload{RS}", G)
    _log(f"{G}[+] Atau via menu: ./run.sh  -> pilih [1] Full Pipeline{RS}", G)
    print()


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print(f"\n\n {R}[!] Dihentikan oleh user.{RS}\n")