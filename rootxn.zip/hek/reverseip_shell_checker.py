#!/usr/bin/env python3
"""
REVERSE IP & SHELL CHECKER MODULE v1.0
=======================================
Reverse IP lookup dan shell checker
Diadaptasi dari AlienExploit Tool5 & Tool6
Diintegrasikan ke GROOTX Exploitation Suite
"""

import requests
import re
import os
import sys
import json
import time
import socket
import threading
import urllib3
from concurrent.futures import ThreadPoolExecutor, as_completed
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn, TimeElapsedColumn
from rich.table import Table

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
console = Console()

# ═══════════════════════════════════════════════════════════════
# CONFIGURATION
# ═══════════════════════════════════════════════════════════════
THREADS = 50
TIMEOUT = 10

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36',
    'Connection': 'Keep-Alive'
}

# ═══════════════════════════════════════════════════════════════
# REVERSE IP LOOKUP
# ═══════════════════════════════════════════════════════════════
class ReverseIPLookup:
    """Reverse IP lookup menggunakan hackertarget API."""
    
    def __init__(self):
        self.results = []
    
    def lookup(self, ip):
        """Lookup reverse IP untuk single IP."""
        try:
            ip = ip.strip()
            if not ip:
                return None
            
            # Validate IP
            try:
                socket.inet_aton(ip)
            except:
                return None
            
            # Lookup via hackertarget
            r = requests.get(f'http://api.hackertarget.com/reverseiplookup/?q={ip}', timeout=TIMEOUT, headers=HEADERS)
            if r.status_code == 200 and '.' in r.text:
                domains = [d.strip() for d in r.text.split('\n') if d.strip()]
                result = {
                    'ip': ip,
                    'domains': domains,
                    'count': len(domains)
                }
                self.results.append(result)
                console.print(f"  [green]✓ {ip} -> {len(domains)} domains[/green]")
                return result
            else:
                console.print(f"  [red]✗ {ip} -> No domains found[/red]")
                return None
        except Exception as e:
            console.print(f"  [red]✗ {ip} -> Error: {str(e)[:50]}[/red]")
            return None
    
    def mass_lookup(self, ips, threads=THREADS):
        """Mass reverse IP lookup."""
        console.print(f"\n[bold cyan]MASS REVERSE IP LOOKUP[/bold cyan]")
        console.print(f"  IPs: {len(ips)}")
        console.print(f"  Threads: {threads}")
        
        with Progress(
            SpinnerColumn(), TextColumn("[progress.description]{task.description}"),
            BarColumn(bar_width=40), TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            TimeElapsedColumn(), console=console
        ) as progress:
            task = progress.add_task("[cyan]Looking up...", total=len(ips))
            
            with ThreadPoolExecutor(max_workers=threads) as executor:
                futures = {executor.submit(self.lookup, ip): ip for ip in ips}
                for future in as_completed(futures):
                    progress.update(task, advance=1)
                    try:
                        future.result()
                    except:
                        pass
        
        # Summary
        console.print(f"\n[bold green]REVERSE IP LOOKUP COMPLETE[/bold green]")
        console.print(f"  Total IPs: {len(ips)}")
        console.print(f"  Found: {len(self.results)}")
        
        if self.results:
            table = Table(title="Reverse IP Results")
            table.add_column("IP", width=20)
            table.add_column("Domains", justify="right", width=10)
            table.add_column("Sample Domains", width=50)
            for r in self.results[:20]:
                table.add_row(r['ip'], str(r['count']), ', '.join(r['domains'][:3]))
            console.print(table)
        
        # Save results
        os.makedirs('result', exist_ok=True)
        with open('result/reverse_ip_results.json', 'w') as f:
            json.dump(self.results, f, indent=2)
        
        return self.results


# ═══════════════════════════════════════════════════════════════
# SHELL CHECKER
# ═══════════════════════════════════════════════════════════════
class ShellChecker:
    """Shell checker untuk cek shell hidup/mati."""
    
    def __init__(self):
        self.alive = []
        self.dead = []
        self.lock = threading.Lock()
    
    def check(self, url):
        """Check apakah shell hidup."""
        try:
            url = url.strip().rstrip('/')
            if not url.startswith(('http://', 'https://')):
                url = 'http://' + url
            
            r = requests.get(url, headers=HEADERS, timeout=TIMEOUT, verify=False)
            
            if r.status_code == 200 and len(r.text) > 5:
                with self.lock:
                    self.alive.append(url)
                console.print(f"  [green]✓ ALIVE: {url}[/green]")
                return True, url, r.status_code, len(r.text)
            else:
                with self.lock:
                    self.dead.append(url)
                console.print(f"  [red]✗ DEAD: {url} (Status: {r.status_code})[/red]")
                return False, url, r.status_code, len(r.text) if r.text else 0
        except Exception as e:
            with self.lock:
                self.dead.append(url)
            console.print(f"  [red]✗ DEAD: {url} (Error: {str(e)[:30]})[/red]")
            return False, url, 0, 0
    
    def mass_check(self, urls, threads=THREADS):
        """Mass check shells."""
        console.print(f"\n[bold cyan]MASS SHELL CHECK[/bold cyan]")
        console.print(f"  URLs: {len(urls)}")
        console.print(f"  Threads: {threads}")
        
        with Progress(
            SpinnerColumn(), TextColumn("[progress.description]{task.description}"),
            BarColumn(bar_width=40), TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            TimeElapsedColumn(), console=console
        ) as progress:
            task = progress.add_task("[cyan]Checking...", total=len(urls))
            
            with ThreadPoolExecutor(max_workers=threads) as executor:
                futures = {executor.submit(self.check, url): url for url in urls}
                for future in as_completed(futures):
                    progress.update(task, advance=1)
                    try:
                        future.result()
                    except:
                        pass
        
        # Summary
        console.print(f"\n[bold green]SHELL CHECK COMPLETE[/bold green]")
        console.print(f"  Total: {len(urls)}")
        console.print(f"  Alive: {len(self.alive)}")
        console.print(f"  Dead: {len(self.dead)}")
        
        if self.alive:
            table = Table(title="Alive Shells")
            table.add_column("URL", width=60)
            for url in self.alive[:20]:
                table.add_row(url)
            console.print(table)
        
        # Save results
        os.makedirs('result', exist_ok=True)
        with open('result/shell_check_results.json', 'w') as f:
            json.dump({
                'alive': self.alive,
                'dead': self.dead,
                'total': len(urls),
                'alive_count': len(self.alive),
                'dead_count': len(self.dead)
            }, f, indent=2)
        
        return self.alive, self.dead


def main():
    """CLI interface"""
    import argparse
    parser = argparse.ArgumentParser(description="Reverse IP & Shell Checker")
    parser.add_argument("-l", "--list", help="Target list file")
    parser.add_argument("-t", "--target", help="Single target")
    parser.add_argument("--mode", default="shell", choices=["reverse-ip", "shell", "all"])
    parser.add_argument("--threads", type=int, default=THREADS)
    args = parser.parse_args()
    
    targets = []
    if args.list:
        with open(args.list) as f:
            targets = [l.strip() for l in f if l.strip()]
    elif args.target:
        targets = [args.target]
    else:
        console.print("[red]Error: Specify -l list.txt or -t target[/red]")
        return
    
    if args.mode in ('reverse-ip', 'all'):
        lookup = ReverseIPLookup()
        lookup.mass_lookup(targets, args.threads)
    
    if args.mode in ('shell', 'all'):
        checker = ShellChecker()
        checker.mass_check(targets, args.threads)


if __name__ == "__main__":
    main()
