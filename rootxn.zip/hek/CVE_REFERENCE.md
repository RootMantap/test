# CVE Reference - GROOTX v3.2
# Daftar CVE yang benar-benar didukung di toolkit ini

## CVE-2025-54068 — Laravel Livewire v3 RCE
- Type: RCE (weak typing hydration bypass)
- CMS: Laravel Livewire v3.0.0-beta.1 - v3.6.3
- Fixed: v3.6.4
- Auth required: No
- Auto shell: Yes

## CVE-2025-49113 — Roundcube Webmail RCE
- Type: RCE deserialization
- CMS: Roundcube < v1.5.10, 1.6.x < v1.6.11
- Fixed: v1.6.11
- Auth required: Yes
- Auto shell: Yes

## CVE-2026-63030 — WordPress Core RCE (wp2shell)
- Type: RCE REST API batch endpoint logic flaw
- CMS: WordPress 6.9.0-6.9.4, 7.0.0-7.0.1
- Fixed: v6.9.5/v7.0.2
- Auth required: No
- Auto shell: Yes

## CVE-2026-60137 — WordPress Core SQLi → RCE Chain
- Type: RCE chained (SQLi → admin creation → webshell)
- CMS: WordPress 6.9.0-6.9.4, 7.0.0-7.0.1
- Fixed: v6.9.5/v7.0.2
- Auth required: No
- Auto shell: Yes

## CVE-2026-48907 — Joomla JCE RCE
- Type: RCE unauthenticated file upload
- CMS: JCE ≤ v2.9.99.4
- Fixed: v2.9.99.5
- Auth required: No
- Auto shell: Yes

## CVE-2026-72592 — phpfm File Upload RCE
- Type: RCE upload (empty extension filter, no auth)
- CMS: phpfm ≤ v1.8.0
- Fixed: v1.8.1
- Auth required: No
- Auto shell: Yes

## CVE-2026-63223 — CodeIgniter 4 File Upload RCE
- Type: RCE upload (magic bytes bypass)
- CMS: CodeIgniter 4 < v4.7.4
- Fixed: v4.7.4
- Auth required: No
- Auto shell: Yes

## CVE-2026-27540 — WooCommerce Lead Capture RCE
- Type: RCE upload (AJAX file upload PHP bypass)
- CMS: WooCommerce Wholesale Lead Capture ≤ v2.0.3.1
- Fixed: v2.0.3.2
- Auth required: No
- Auto shell: Yes

## CVE-2025-52691 — SmarterMail RCE
- Type: RCE upload (path traversal)
- CMS: SmarterMail (multiple versions)
- Fixed: latest
- Auth required: No
- Auto shell: Yes

## CVE-2026-2226 — DouPHP ZIP Unrestricted Upload RCE
- Type: RCE upload (ZIP sql_filename bypass)
- CMS: DouPHP ≤ v1.9
- Fixed: latest
- Auth required: No
- Auto shell: Yes

## CVE-2026-100382 — MediaWiki ExternalData OS Command Injection
- Type: RCE command injection via wikitext
- CMS: MediaWiki with ExternalData extension
- Fixed: N/A
- Auth required: No
- Auto shell: Yes

## CVE-2026-35273 — Oracle PeopleSoft PSEMHUB/PSIGW SSRF → RCE
- Type: SSRF → RCE (ShinyHunters PSEMHUB hub + PSIGW connector)
- CMS: PeopleSoft PeopleTools 8.61/8.62
- Fixed: N/A
- Auth required: No
- Auto shell: Yes

# Keterangan
- Semua 12 CVE didukung di GROOTX v3.2
- Tidak ada CVE-2024-10000 atau CVE-2023-10001 — ini bukan CVE nyata
- Tidak ada CVE historis lama yang tidak ditangani toolkit (CVE-2014, CVE-2015, CVE-2017, CVE-2018, CVE-2019)
# Jenis exploit: rce, rce_deserialization, rce_rest_api, rce_chained, rce_upload, rce_cmd_injection, ssrf_rce